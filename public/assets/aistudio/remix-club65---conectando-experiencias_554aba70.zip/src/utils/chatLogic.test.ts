import test from 'node:test';
import assert from 'node:assert/strict';
import {
  filterChatsForUser,
  validateRegistration,
  ChatItem,
  UserSession,
  getBlockedMessageForProfile,
  getBlockedMessageForActivity,
  getBlockedMessageForReviews,
  canUserUnblock,
  canRemoveParticipantFromGroup,
  isReportMotiveValid
} from './chatLogic';

test('validateRegistration requires valid data', () => {
  assert.equal(validateRegistration({}).valid, false);
  assert.equal(validateRegistration({ username: 'ab' }).valid, false);
  assert.equal(validateRegistration({ username: 'carola', nombre: 'Carola', clave: '12', email: 'test@mail.com' }).valid, false);
  assert.equal(validateRegistration({ username: 'carola', nombre: 'Carola', clave: '1234', email: 'notanemail' }).valid, false);
  assert.equal(validateRegistration({ username: 'carola', nombre: 'Carola Márquez', clave: '1234', email: 'carola@mail.com' }).valid, true);
});

test('filterChatsForUser filters chats based on role and participation', () => {
  const dummyChats: ChatItem[] = [
    { id: 1, title: 'Movilidad', subtitle: 'CEDEM', type: 'grupal', organizerId: 'institucional', allowedRoles: ['personal', 'institucional'] },
    { id: 10, title: 'Tejido', subtitle: 'Plaza', type: 'grupal', organizerId: 'personal', allowedRoles: ['personal'] },
    { id: 99, title: 'Admin Chat', subtitle: 'Seguridad', type: 'grupal', organizerId: 'moderador', allowedRoles: ['moderador'] },
  ];

  const visitante: UserSession = { id: 'vis', username: 'anon', role: 'visitante', apodo: 'Visitante' };
  assert.equal(filterChatsForUser(dummyChats, visitante).length, 0);

  const personalUser: UserSession = { id: 'personal', username: 'carola', role: 'personal', apodo: 'Carola' };
  const personalChats = filterChatsForUser(dummyChats, personalUser);
  assert.equal(personalChats.length, 2);
  assert.ok(personalChats.some(c => c.id === 1));
  assert.ok(personalChats.some(c => c.id === 10));

  const instUser: UserSession = { id: 'institucional', username: 'Municipio 3F', role: 'institucional', apodo: 'Municipio 3F' };
  const instChats = filterChatsForUser(dummyChats, instUser);
  assert.equal(instChats.length, 1);
  assert.equal(instChats[0].id, 1);

  const adminUser: UserSession = { id: 'moderador', username: 'admin', role: 'moderador', apodo: 'Admin' };
  const adminChats = filterChatsForUser(dummyChats, adminUser);
  assert.equal(adminChats.length, 1);
  assert.equal(adminChats[0].id, 99);
});

test('getBlockedMessageForProfile respects bidirectional blocking', () => {
  // If other user blocked me
  assert.equal(getBlockedMessageForProfile('Roberto Gómez', true, false), 'Roberto Gómez te ha bloqueado');
  // If I blocked the other user
  assert.equal(getBlockedMessageForProfile('Roberto Gómez', false, true), 'Has bloqueado a Roberto Gómez. Desbloquealo para ver su información.');
  // If neither blocked
  assert.equal(getBlockedMessageForProfile('Roberto Gómez', false, false), null);
});

test('getBlockedMessageForActivity shows correct messages for organizer blocking', () => {
  // If organizer blocked me
  assert.equal(getBlockedMessageForActivity(true, false), 'El organizador te ha bloqueado');
  // If I blocked the organizer
  assert.equal(getBlockedMessageForActivity(false, true), 'Desbloqueá al organizador para ver ubicación');
  // If neither blocked
  assert.equal(getBlockedMessageForActivity(false, false), null);
});

test('getBlockedMessageForReviews shows correct messages for reviews', () => {
  // If organizer blocked me
  assert.equal(getBlockedMessageForReviews(true, false), 'Reseñas no disponibles (el organizador te ha bloqueado)');
  // If I blocked the organizer
  assert.equal(getBlockedMessageForReviews(false, true), 'Reseñas no disponibles (desbloquea al organizador para ver reseñas)');
  // If neither blocked
  assert.equal(getBlockedMessageForReviews(false, false), null);
});

test('canUserUnblock enforces strict security policy', () => {
  // If other user blocked me, I cannot unblock
  assert.equal(canUserUnblock(true, false), false);
  // Even if both flags somehow true, other blocked me wins
  assert.equal(canUserUnblock(true, true), false);
  // If I blocked the user, I can unblock
  assert.equal(canUserUnblock(false, true), true);
  // If neither blocked, false
  assert.equal(canUserUnblock(false, false), false);
});

test('canRemoveParticipantFromGroup prevents self-removal from group moderation', () => {
  assert.equal(canRemoveParticipantFromGroup('carola', 'Carola Vecina Activa', 'carola'), false);
  assert.equal(canRemoveParticipantFromGroup('carola', 'Carola Vecina Activa', 'Carola Vecina Activa'), false);
  assert.equal(canRemoveParticipantFromGroup('carola', 'Carola Vecina Activa', 'Roberto Gómez'), true);
  assert.equal(canRemoveParticipantFromGroup('carola', 'Carola Vecina Activa', 'Marta Sánchez'), true);
});

test('isReportMotiveValid validates exact 9 report motives', () => {
  assert.equal(isReportMotiveValid('Spam'), true);
  assert.equal(isReportMotiveValid('Odio, abuso, o acoso'), true);
  assert.equal(isReportMotiveValid('Discurso violento'), true);
  assert.equal(isReportMotiveValid('Comportamientos ilegales'), true);
  assert.equal(isReportMotiveValid('Suplantación de identidad'), true);
  assert.equal(isReportMotiveValid('Suicidio o Autolesiones'), true);
  assert.equal(isReportMotiveValid('Terrorismo o extremismo'), true);
  assert.equal(isReportMotiveValid('Integridad cívica'), true);
  assert.equal(isReportMotiveValid('Contenido sexual'), true);
  assert.equal(isReportMotiveValid('Motivo inventado'), false);
});

