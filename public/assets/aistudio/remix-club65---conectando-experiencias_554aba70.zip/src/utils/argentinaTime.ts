/**
 * Utilidades de fecha y hora estándar de la República Argentina (ART: UTC-3)
 * Garantiza que en cualquier entorno de ejecución (servidor, contenedor o navegador),
 * los horarios y fechas de propuestas, moderación, chats y registros correspondan exactamente a Argentina.
 */

export function formatArgentinaDateTime(date: Date = new Date()): string {
  const formatter = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const m: Record<string, string> = {};
  for (const p of parts) m[p.type] = p.value;
  return `${m.day}/${m.month}/${m.year}, ${m.hour}:${m.minute} hs`;
}

export function formatArgentinaDateOnly(date: Date = new Date()): string {
  const formatter = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
  const parts = formatter.formatToParts(date);
  const m: Record<string, string> = {};
  for (const p of parts) m[p.type] = p.value;
  return `${m.day}/${m.month}/${m.year}`;
}

export function formatArgentinaTimeOnly(date: Date = new Date()): string {
  const formatter = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  const m: Record<string, string> = {};
  for (const p of parts) m[p.type] = p.value;
  return `${m.hour}:${m.minute} hs`;
}
