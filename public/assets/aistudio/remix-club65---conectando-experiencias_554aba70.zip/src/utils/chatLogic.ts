export interface ChatItem {
  id: number;
  title: string;
  subtitle: string;
  type: 'grupal' | 'privado';
  activityId?: number | null;
  organizerId?: string;
  allowedRoles?: string[];
  participants?: string[];
}

export interface UserSession {
  id: string;
  username: string;
  role: 'visitante' | 'personal' | 'institucional' | 'moderador';
  apodo: string;
}

/**
 * Filter chats visible to a specific user role and ID.
 * Personal users see chats for activities they are enrolled in, organized, or direct chats where they are participants.
 * Institutional users see chats for their workshops.
 * Moderadores see admin-relevant channels.
 */
export function filterChatsForUser(chats: ChatItem[], user: UserSession | null): ChatItem[] {
  if (!user || user.role === 'visitante') return [];

  return chats.filter(chat => {
    if (user.role === 'moderador') {
      return chat.allowedRoles?.includes('moderador') || false;
    }

    if (user.role === 'institucional') {
      return (
        chat.organizerId === 'institucional' ||
        chat.organizerId === user.id ||
        (chat.allowedRoles?.includes('institucional') ?? false)
      );
    }

    // Personal user
    if (chat.organizerId === 'personal' || chat.organizerId === user.id) return true;
    if (chat.activityId === 1 || chat.activityId === 10) return true;
    if (chat.allowedRoles?.includes('personal')) return true;
    if (chat.participants && (chat.participants.includes(user.id) || chat.participants.includes(user.apodo))) return true;

    return false;
  });
}

/**
 * Validates registration data
 */
export function validateRegistration(data: {
  username?: string;
  nombre?: string;
  clave?: string;
  email?: string;
  tipo?: string;
}): { valid: boolean; error?: string } {
  if (!data.username || data.username.trim().length < 3) {
    return { valid: false, error: 'El nombre de usuario debe tener al menos 3 caracteres.' };
  }
  if (!data.nombre || data.nombre.trim().length < 2) {
    return { valid: false, error: 'Por favor ingresá tu nombre completo.' };
  }
  if (!data.clave || data.clave.length < 3) {
    return { valid: false, error: 'La contraseña debe tener al menos 3 caracteres.' };
  }
  if (!data.email || !data.email.includes('@')) {
    return { valid: false, error: 'Ingresá un correo electrónico válido.' };
  }
  return { valid: true };
}

export const MOTIVOS_REPORTE_LIST = [
  'Spam',
  'Odio, abuso, o acoso',
  'Discurso violento',
  'Comportamientos ilegales',
  'Suplantación de identidad',
  'Suicidio o Autolesiones',
  'Terrorismo o extremismo',
  'Integridad cívica',
  'Contenido sexual'
];

export function isReportMotiveValid(motive: string): boolean {
  return MOTIVOS_REPORTE_LIST.includes(motive);
}

export function getBlockedMessageForProfile(
  targetUserApodo: string,
  didOtherBlockMe: boolean,
  didIBlockUser: boolean
): string | null {
  if (didOtherBlockMe) {
    return `${targetUserApodo} te ha bloqueado`;
  }
  if (didIBlockUser) {
    return `Has bloqueado a ${targetUserApodo}. Desbloquealo para ver su información.`;
  }
  return null;
}

export function getBlockedMessageForActivity(
  didOtherBlockMe: boolean,
  didIBlockUser: boolean
): string | null {
  if (didOtherBlockMe) {
    return 'El organizador te ha bloqueado';
  }
  if (didIBlockUser) {
    return 'Desbloqueá al organizador para ver ubicación';
  }
  return null;
}

export function getBlockedMessageForReviews(
  didOtherBlockMe: boolean,
  didIBlockUser: boolean
): string | null {
  if (didOtherBlockMe) {
    return 'Reseñas no disponibles (el organizador te ha bloqueado)';
  }
  if (didIBlockUser) {
    return 'Reseñas no disponibles (desbloquea al organizador para ver reseñas)';
  }
  return null;
}

/**
 * Checks if the current user has the security permission to unblock the target.
 * If the other user blocked me, I CANNOT unblock them (serious security violation).
 * Only the user who initiated the block can unblock.
 */
export function canUserUnblock(
  didOtherBlockMe: boolean,
  didIBlockUser: boolean
): boolean {
  if (didOtherBlockMe) return false;
  return Boolean(didIBlockUser);
}

/**
 * Checks if a user is allowed to remove a participant in group moderation.
 * Users cannot remove themselves from group moderation (they must use "Salir del grupo").
 */
export function canRemoveParticipantFromGroup(
  currentUsername: string,
  currentApodo: string,
  participantName: string
): boolean {
  const p = (participantName || '').trim().toLowerCase();
  const u = (currentUsername || '').trim().toLowerCase();
  const a = (currentApodo || '').trim().toLowerCase();
  if (p === u || p === a) return false;
  return true;
}

/**
 * Calculates exact canvas draw coordinates matching the CSS object-fit: contain preview.
 */
export function calculateCropCoords(
  viewW: number,
  viewH: number,
  canvasW: number,
  canvasH: number,
  imgW: number,
  imgH: number,
  posX: number,
  posY: number,
  zoom: number
) {
  const scale = canvasW / viewW;
  const imgRatio = imgW / imgH;
  const containerRatio = viewW / viewH;

  let baseW = viewW;
  let baseH = viewH;
  if (imgRatio > containerRatio) {
    baseW = viewW;
    baseH = viewW / imgRatio;
  } else {
    baseH = viewH;
    baseW = viewH * imgRatio;
  }

  const centerX = (viewW / 2 + posX) * scale;
  const centerY = (viewH / 2 + posY) * scale;
  const drawW = baseW * zoom * scale;
  const drawH = baseH * zoom * scale;

  return {
    drawX: centerX - drawW / 2,
    drawY: centerY - drawH / 2,
    drawW,
    drawH
  };
}

