import { User, Activity, Chat, Review, Contact, ChatMessage, SecurityReport, SanctionRecord, SimulatedEmail } from './types.ts';

const SESSION_KEY = 'club65_current_user_id';

export function getStoredUserId(): string | null {
  return localStorage.getItem(SESSION_KEY);
}

export function setStoredUserId(id: string | null) {
  if (id) {
    localStorage.setItem(SESSION_KEY, id);
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

function getHeaders() {
  const userId = getStoredUserId();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (userId) {
    headers['x-user-id'] = userId;
  }
  return headers;
}

export const api = {
  async login(usuario: string, clave: string): Promise<User> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario, clave })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al iniciar sesión.');
    }
    const data = await res.json();
    setStoredUserId(data.user.id);
    return data.user;
  },

  async register(data: {
    usuario: string;
    clave: string;
    apodo: string;
    tipo: 'personal' | 'institucional';
    localidad: string;
    cuit?: string;
    entidadTipo?: string;
    contactoInstitucional?: string;
    email?: string;
  }): Promise<User> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al registrar la cuenta.');
    }
    const result = await res.json();
    setStoredUserId(result.user.id);
    return result.user;
  },

  async getMe(): Promise<User | null> {
    const userId = getStoredUserId();
    if (!userId) return null;
    try {
      const res = await fetch('/api/auth/me', { headers: getHeaders() });
      if (!res.ok) {
        setStoredUserId(null);
        return null;
      }
      const data = await res.json();
      return data.user;
    } catch {
      return null;
    }
  },

  async getUserProfile(username: string): Promise<{ id: string; usuario: string; apodo: string; avatar: string; bio: string; tipo: string; localidad?: string } | null> {
    try {
      const clean = username.replace(/^@/, '').trim();
      const res = await fetch(`/api/users/profile/${encodeURIComponent(clean)}`, { headers: getHeaders() });
      if (!res.ok) return null;
      return res.json();
    } catch {
      return null;
    }
  },

  async updateProfile(updates: Partial<User>): Promise<User> {
    const res = await fetch('/api/auth/profile', {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(updates)
    });
    if (!res.ok) {
      throw new Error('Error al actualizar el perfil.');
    }
    const data = await res.json();
    return data.user;
  },

  // USER BLOCKING
  async blockUser(targetUsername: string): Promise<void> {
    const res = await fetch('/api/users/block', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ targetUsername })
    });
    if (!res.ok) throw new Error('Error al bloquear usuario.');
  },

  async unblockUser(targetUsername: string): Promise<void> {
    const res = await fetch('/api/users/unblock', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ targetUsername })
    });
    if (!res.ok) throw new Error('Error al desbloquear usuario.');
  },

  async getActivities(): Promise<Activity[]> {
    const res = await fetch('/api/activities', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async createActivity(activity: Partial<Activity>): Promise<Activity> {
    const res = await fetch('/api/activities', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(activity)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al crear la actividad.');
    }
    return res.json();
  },

  async enrollActivity(id: number): Promise<Activity> {
    const res = await fetch(`/api/activities/${id}/enroll`, {
      method: 'POST',
      headers: getHeaders()
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al inscribirse.');
    }
    const data = await res.json();
    return data.activity;
  },

  async unenrollActivity(id: number): Promise<Activity> {
    const res = await fetch(`/api/activities/${id}/unenroll`, {
      method: 'POST',
      headers: getHeaders()
    });
    if (!res.ok) {
      throw new Error('Error al desinscribirse.');
    }
    const data = await res.json();
    return data.activity;
  },

  async vetoUser(id: number, username: string): Promise<Activity> {
    const res = await fetch(`/api/activities/${id}/veto`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ username })
    });
    if (!res.ok) throw new Error('Error al vetar al usuario.');
    const data = await res.json();
    return data.activity;
  },

  async deleteActivity(id: number): Promise<void> {
    const res = await fetch(`/api/activities/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al eliminar la actividad.');
  },

  async moderateActivity(id: number, action: 'approve' | 'reject' | 'request_changes', note?: string): Promise<void> {
    const res = await fetch(`/api/activities/${id}/moderate`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ action, note })
    });
    if (!res.ok) throw new Error('Error en moderación.');
  },

  async resubmitProposal(id: number, data: Partial<Activity> & { userFeedbackNote?: string }): Promise<Activity> {
    const res = await fetch(`/api/activities/${id}/resubmit`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al reenviar modificaciones.');
    }
    const result = await res.json();
    return result.activity;
  },

  async getChats(): Promise<Chat[]> {
    const res = await fetch('/api/chats', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async sendChatMessage(chatId: number, text: string, replyTo?: { id: string; sender: string; text: string }): Promise<ChatMessage> {
    const res = await fetch(`/api/chats/${chatId}/messages`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ text, replyTo })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al enviar el mensaje.');
    }
    return res.json();
  },

  async pinChatMessage(chatId: number, messageId: string | null): Promise<Chat> {
    const res = await fetch(`/api/chats/${chatId}/pin`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ messageId })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al fijar mensaje.');
    }
    const data = await res.json();
    return data.chat;
  },

  async getUsers(): Promise<Record<string, User>> {
    try {
      const res = await fetch('/api/users', { headers: getHeaders() });
      if (!res.ok) return {};
      return res.json();
    } catch {
      return {};
    }
  },

  async deleteChatMessage(chatId: number, messageId: string, reasonText?: string): Promise<void> {
    const res = await fetch(`/api/chats/${chatId}/messages/${messageId}/delete`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ reasonText })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al eliminar el mensaje.');
    }
  },

  async addChatParticipant(chatId: number, participant: string): Promise<Chat> {
    const res = await fetch(`/api/chats/${chatId}/participants/add`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ participant })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al agregar participante.');
    }
    const data = await res.json();
    return data.chat;
  },

  async removeChatParticipant(chatId: number, participant: string): Promise<Chat> {
    const res = await fetch(`/api/chats/${chatId}/participants/remove`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ participant })
    });
    if (!res.ok) throw new Error('Error al remover participante.');
    const data = await res.json();
    return data.chat;
  },

  async updateChatPhoto(chatId: number, photoUrl: string): Promise<Chat> {
    const res = await fetch(`/api/chats/${chatId}/photo`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ photoUrl })
    });
    if (!res.ok) throw new Error('Error al actualizar foto del grupo.');
    const data = await res.json();
    return data.chat;
  },

  async makeChatAdmin(chatId: number, participant: string): Promise<Chat> {
    const res = await fetch(`/api/chats/${chatId}/admins`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ participant })
    });
    if (!res.ok) throw new Error('Error al designar administrador.');
    const data = await res.json();
    return data.chat;
  },

  async createChat(data: { title: string; subtitle?: string; type: 'grupal' | 'privado'; participants?: string[]; avatar?: string }): Promise<Chat> {
    const res = await fetch('/api/chats', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Error al crear la conversación.');
    return res.json();
  },

  async leaveChat(chatId: number): Promise<void> {
    const res = await fetch(`/api/chats/${chatId}/leave`, {
      method: 'POST',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al salir del grupo.');
  },

  async deleteChat(chatId: number): Promise<void> {
    await fetch(`/api/chats/${chatId}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
  },

  async getReviews(): Promise<Review[]> {
    const res = await fetch('/api/reviews', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async createReview(rev: Partial<Review>): Promise<Review> {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(rev)
    });
    if (!res.ok) throw new Error('Error al enviar la reseña.');
    return res.json();
  },

  async updateReview(id: number, rev: Partial<Review>): Promise<Review> {
    const res = await fetch(`/api/reviews/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(rev)
    });
    if (!res.ok) throw new Error('Error al actualizar la reseña.');
    return res.json();
  },

  async deleteReview(id: number): Promise<void> {
    const res = await fetch(`/api/reviews/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al eliminar reseña.');
  },

  async getContacts(): Promise<Contact[]> {
    const res = await fetch('/api/contacts', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async addContact(contact: Partial<Contact>): Promise<Contact> {
    const res = await fetch('/api/contacts', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(contact)
    });
    if (!res.ok) throw new Error('Error al agregar contacto.');
    return res.json();
  },

  async deleteContact(id: string): Promise<void> {
    const res = await fetch(`/api/contacts/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al eliminar contacto.');
  },

  // SECURITY REPORTS
  async getReports(): Promise<SecurityReport[]> {
    const res = await fetch('/api/reports', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async createReport(report: {
    type: 'chat_message' | 'review_media' | 'review_text' | 'chat_general';
    chatId?: number;
    messageId?: string;
    messageText?: string;
    mediaUrl?: string;
    reviewId?: number;
    activityId?: number;
    reportedUser?: string;
    reason: string;
    comment?: string;
  }): Promise<{ success: boolean; notificationMessage: string; report: SecurityReport }> {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(report)
    });
    if (!res.ok) throw new Error('Error al enviar el reporte.');
    return res.json();
  },

  async resolveReport(
    id: string,
    status: 'resuelto' | 'desestimado' | 'ban_user' | 'delete_content' | 'dismiss',
    resolutionNote?: string,
    action?: string,
    sanctionReason?: string,
    adminComment?: string
  ): Promise<SecurityReport> {
    const res = await fetch(`/api/reports/${id}/resolve`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({
        status: status === 'dismiss' || status === 'desestimado' ? 'desestimado' : 'resuelto',
        resolutionNote,
        action: action || status,
        sanctionReason,
        adminComment
      })
    });
    if (!res.ok) throw new Error('Error al resolver reporte.');
    const data = await res.json();
    return data.report;
  },

  async forceCancelActivity(id: number, reason: string): Promise<Activity> {
    const res = await fetch(`/api/activities/${id}/force-cancel`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ reason })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al forzar la baja de la actividad.');
    }
    const data = await res.json();
    return data.activity;
  },

  // INSTITUTIONS
  async getPendingInstitutions(): Promise<User[]> {
    const res = await fetch('/api/admin/institutions', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async approveInstitution(userId: string): Promise<User> {
    const res = await fetch(`/api/admin/institutions/${userId}/approve`, {
      method: 'POST',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al dar de alta la institución.');
    const data = await res.json();
    return data.user;
  },

  async rejectInstitution(userId: string, reason?: string): Promise<User> {
    const res = await fetch(`/api/admin/institutions/${userId}/reject`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ reason })
    });
    if (!res.ok) throw new Error('Error al rechazar solicitud.');
    const data = await res.json();
    return data.user;
  },

  async verifyInstitution(userId: string, isVerified: boolean): Promise<User> {
    const res = await fetch(`/api/admin/institutions/${userId}/verify`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ isVerified })
    });
    if (!res.ok) throw new Error('Error al cambiar verificación institucional.');
    const data = await res.json();
    return data.user;
  },

  // PROMOTE USER TO ADMINISTRATOR
  async promoteToAdmin(username: string): Promise<User> {
    const res = await fetch('/api/admin/promote', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ username })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Error al designar administrador.');
    }
    const data = await res.json();
    return data.user;
  },

  // BANS & SANCTIONS
  async getSanctions(): Promise<SanctionRecord[]> {
    const res = await fetch('/api/admin/sanctions', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  },

  async addSanction(sanction: {
    username: string;
    reason: string;
    comment?: string;
    type?: 'temporal_7' | 'temporal_30' | 'permanente';
    liftDate?: string;
    reportId?: string;
  }): Promise<SanctionRecord> {
    const res = await fetch('/api/admin/sanctions', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(sanction)
    });
    if (!res.ok) throw new Error('Error al registrar sanción.');
    const data = await res.json();
    return data.sanction;
  },

  async removeSanction(username: string): Promise<void> {
    const res = await fetch(`/api/admin/sanctions/${username}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    if (!res.ok) throw new Error('Error al levantar sanción.');
  },

  async getBannedUsers(): Promise<string[]> {
    const res = await fetch('/api/admin/banned', { headers: getHeaders() });
    if (!res.ok) return [];
    const data = await res.json();
    return data.bannedUsers || [];
  },

  async banUserGlobal(identifier: string): Promise<void> {
    const res = await fetch('/api/admin/ban', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ identifier })
    });
    if (!res.ok) throw new Error('Error al vetar usuario.');
  },

  async unbanUserGlobal(identifier: string): Promise<void> {
    const res = await fetch('/api/admin/unban', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ identifier })
    });
    if (!res.ok) throw new Error('Error al levantar sanción.');
  },

  async getSimulatedEmails(): Promise<SimulatedEmail[]> {
    const res = await fetch('/api/simulated-emails', { headers: getHeaders() });
    if (!res.ok) return [];
    return res.json();
  }
};
