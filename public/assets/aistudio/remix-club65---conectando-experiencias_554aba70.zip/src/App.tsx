/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { User, Activity, ActivityVersion, Chat, Review, Contact, ChatMessage, SecurityReport, SanctionRecord } from './types.ts';
import { api, setStoredUserId } from './api.ts';
import { canRemoveParticipantFromGroup, getBlockedMessageForActivity, getBlockedMessageForReviews } from './utils/chatLogic.ts';
import { LeafletMap } from './components/LeafletMap.tsx';

declare global {
  interface Window {
    jspdf?: {
      jsPDF: new () => {
        setFont: (font: string, style?: string) => void;
        setFontSize: (size: number) => void;
        text: (text: string, x: number, y: number) => void;
        setLineWidth: (width: number) => void;
        line: (x1: number, y1: number, x2: number, y2: number) => void;
        save: (filename: string) => void;
      };
    };
  }
}

interface GalleryItem {
  mediaUrl: string;
  autor: string;
  estrellas: number;
  fecha: string;
  texto: string;
  actividad: string;
}

function isVideoMedia(url?: string | null): boolean {
  if (!url) return false;
  return url.startsWith('data:video') || /\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(url);
}

const NOMBRES_MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export interface LocationItem {
  nombre: string;
  detalle: string;
  lat?: number;
  lng?: number;
}

const BUSQUEDA_UBICACIONES_EXTENDIDAS: LocationItem[] = [
  { nombre: 'CEDEM 1 - Centro Deportivo', detalle: 'Alberdi 5470, Caseros', lat: -34.6041, lng: -58.5662 },
  { nombre: 'CEDEM 2 - Polideportivo', detalle: 'Alberdi 5040, Caseros', lat: -34.6052, lng: -58.5645 },
  { nombre: 'CEDEM 3 - Parque Deportivo', detalle: 'Miramar y Alvear, El Palomar', lat: -34.5982, lng: -58.5831 },
  { nombre: 'CEDEM 4 - Gimnasio Adaptado', detalle: 'Teodoro Plaza y Castelli, Ciudadela', lat: -34.6362, lng: -58.5391 },
  { nombre: 'Plaza Unidad Nacional', detalle: 'Alberdi y Medina, Caseros', lat: -34.6072, lng: -58.5615 },
  { nombre: 'Plaza Giorello', detalle: 'Fernández de Enciso y Cufer, Santos Lugares', lat: -34.5992, lng: -58.5521 },
  { nombre: 'Plaza de los Aviadores', detalle: 'Boulevard San Martín y De los Jacarandaes, Ciudad Jardín', lat: -34.5932, lng: -58.5872 },
  { nombre: 'Plaza Pineral', detalle: 'Sarmiento y Fischetti, Caseros', lat: -34.6112, lng: -58.5678 },
  { nombre: 'Plaza Villa Parque', detalle: 'Chassaing y Neuquén, Caseros', lat: -34.6025, lng: -58.5712 },
  { nombre: 'Plaza Belgrano', detalle: 'Belgrano y Andrés Ferreyra, Caseros', lat: -34.6095, lng: -58.5582 },
  { nombre: 'Plaza Luján', detalle: 'Lisandro de la Torre y San Martín, El Palomar', lat: -34.5955, lng: -58.5789 },
  { nombre: 'Plaza Mitre', detalle: 'Mitre y Urquiza, Caseros', lat: -34.6081, lng: -58.5641 },
  { nombre: 'Centro Cultural Caseros', detalle: 'Valentín Gómez 4726, Caseros', lat: -34.6078, lng: -58.5629 },
  { nombre: 'Centro Cultural de Sáenz Peña', detalle: 'Amadeo Sabattini 4600, Sáenz Peña', lat: -34.5968, lng: -58.5342 },
  { nombre: 'Punto Digital Tres de Febrero', detalle: 'Urquiza y Valentín Gómez, Caseros', lat: -34.6069, lng: -58.5635 },
  { nombre: 'Sede Municipal Tres de Febrero', detalle: 'Alberdi 4840, Caseros', lat: -34.6061, lng: -58.5632 },
  { nombre: 'Club Social Caseros', detalle: '3 de Febrero 2640, Caseros', lat: -34.6089, lng: -58.5654 },
  { nombre: 'Club AFALP', detalle: 'De las Alas 1050, Ciudad Jardín', lat: -34.5951, lng: -58.5862 },
  { nombre: 'Club Atlético Estudiantes', detalle: 'Av. Urquiza y Lisandro de la Torre, Caseros', lat: -34.6098, lng: -58.5619 },
  { nombre: 'Club Social El Libertador', detalle: 'Av. La Plata 3400, Santos Lugares', lat: -34.6015, lng: -58.5542 },
  { nombre: 'Club Defensores de Santos Lugares', detalle: 'Ernesto Sábato 3150, Santos Lugares', lat: -34.6022, lng: -58.5529 },
  { nombre: 'Centro de Jubilados El Palomar', detalle: 'Rosetti 6200, El Palomar', lat: -34.5945, lng: -58.5812 },
  { nombre: 'Centro de Jubilados y Pensionados Caseros', detalle: 'Mitre 4450, Caseros', lat: -34.6075, lng: -58.5651 },
  { nombre: 'Asociación Vecinal Santos Lugares', detalle: 'Fernández de Enciso 750, Santos Lugares', lat: -34.6001, lng: -58.5535 },
  { nombre: 'Parque del Bicentenario', detalle: 'Triunvirato y Bolivia, Villa Bosch', lat: -34.5829, lng: -58.5684 },
  { nombre: 'Plaza Leonardo Murialdo', detalle: 'Gaucho Cruz y Martín Coronado, Villa Bosch', lat: -34.5872, lng: -58.5715 },
  { nombre: 'Cine Teatro Helios', detalle: 'Boulevard San Martín 3076, Ciudad Jardín', lat: -34.5942, lng: -58.5881 },
  { nombre: 'Casa Museo Ernesto Sábato', detalle: 'Ernesto Sábato 3135, Santos Lugares', lat: -34.6024, lng: -58.5531 },
  { nombre: 'Av. San Martín 1500', detalle: 'Caseros, Tres de Febrero', lat: -34.6062, lng: -58.5638 },
  { nombre: 'Av. Urquiza 4800', detalle: 'Caseros, Tres de Febrero', lat: -34.6074, lng: -58.5632 },
  { nombre: 'Av. La Plata 3200', detalle: 'Santos Lugares, Tres de Febrero', lat: -34.6012, lng: -58.5541 },
  { nombre: 'Av. Gaona y General Paz', detalle: 'Ciudadela, Tres de Febrero', lat: -34.6341, lng: -58.5298 },
  { nombre: 'Av. Rivadavia 12500', detalle: 'Ciudadela, Tres de Febrero', lat: -34.6382, lng: -58.5365 },
  { nombre: 'Av. Márquez y Ruta 8', detalle: 'Loma Hermosa, Tres de Febrero', lat: -34.5682, lng: -58.5821 },
  { nombre: 'Av. Marcelo T. de Alvear 2400', detalle: 'Caseros, Tres de Febrero', lat: -34.6152, lng: -58.5592 },
  { nombre: 'Av. San Martín y Lisandro de la Torre', detalle: 'Caseros, Tres de Febrero', lat: -34.6071, lng: -58.5621 },
  { nombre: 'Estación Caseros (Línea San Martín)', detalle: 'Urquiza y 3 de Febrero, Caseros', lat: -34.6077, lng: -58.5644 },
  { nombre: 'Estación Santos Lugares (Línea San Martín)', detalle: 'Av. La Plata y Rodríguez Peña, Santos Lugares', lat: -34.6008, lng: -58.5518 },
  { nombre: 'Estación Ciudadela (Línea Sarmiento)', detalle: 'Av. Rivadavia y Maipú, Ciudadela', lat: -34.6375, lng: -58.5358 },
  { nombre: 'Estación El Palomar (Línea San Martín)', detalle: 'Marconi y Rosetti, El Palomar', lat: -34.5938, lng: -58.5802 },
  { nombre: 'Hospital Dr. Carlos Bocalandro', detalle: 'Av. Eva Perón (Ruta 8) 9200, Loma Hermosa', lat: -34.5691, lng: -58.5815 },
  { nombre: 'Hospital Dr. Ramón Carrillo', detalle: 'Hipólito Yrigoyen 1051, Ciudadela', lat: -34.6318, lng: -58.5372 },
  { nombre: 'Centro de Jubilados Amigos de Villa Bosch', detalle: 'Quintana 1050, Villa Bosch', lat: -34.5862, lng: -58.5705 },
  { nombre: 'Centro Cultural Municipal Leopoldo Marechal', detalle: 'Alpatacal 3325, Santos Lugares', lat: -34.6019, lng: -58.5524 },
  { nombre: 'Teatro Paramés', detalle: '3 de Febrero 2561, Caseros', lat: -34.6092, lng: -58.5651 }
];

export const MOTIVOS_REPORTE = [
  'Spam',
  'Odio, abuso, o acoso',
  'Discurso violento',
  'Comportamientos ilegales',
  'Suplantación de identidad',
  'Suicidio o Autolesiones',
  'Terrorismo o extremismo',
  'Integridad cívica',
  'Contenido sexual'
];

const UBICACIONES_SUGERIDAS = BUSQUEDA_UBICACIONES_EXTENDIDAS.slice(0, 8);

// Componente para Ajuste y Recorte de Foto (Circular para perfiles/grupos, Rectangular 16:10 para cartelera)
function ImageCropperModal({
  imageSrc,
  title,
  shape = 'circle',
  onCancel,
  onApply
}: {
  imageSrc: string;
  title: string;
  shape?: 'circle' | 'rectangle';
  onCancel: () => void;
  onApply: (croppedDataUrl: string) => void;
}) {
  const [zoom, setZoom] = useState(1);
  const [posX, setPosX] = useState(0);
  const [posY, setPosY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const imgRef = useRef<HTMLImageElement | null>(null);
  const isRect = shape === 'rectangle';

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - posX, y: e.clientY - posY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPosX(e.clientX - dragStart.x);
    setPosY(e.clientY - dragStart.y);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      setDragStart({ x: e.touches[0].clientX - posX, y: e.touches[0].clientY - posY });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    setPosX(e.touches[0].clientX - dragStart.x);
    setPosY(e.touches[0].clientY - dragStart.y);
  };

  const handleApply = () => {
    const canvas = document.createElement('canvas');
    const canvasW = isRect ? 800 : 400;
    const canvasH = isRect ? 480 : 400;
    canvas.width = canvasW;
    canvas.height = canvasH;
    const ctx = canvas.getContext('2d');
    if (!ctx || !imgRef.current) {
      onCancel();
      return;
    }

    const img = imgRef.current;
    ctx.save();

    if (!isRect) {
      ctx.beginPath();
      ctx.arc(canvasW / 2, canvasH / 2, canvasW / 2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
    }

    const viewW = isRect ? 320 : 260;
    const viewH = isRect ? 192 : 260;
    const scale = canvasW / viewW;

    const imgRatio = img.naturalWidth / img.naturalHeight;
    const containerRatio = viewW / viewH;

    let baseW = viewW;
    let baseH = viewH;
    if (imgRatio > containerRatio) {
      baseW = viewW;
      baseH = viewW / imgRatio;
    } else {
      baseH = viewH;
      baseW = viewH * imgRatio;
    }

    const centerX = (viewW / 2 + posX) * scale;
    const centerY = (viewH / 2 + posY) * scale;
    const drawWidth = baseW * zoom * scale;
    const drawHeight = baseH * zoom * scale;

    ctx.drawImage(
      img,
      centerX - drawWidth / 2,
      centerY - drawHeight / 2,
      drawWidth,
      drawHeight
    );
    ctx.restore();

    const croppedBase64 = canvas.toDataURL('image/jpeg', 0.92);
    onApply(croppedBase64);
  };

  return (
    <div className="fixed inset-0 bg-black/85 z-[100] flex items-center justify-center p-4">
      <div className={`bg-stone-900 border-2 border-amber-400 text-amber-50 w-full ${isRect ? 'max-w-md' : 'max-w-sm'} rounded-3xl p-5 shadow-2xl flex flex-col items-center space-y-4 animate-in fade-in zoom-in-95`}>
        <div className="w-full flex items-center justify-between border-b border-stone-800 pb-3">
          <h3 className="font-brand text-lg font-bold text-amber-300 flex items-center gap-2">
            <i className="fa-solid fa-crop-simple text-club-orange" /> {title}
          </h3>
          <button onClick={onCancel} className="text-xl text-stone-400 hover:text-white cursor-pointer font-bold">
            &times;
          </button>
        </div>

        <div
          className={`relative ${isRect ? 'w-[320px] h-[192px] rounded-2xl' : 'w-[260px] h-[260px] rounded-full'} overflow-hidden border-4 border-amber-400 bg-stone-950 flex items-center justify-center cursor-move select-none shadow-inner`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleMouseUp}
        >
          <img
            ref={imgRef}
            src={imageSrc}
            alt="Ajuste"
            draggable={false}
            style={{
              transform: `translate(${posX}px, ${posY}px) scale(${zoom})`,
              transformOrigin: 'center center',
              maxWidth: 'none',
              maxHeight: 'none',
              width: '100%',
              height: '100%',
              objectFit: 'contain'
            }}
            className="pointer-events-none transition-transform duration-75"
          />
          <div className={`absolute inset-0 ${isRect ? 'rounded-2xl' : 'rounded-full'} border border-white/40 pointer-events-none`} />
        </div>

        <p className="text-[11px] text-stone-400 text-center">
          <i className="fa-solid fa-arrows-up-down-left-right mr-1 text-club-orange" /> Arrastrá para posicionar y usá el deslizador para hacer zoom
        </p>

        <div className="w-full flex items-center gap-3 px-2">
          <button
            type="button"
            onClick={() => setZoom(prev => Math.max(1, prev - 0.2))}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-amber-300 flex items-center justify-center font-bold cursor-pointer"
          >
            <i className="fa-solid fa-minus text-xs" />
          </button>
          <input
            type="range"
            min="1"
            max="3"
            step="0.05"
            value={zoom}
            onChange={(e) => setZoom(parseFloat(e.target.value))}
            className="flex-1 accent-amber-400 cursor-pointer"
          />
          <button
            type="button"
            onClick={() => setZoom(prev => Math.min(3, prev + 0.2))}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-amber-300 flex items-center justify-center font-bold cursor-pointer"
          >
            <i className="fa-solid fa-plus text-xs" />
          </button>
          <button
            type="button"
            onClick={() => { setZoom(1); setPosX(0); setPosY(0); }}
            className="px-2 py-1 bg-stone-800 hover:bg-stone-700 text-[10px] rounded-lg text-stone-300 font-bold cursor-pointer"
            title="Restablecer posición"
          >
            Centrar
          </button>
        </div>

        <div className="w-full flex justify-between gap-3 pt-2 border-t border-stone-800">
          <button
            type="button"
            onClick={onCancel}
            className="pill-btn flex-1 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-bold cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleApply}
            className="pill-btn flex-1 py-2.5 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold shadow cursor-pointer flex items-center justify-center gap-1.5"
          >
            <i className="fa-solid fa-check" /> Aplicar foto
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  // Current authenticated user session (null = visitor)
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // In-app Toast notification state (avoiding window.alert in iframe)
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<any>(null);

  function showToast(msg: string) {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => setToastMessage(null), 4000);
  }

  // Active view state
  const [currentView, setCurrentView] = useState<string>('explorar');
  const [showCookiesBanner, setShowCookiesBanner] = useState(true);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const dropdownTimeoutRef = useRef<any>(null);
  const locationDebounceTimerRef = useRef<any>(null);

  // Main data states
  const [activities, setActivities] = useState<Activity[]>([]);
  const [chats, setChats] = useState<Chat[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [reports, setReports] = useState<SecurityReport[]>([]);
  const [pendingInstitutions, setPendingInstitutions] = useState<User[]>([]);
  const [bannedUsersList, setBannedUsersList] = useState<string[]>([]);
  const [sanctionsList, setSanctionsList] = useState<SanctionRecord[]>([]);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [currentCategory, setCurrentCategory] = useState<string>('todas');

  // Active chat state
  const [activeChatId, setActiveChatId] = useState<number | null>(null);
  const [chatInputText, setChatInputText] = useState('');
  const [replyingToMessage, setReplyingToMessage] = useState<{ id: string; sender: string; text: string } | null>(null);
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);

  // Photo Cropper / Adjuster State (Circular para perfiles/grupos, Rectangular para cartelera)
  const [imageCropperState, setImageCropperState] = useState<{
    isOpen: boolean;
    rawSrc: string;
    target: 'group' | 'profile' | 'activity';
    shape?: 'circle' | 'rectangle';
    title: string;
  } | null>(null);

  // Report resolution decision & context states
  const [modalDecisionReporte, setModalDecisionReporte] = useState<{
    report: SecurityReport;
    actionType: 'sancionar' | 'eliminar' | 'desestimar';
    motive: string;
    comment: string;
    sanctionType: 'temporal_7' | 'temporal_30' | 'permanente';
    alsoDelete: boolean;
  } | null>(null);
  const [verContextoReporteId, setVerContextoReporteId] = useState<string | null>(null);
  const [inputPromoverAdmin, setInputPromoverAdmin] = useState('');
  const [editingProposalActivityId, setEditingProposalActivityId] = useState<number | null>(null);
  const [userFeedbackInput, setUserFeedbackInput] = useState<string>('');
  const [modalInstPendingNotice, setModalInstPendingNotice] = useState<{ email: string; apodo: string } | null>(null);
  const [filtroReportes, setFiltroReportes] = useState<'pendientes' | 'historial'>('pendientes');
  const [allUsersMap, setAllUsersMap] = useState<Record<string, User>>({});
  const [modalDesignarAdminOpen, setModalDesignarAdminOpen] = useState(false);

  // Message options & deletion confirm modals
  const [openMessageMenuId, setOpenMessageMenuId] = useState<string | null>(null);
  const [messageToDelete, setMessageToDelete] = useState<{ chatId: number; messageId: string; messageText: string; sender: string } | null>(null);
  const [confirmDenounceMessage, setConfirmDenounceMessage] = useState<{ chatId: number; messageId: string; messageText: string; sender: string } | null>(null);

  // Unified report modal
  const [modalReporteData, setModalReporteData] = useState<{
    isOpen: boolean;
    type: 'chat_message' | 'review_media' | 'review_text' | 'chat_general';
    chatId?: number;
    messageId?: string;
    messageText?: string;
    mediaUrl?: string;
    reviewId?: number;
    activityId?: number;
    reportedUser?: string;
    reason: string;
    comment: string;
  }>({
    isOpen: false,
    type: 'chat_message',
    reason: 'Spam',
    comment: ''
  });

  // Group moderation modal
  const [modalModerarGrupoOpen, setModalModerarGrupoOpen] = useState(false);
  const [adminChangePhotoInput, setAdminChangePhotoInput] = useState('');

  // Dashboard tab
  const [dashboardTab, setDashboardTab] = useState<'propuestas' | 'instituciones' | 'reportes' | 'sanciones'>('propuestas');
  const [modalSolicitarCambiosAct, setModalSolicitarCambiosAct] = useState<Activity | null>(null);
  const [solicitarCambiosNota, setSolicitarCambiosNota] = useState('');
  const [searchBannedQuery, setSearchBannedQuery] = useState('');
  const [modalConfirmReportVisor, setModalConfirmReportVisor] = useState(false);
  const [visorMenuOpen, setVisorMenuOpen] = useState(false);

  // Calendar state
  const [calMesActual, setCalMesActual] = useState(9); // Octubre (0-indexed)
  const [calAnoActual, setCalAnoActual] = useState(2026);

  // Subtabs
  const [subTabMisActividades, setSubTabMisActividades] = useState<'moderar' | 'realizadas'>('moderar');
  const [subTabResenas, setSubTabResenas] = useState<'mis-opiniones' | 'actividades-organizadas'>('mis-opiniones');

  // Modals state
  const [modalLoginOpen, setModalLoginOpen] = useState(false);
  const [modalRegisterOpen, setModalRegisterOpen] = useState(false);
  const [modalEditProfileOpen, setModalEditProfileOpen] = useState(false);
  const [modalDetalleId, setModalDetalleId] = useState<number | null>(null);
  const [modalCustomActivity, setModalCustomActivity] = useState<Activity | null>(null);
  const [modalOpinionesId, setModalOpinionesId] = useState<number | null>(null);
  const [resenasOriginActivityId, setResenasOriginActivityId] = useState<number | null>(null);

  // Review writing & editing with multi-media
  const [modalEscribirResenaOpen, setModalEscribirResenaOpen] = useState(false);
  const [resenaEditData, setResenaEditData] = useState<{ id?: number; actividadId: number; actividad: string; estrellas: number; texto: string } | null>(null);
  const [califEstrellas, setCalifEstrellas] = useState(5);
  const [textoResena, setTextoResena] = useState('');
  const [archivosResena, setArchivosResena] = useState<string[]>([]);

  // Review Gallery Visor state (with next/prev arrows, author, stars, review text)
  const [galeriaItems, setGaleriaItems] = useState<GalleryItem[]>([]);
  const [galeriaIndex, setGaleriaIndex] = useState<number>(0);
  const [modalGaleriaOpen, setModalGaleriaOpen] = useState(false);

  // Directory and contact profile
  const [modalDirectorioOpen, setModalDirectorioOpen] = useState(false);
  const [modalPerfilContacto, setModalPerfilContacto] = useState<Contact | null>(null);
  const [indiceResenaPerfil, setIndiceResenaPerfil] = useState(0);

  // Inscriptos / Personal moderation modals
  const [modalInscriptosId, setModalInscriptosId] = useState<number | null>(null);
  const [modalModeracionActividadId, setModalModeracionActividadId] = useState<number | null>(null);

  // Activity creation modal
  const [modalCrearEventoOpen, setModalCrearEventoOpen] = useState(false);
  const [eventoTipoCreacion, setEventoTipoCreacion] = useState<'personal' | 'institucional'>('personal');
  const [modalFechasRepetitivasOpen, setModalFechasRepetitivasOpen] = useState(false);

  // Group creation & participant modals
  const [modalCrearGrupoOpen, setModalCrearGrupoOpen] = useState(false);
  const [modalVerParticipantesOpen, setModalVerParticipantesOpen] = useState(false);

  // Cancellation and simple image visor
  const [modalConfirmarCancelacion, setModalConfirmarCancelacion] = useState<{ nombre: string; dia: string; hora: string; tipo: 'personal' | 'institucional' } | null>(null);
  const [modalVisorImgSrc, setModalVisorImgSrc] = useState<string | null>(null);

  // Forms
  const [loginForm, setLoginForm] = useState({ usuario: '', clave: '' });
  const [loginError, setLoginError] = useState('');
  const [regForm, setRegForm] = useState({
    tipo: 'personal' as 'personal' | 'institucional',
    nombre: '',
    usuario: '',
    email: '',
    clave: '',
    localidad: '',
    cuit: '',
    entidadTipo: 'municipio',
    contactoInstitucional: '',
    terminos: false
  });
  const [regError, setRegError] = useState('');
  const [profileForm, setProfileForm] = useState({ apodo: '', bio: '', avatar: '' });

  // Event form
  const [eventoForm, setEventoForm] = useState({
    nombre: '',
    avance: '',
    categoria: 'salud' as string,
    frecuencia: 'unico' as 'unico' | 'recurrente',
    fechaIni: '2026-10-26',
    horaIni: '18:00',
    fechaFin: '2026-10-26',
    horaFin: '20:00',
    direccion: '',
    lat: -34.6068,
    lng: -58.5647,
    tipoCupo: 'limitado' as 'limitado' | 'ilimitado',
    cupoMax: 20,
    descripcion: '',
    imagen: ''
  });
  const [eventoImgLabel, setEventoImgLabel] = useState('Predeterminada activa ✓');
  const [sugerenciasUbicacion, setSugerenciasUbicacion] = useState<LocationItem[]>([]);
  const [showSugerencias, setShowSugerencias] = useState(false);
  const [isSearchingLocation, setIsSearchingLocation] = useState(false);

  // Recurring dates helper
  const [frecuenciaRecurrente, setFrecuenciaRecurrente] = useState('semanal');
  const [diasSemanaRecurrente, setDiasSemanaRecurrente] = useState<string[]>(['Lunes']);
  const [diaMesRecurrente, setDiaMesRecurrente] = useState(15);
  const [cantidadEventosRecurrente, setCantidadEventosRecurrente] = useState(12);
  const [resumenRecurrente, setResumenRecurrente] = useState('Semanal (Lunes) • 12 encuentros');

  // Group creation form
  const [nombreNuevoGrupo, setNombreNuevoGrupo] = useState('');
  const [participantesSeleccionadosGrupo, setParticipantesSeleccionadosGrupo] = useState<string[]>([]);

  // Global admin ban form
  const [inputVetarGlobal, setInputVetarGlobal] = useState('');

  // Initial load
  useEffect(() => {
    async function initApp() {
      try {
        setLoading(true);
        let user = await api.getMe();
        if (!user) {
          try {
            user = await api.login('carola', 'caro');
          } catch {
            user = null;
          }
        }
        setCurrentUser(user);

        const [acts, chatsList, revs, conts, reps, insts, bans, sancs, allUsers] = await Promise.all([
          api.getActivities(),
          api.getChats(),
          api.getReviews(),
          api.getContacts(),
          api.getReports(),
          api.getPendingInstitutions(),
          api.getBannedUsers(),
          api.getSanctions(),
          api.getUsers().catch(() => ({} as Record<string, User>))
        ]);

        setActivities(acts);
        setChats(chatsList);
        setReviews(revs);
        setContacts(conts);
        setReports(reps);
        setPendingInstitutions(insts);
        setBannedUsersList(bans);
        setSanctionsList(sancs);
        if (allUsers) setAllUsersMap(allUsers);

        if (user) {
          applyAccessibility(user.textSize, user.contrast);
          setProfileForm({ apodo: user.apodo, bio: user.bio, avatar: user.avatar });
        }
      } catch (err) {
        console.error('Error initializing app:', err);
      } finally {
        setLoading(false);
      }
    }
    initApp();
  }, []);

  // Auto-scroll chat messages
  useEffect(() => {
    if (activeChatId && chatMessagesEndRef.current) {
      chatMessagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chats, activeChatId]);

  function applyAccessibility(size: 'normal' | 'grande' | 'gigante', contrast: boolean) {
    document.body.classList.remove('text-size-grande', 'text-size-gigante', 'high-contrast');
    if (size === 'grande') document.body.classList.add('text-size-grande');
    if (size === 'gigante') document.body.classList.add('text-size-gigante');
    if (contrast) document.body.classList.add('high-contrast');
  }

  async function handleSetTextSize(size: 'normal' | 'grande' | 'gigante') {
    if (!currentUser) return;
    try {
      const updated = await api.updateProfile({ textSize: size });
      setCurrentUser(updated);
      applyAccessibility(size, updated.contrast);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleToggleContrast() {
    if (!currentUser) return;
    try {
      const updated = await api.updateProfile({ contrast: !currentUser.contrast });
      setCurrentUser(updated);
      applyAccessibility(updated.textSize, updated.contrast);
    } catch (e) {
      console.error(e);
    }
  }

  async function refreshData() {
    try {
      const [acts, chatsList, revs, conts, reps, insts, bans, sancs, allUsers] = await Promise.all([
        api.getActivities(),
        api.getChats(),
        api.getReviews(),
        api.getContacts(),
        api.getReports(),
        api.getPendingInstitutions(),
        api.getBannedUsers(),
        api.getSanctions(),
        api.getUsers().catch(() => ({} as Record<string, User>))
      ]);
      setActivities(acts);
      setChats(chatsList);
      setReviews(revs);
      setContacts(conts);
      setReports(reps);
      setPendingInstitutions(insts);
      setBannedUsersList(bans);
      setSanctionsList(sancs);
      if (allUsers) setAllUsersMap(allUsers);
    } catch (e) {
      console.error(e);
    }
  }

  function isUserBlocked(targetName?: string): boolean {
    if (!targetName || !currentUser?.blockedUsers) return false;
    const clean = targetName.trim().toLowerCase();
    return currentUser.blockedUsers.some(u => u.toLowerCase() === clean);
  }

  function didIBlockUser(targetName?: string): boolean {
    if (!targetName) return false;
    const clean = targetName.trim().toLowerCase();
    if (currentUser?.myBlockedUsers && currentUser.myBlockedUsers.some(u => u.toLowerCase() === clean)) return true;
    if (currentUser?.blockedUsers && currentUser.blockedUsers.some(u => u.toLowerCase() === clean)) return true;
    return false;
  }

  function didIBlockContact(contact?: Contact | { nombre?: string; id?: string } | null): boolean {
    if (!contact) return false;
    const aliases = [contact.nombre, contact.id, contact.id?.replace(/^u_/, '')].filter(Boolean) as string[];
    return aliases.some(a => didIBlockUser(a));
  }

  function didOtherBlockMe(targetName?: string): boolean {
    if (!targetName || !currentUser?.blockedByUsers) return false;
    const clean = targetName.trim().toLowerCase();
    return currentUser.blockedByUsers.some(u => u.toLowerCase() === clean);
  }

  function getUserPhotoByName(name?: string): string | undefined {
    if (!name) return undefined;
    const clean = name.trim().toLowerCase().replace(/^@/, '');
    if (currentUser && (clean === currentUser.usuario.toLowerCase() || clean === currentUser.apodo.toLowerCase())) {
      return currentUser.avatar;
    }
    const directUser = allUsersMap[clean];
    if (directUser?.avatar) return directUser.avatar;

    for (const key of Object.keys(allUsersMap)) {
      const u = allUsersMap[key];
      if (u.usuario?.toLowerCase() === clean && u.avatar) return u.avatar;
      if (u.apodo?.toLowerCase() === clean && u.avatar) return u.avatar;
    }

    const foundContact = contacts.find(c => c.nombre.toLowerCase() === clean || c.id.toLowerCase() === clean);
    if (foundContact?.foto) return foundContact.foto;
    return undefined;
  }

  function getChatDisplayTitle(chat: Chat, current?: User | null): string {
    if (chat.type === 'privado' && current) {
      const myApodo = (current.apodo || '').toLowerCase();
      const myUser = (current.usuario || '').toLowerCase();
      if (chat.title.toLowerCase() === myApodo || chat.title.toLowerCase() === myUser) {
        const other = (chat.participants || []).find(p => p.toLowerCase() !== myApodo && p.toLowerCase() !== myUser);
        if (other) return other;
      }
    }
    return chat.title;
  }

  function getChatDisplayPhoto(chat: Chat): string | undefined {
    if (chat.image) return chat.image;
    if (chat.type === 'privado') {
      const displayTitle = getChatDisplayTitle(chat, currentUser);
      return getUserPhotoByName(displayTitle);
    }
    return undefined;
  }

  async function handleAddParticipantToGroup(participantName: string) {
    if (!activeChatId) return;
    try {
      await api.addChatParticipant(activeChatId, participantName);
      await refreshData();
      showToast(`¡${participantName} fue agregado al grupo con éxito!`);
    } catch (err: any) {
      showToast(err.message || 'Error al agregar participante al grupo.');
    }
  }

  async function openUserProfileByName(username?: string) {
    if (!username) return;
    const clean = username.replace(/^@/, '').trim();
    if (currentUser && (clean.toLowerCase() === currentUser.usuario.toLowerCase() || clean.toLowerCase() === currentUser.apodo.toLowerCase())) {
      setModalPerfilContacto({
        id: currentUser.id,
        nombre: currentUser.apodo,
        detalle: `${currentUser.localidad || 'Tres de Febrero'} • Tu Perfil`,
        avatar: currentUser.apodo.slice(0, 2).toUpperCase(),
        avatarClass: 'bg-club-orange',
        bio: currentUser.bio,
        foto: currentUser.avatar
      });
      return;
    }

    const foundContact = contacts.find(c => c.nombre.toLowerCase() === clean.toLowerCase() || c.id.toLowerCase() === clean.toLowerCase());

    try {
      const serverUser = await api.getUserProfile(clean);
      if (serverUser) {
        setModalPerfilContacto({
          id: serverUser.id || `u_${clean}`,
          nombre: serverUser.apodo || clean,
          detalle: `${serverUser.localidad || 'Tres de Febrero'} • Miembro de CLUB65`,
          avatar: (serverUser.apodo || clean).slice(0, 2).toUpperCase(),
          avatarClass: serverUser.tipo === 'institucional' ? 'bg-club-blue' : 'bg-club-orange',
          bio: serverUser.bio || (foundContact ? foundContact.bio : 'Miembro activo de la comunidad de CLUB65.'),
          foto: serverUser.avatar || foundContact?.foto
        });
        return;
      }
    } catch {
      // fallback
    }

    if (foundContact) {
      setModalPerfilContacto(foundContact);
    } else {
      setModalPerfilContacto({
        id: `u_${clean}`,
        nombre: clean,
        detalle: 'Vecino de Tres de Febrero',
        avatar: clean.slice(0, 2).toUpperCase(),
        avatarClass: 'bg-club-orange',
        bio: 'Miembro activo de la comunidad de CLUB65.',
        foto: undefined
      });
    }
  }

  async function handleBlockUser(targetUsername: string) {
    try {
      await api.blockUser(targetUsername);
      const clean = targetUsername.toLowerCase();
      setCurrentUser(prev => {
        if (!prev) return null;
        const newBlocked = Array.from(new Set([...(prev.blockedUsers || []), clean]));
        const newMyBlocked = Array.from(new Set([...(prev.myBlockedUsers || []), clean]));
        return {
          ...prev,
          blockedUsers: newBlocked,
          myBlockedUsers: newMyBlocked
        };
      });
      showToast(`Has bloqueado a ${targetUsername}`);
      const me = await api.getMe().catch(() => null);
      if (me) setCurrentUser(me);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al bloquear usuario.');
    }
  }

  async function handleUnblockUser(targetUsername: string) {
    try {
      await api.unblockUser(targetUsername);
      const clean = targetUsername.toLowerCase();
      setCurrentUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          blockedUsers: (prev.blockedUsers || []).filter(u => u.toLowerCase() !== clean),
          myBlockedUsers: (prev.myBlockedUsers || []).filter(u => u.toLowerCase() !== clean)
        };
      });
      showToast(`Has desbloqueado a ${targetUsername}`);
      const me = await api.getMe().catch(() => null);
      if (me) setCurrentUser(me);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al desbloquear usuario.');
    }
  }

  function openReportModal(data: {
    type: 'chat_message' | 'review_media' | 'review_text' | 'chat_general';
    chatId?: number;
    messageId?: string;
    messageText?: string;
    mediaUrl?: string;
    reviewId?: number;
    activityId?: number;
    reportedUser?: string;
  }) {
    setModalReporteData({
      isOpen: true,
      reason: 'Spam',
      comment: '',
      ...data
    });
  }

  async function handleSubmitReport(e: React.FormEvent) {
    e.preventDefault();
    if (!modalReporteData.reason) return;

    try {
      const res = await api.createReport({
        type: modalReporteData.type,
        chatId: modalReporteData.chatId,
        messageId: modalReporteData.messageId,
        messageText: modalReporteData.messageText,
        mediaUrl: modalReporteData.mediaUrl,
        reviewId: modalReporteData.reviewId,
        activityId: modalReporteData.activityId,
        reportedUser: modalReporteData.reportedUser,
        reason: modalReporteData.reason,
        comment: modalReporteData.comment
      });

      // Show exact notification text required by user
      showToast(res.notificationMessage || 'Su reporte ha sido recibido, Te comunicaremos si detectamos que se incumplió una regla, así como las medidas que tomaremos al respecto');

      // If this report came from deleting a chat message, execute the deletion
      if (confirmDenounceMessage) {
        await api.deleteChatMessage(confirmDenounceMessage.chatId, confirmDenounceMessage.messageId);
        setConfirmDenounceMessage(null);
      }

      setModalReporteData(prev => ({ ...prev, isOpen: false }));
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al enviar reporte');
    }
  }

  async function handleDeleteChatMessage(chatId: number, messageId: string) {
    try {
      await api.deleteChatMessage(chatId, messageId);
      showToast('Mensaje retirado correctamente.');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al retirar mensaje.');
    }
  }

  async function handleRemoveParticipant(participant: string) {
    if (!activeChatId) return;
    try {
      await api.removeChatParticipant(activeChatId, participant);
      showToast(`Se retiró a ${participant} del grupo.`);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al remover participante.');
    }
  }

  async function handleChangeChatPhoto(url: string) {
    if (!activeChatId || !url.trim()) return;
    try {
      const cleanUrl = url.trim();
      setChats(prev => prev.map(c => c.id === activeChatId ? { ...c, image: cleanUrl } : c));
      await api.updateChatPhoto(activeChatId, cleanUrl);
      showToast('Foto del grupo actualizada con éxito.');
      setAdminChangePhotoInput('');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al actualizar foto del grupo.');
    }
  }

  async function handleMakeAdmin(participant: string) {
    if (!activeChatId) return;
    try {
      await api.makeChatAdmin(activeChatId, participant);
      showToast(`¡${participant} ahora es administrador del grupo!`);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al designar administrador.');
    }
  }

  async function handleAdminModerateProposal(id: number, action: 'approve' | 'reject' | 'request_changes', note?: string) {
    try {
      await api.moderateActivity(id, action, note);
      if (action === 'approve') {
        showToast('Propuesta aprobada y publicada en la Cartelera comunitaria.');
      } else if (action === 'request_changes') {
        showToast('Devolución enviada al vecino para que ajuste la propuesta.');
      } else {
        showToast('Propuesta rechazada y archivada.');
      }
      setModalSolicitarCambiosAct(null);
      setSolicitarCambiosNota('');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al procesar propuesta.');
    }
  }

  async function handleApproveInstitution(userId: string) {
    try {
      await api.approveInstitution(userId);
      showToast('Institución dada de alta exitosamente en CLUB65.');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al dar de alta la institución.');
    }
  }

  async function handleRejectInstitution(userId: string) {
    const motivo = prompt('Ingresá el motivo del rechazo del alta institucional (opcional):') || 'Documentación incompleta o no coincide con los registros públicos.';
    try {
      await api.rejectInstitution(userId, motivo);
      showToast('Solicitud de alta institucional rechazada.');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al rechazar alta institucional.');
    }
  }

  async function handlePromoteToAdmin() {
    if (!inputPromoverAdmin.trim()) return;
    const cleanUser = inputPromoverAdmin.trim().replace(/^@/, '');
    try {
      const updated = await api.promoteToAdmin(cleanUser);
      showToast(`¡Usuario @${updated.usuario} ahora es Administrador oficial de CLUB65!`);
      setInputPromoverAdmin('');
      setModalDesignarAdminOpen(false);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al designar administrador.');
    }
  }

  async function handleForceCancelActivity(id: number, title: string) {
    if (confirm(`¿Forzar la baja de la actividad "${title}" de la Cartelera comunitaria?`)) {
      try {
        await api.forceCancelActivity(id, 'Baja forzada por la administración');
        showToast(`Actividad "${title}" dada de baja de la Cartelera.`);
        await refreshData();
      } catch (err: any) {
        showToast(err.message || 'Error al dar de baja la actividad.');
      }
    }
  }

  async function handleLiftSanction(username: string) {
    try {
      await api.removeSanction(username);
      showToast(`Sanción levantada para @${username}.`);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al levantar sanción.');
    }
  }

  async function handleConfirmReportDecision() {
    if (!modalDecisionReporte) return;
    const { report, actionType, motive, comment, sanctionType, alsoDelete } = modalDecisionReporte;
    try {
      if (actionType === 'sancionar') {
        const targetUser = report.reportedUser || 'usuario_reportado';
        await api.resolveReport(report.id, 'ban_user', comment || 'Sancionado por infracción comunitaria', 'sancionar', motive, comment);
        await api.addSanction({
          username: targetUser,
          reason: motive,
          comment: comment || `Infracción: ${motive}.`,
          type: sanctionType,
          reportId: report.id
        });
        if (alsoDelete && report.chatId && report.messageId) {
          await api.deleteChatMessage(report.chatId, report.messageId);
        }
        showToast(`Usuario @${targetUser} sancionado y notificación enviada al denunciante.`);
      } else if (actionType === 'eliminar') {
        await api.resolveReport(report.id, 'delete_content', comment || 'Contenido retirado por la administración.', 'eliminar', motive, comment);
        if (report.chatId && report.messageId) {
          await api.deleteChatMessage(report.chatId, report.messageId);
        }
        showToast('Contenido retirado y notificación enviada al denunciante.');
      } else {
        await api.resolveReport(report.id, 'dismiss', comment || 'El contenido no infringe las normas comunitarias.', 'desestimar', motive, comment);
        showToast('Reporte desestimado.');
      }
      setModalDecisionReporte(null);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al procesar resolución de reporte.');
    }
  }

  async function handleLiftBan(identifier: string) {
    try {
      await api.unbanUserGlobal(identifier);
      showToast(`Sanción levantada para ${identifier}.`);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al levantar sanción.');
    }
  }

  // Login handler
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError('');
    try {
      const user = await api.login(loginForm.usuario, loginForm.clave);
      setCurrentUser(user);
      setProfileForm({ apodo: user.apodo, bio: user.bio, avatar: user.avatar });
      applyAccessibility(user.textSize, user.contrast);
      setModalLoginOpen(false);
      setLoginForm({ usuario: '', clave: '' });
      await refreshData();
      setCurrentView(user.tipo === 'moderador' ? 'moderacion' : 'explorar');
    } catch (err: any) {
      setLoginError(err.message || 'Error al iniciar sesión.');
    }
  }

  // Quick demo login
  async function quickLogin(usuario: string, clave: string) {
    setLoginError('');
    try {
      const user = await api.login(usuario, clave);
      setCurrentUser(user);
      setProfileForm({ apodo: user.apodo, bio: user.bio, avatar: user.avatar });
      applyAccessibility(user.textSize, user.contrast);
      setModalLoginOpen(false);
      await refreshData();
      setCurrentView(user.tipo === 'moderador' ? 'moderacion' : 'explorar');
    } catch (err: any) {
      setLoginError(err.message);
    }
  }

  // Register handler
  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setRegError('');
    try {
      const user = await api.register({
        usuario: regForm.usuario,
        clave: regForm.clave,
        apodo: regForm.nombre,
        tipo: regForm.tipo,
        localidad: regForm.localidad,
        cuit: regForm.cuit,
        entidadTipo: regForm.entidadTipo,
        contactoInstitucional: regForm.contactoInstitucional,
        email: regForm.email
      });

      if (regForm.tipo === 'institucional') {
        setModalRegisterOpen(false);
        setModalInstPendingNotice({
          email: regForm.email || `${regForm.usuario}@correo.club65.ar`,
          apodo: regForm.nombre
        });
        setRegForm({
          tipo: 'personal',
          nombre: '',
          usuario: '',
          email: '',
          clave: '',
          localidad: '',
          cuit: '',
          entidadTipo: 'municipio',
          contactoInstitucional: '',
          terminos: false
        });
        await refreshData();
        return;
      }

      setCurrentUser(user);
      setProfileForm({ apodo: user.apodo, bio: user.bio, avatar: user.avatar });
      setModalRegisterOpen(false);
      await refreshData();
      setCurrentView('explorar');
      showToast(`¡Cuenta creada con éxito para ${user.apodo}!`);
    } catch (err: any) {
      setRegError(err.message || 'Error al registrar.');
    }
  }

  function handleLogout() {
    setStoredUserId(null);
    setCurrentUser(null);
    applyAccessibility('normal', false);
    setCurrentView('home-visitante');
    setUserDropdownOpen(false);
  }

  // Save profile with contextual toast message based on what was updated
  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!currentUser) return;
    try {
      const apodoCambiado = profileForm.apodo.trim() !== currentUser.apodo.trim();
      const fotoCambiada = profileForm.avatar !== currentUser.avatar;

      const updated = await api.updateProfile({
        apodo: profileForm.apodo,
        bio: profileForm.bio,
        avatar: profileForm.avatar
      });
      setCurrentUser(updated);
      setModalEditProfileOpen(false);
      await refreshData();

      if (apodoCambiado && fotoCambiada) {
        showToast('¡Perfil, foto y mensajes actualizados con éxito!');
      } else if (fotoCambiada) {
        showToast('¡Foto de perfil actualizada con éxito!');
      } else if (apodoCambiado) {
        showToast('¡Apodo y mensajes anteriores actualizados con tu nuevo nombre!');
      } else {
        showToast('¡Perfil actualizado con éxito!');
      }
    } catch (err: any) {
      showToast(err.message || 'Error al actualizar perfil');
    }
  }

  function handleProfilePhotoFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          setImageCropperState({
            isOpen: true,
            rawSrc: ev.target.result as string,
            target: 'profile',
            title: 'Ajustar foto de perfil'
          });
        }
      };
      reader.readAsDataURL(file);
    }
  }

  // Toggle enrollment
  async function toggleEnrollment(actId: number) {
    if (!currentUser) {
      setModalDetalleId(null);
      setModalLoginOpen(true);
      return;
    }

    const act = activities.find(a => a.id === actId);
    if (!act) return;

    const isEnrolled = act.enrolledUsernames?.includes(currentUser.usuario);

    try {
      if (isEnrolled) {
        await api.unenrollActivity(actId);
        showToast(`Cancelaste tu inscripción a "${act.title}".`);
      } else {
        await api.enrollActivity(actId);
        showToast(`¡Te inscribiste con éxito a "${act.title}"! Ya podés encontrar el grupo en Mi Chat.`);
      }
      setModalDetalleId(null);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'No se pudo actualizar la inscripción.');
    }
  }

  // Veto user from activity
  async function handleVetoUser(actId: number, username: string) {
    try {
      const updated = await api.vetoUser(actId, username);
      setActivities(prev => prev.map(a => a.id === actId ? updated : a));
      await refreshData();
      showToast(`El usuario ${username} ha sido vetado de la actividad. El cupo ha sido liberado.`);
    } catch (err: any) {
      showToast(err.message || 'Error al vetar usuario.');
    }
  }

  // Cancel activity
  async function executeCancelActivity() {
    if (!modalConfirmarCancelacion) return;
    try {
      const targetAct = activities.find(a =>
        a.title.toLowerCase().trim() === modalConfirmarCancelacion.nombre.toLowerCase().trim() ||
        a.title.toLowerCase().includes(modalConfirmarCancelacion.nombre.toLowerCase().slice(0, 10))
      );
      if (targetAct) {
        await api.deleteActivity(targetAct.id);
      }
      setModalConfirmarCancelacion(null);
      setModalModeracionActividadId(null);
      await refreshData();
      showToast('Actividad cancelada correctamente. Se notificará a los inscriptos.');
    } catch (err: any) {
      showToast(err.message || 'Error al cancelar actividad.');
    }
  }

  // Send message in active chat with reply support
  async function handleSendChatMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!activeChatId || !chatInputText.trim()) return;

    try {
      await api.sendChatMessage(
        activeChatId,
        chatInputText.trim(),
        replyingToMessage ? { id: replyingToMessage.id, sender: replyingToMessage.sender, text: replyingToMessage.text } : undefined
      );
      setChatInputText('');
      setReplyingToMessage(null);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al enviar mensaje');
    }
  }

  // Pin / unpin message toggle
  async function handlePinChatMessage(messageId: string) {
    if (!activeChatId) return;
    try {
      const chat = chats.find(c => c.id === activeChatId);
      const isAlreadyPinned = chat?.pinnedMessageId === messageId;
      const newPinId = isAlreadyPinned ? '' : messageId;
      await api.pinChatMessage(activeChatId, newPinId);
      showToast(isAlreadyPinned ? 'Mensaje desfijado del grupo.' : 'Mensaje fijado en el grupo con éxito.');
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al fijar mensaje');
    }
  }

  // Leave active group chat
  async function handleSalirGrupoActivo() {
    if (!activeChatId) return;
    const c = chats.find(x => x.id === activeChatId);
    if (!c) return;

    try {
      await api.leaveChat(activeChatId);
      if (c.activityId) {
        try {
          await api.unenrollActivity(c.activityId);
        } catch {}
      }
      setChats(prev => prev.filter(x => x.id !== activeChatId));
      setActiveChatId(null);
      await refreshData();
      showToast(`Saliste del grupo "${c.title}".`);
    } catch (err: any) {
      showToast(err.message || 'Error al salir del grupo');
    }
  }

  // Búsqueda de ubicación en tiempo real con OpenStreetMap Nominatim (100% gratuito y libre)
  function handleSearchLocation(query: string) {
    setEventoForm(prev => ({ ...prev, direccion: query }));
    if (!query.trim()) {
      setShowSugerencias(false);
      setIsSearchingLocation(false);
      return;
    }

    const q = query.toLowerCase().trim();
    const directOption: LocationItem = {
      nombre: query,
      detalle: 'Usar esta dirección ingresada',
      lat: eventoForm.lat || -34.6068,
      lng: eventoForm.lng || -58.5647
    };

    // 1. Coincidencias de puntos de referencia locales (Tres de Febrero / BsAs)
    const curatedMatches = BUSQUEDA_UBICACIONES_EXTENDIDAS.filter(
      u => u.nombre.toLowerCase().includes(q) || u.detalle.toLowerCase().includes(q)
    );

    setSugerenciasUbicacion([directOption, ...curatedMatches]);
    setShowSugerencias(true);
    setIsSearchingLocation(true);

    // 2. Consulta en vivo a Nominatim OpenStreetMap sin coste ni API key
    if (locationDebounceTimerRef.current) {
      clearTimeout(locationDebounceTimerRef.current);
    }
    locationDebounceTimerRef.current = setTimeout(async () => {
      try {
        const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&addressdetails=1&limit=8`;
        const res = await fetch(url, { headers: { 'Accept-Language': 'es' } });
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            const realExternal: LocationItem[] = data.map((item: any) => {
              const parts = item.display_name.split(',');
              const cleanTitle = parts.slice(0, 2).join(',').trim();
              return {
                nombre: cleanTitle || item.name || query,
                detalle: item.display_name,
                lat: parseFloat(item.lat),
                lng: parseFloat(item.lon)
              };
            });

            // Si es la primera coincidencia y la dirección escrita coincide, actualizamos coordenadas
            if (realExternal[0] && typeof realExternal[0].lat === 'number') {
              const firstLat = realExternal[0].lat ?? -34.6068;
              const firstLng = realExternal[0].lng ?? -58.5647;
              setEventoForm(prev => {
                if (prev.direccion === query) {
                  return { ...prev, lat: firstLat, lng: firstLng };
                }
                return prev;
              });
            }

            setSugerenciasUbicacion(prev => {
              const existing = new Set(prev.map(p => p.nombre.toLowerCase()));
              const fresh = realExternal.filter((r) => !existing.has(r.nombre.toLowerCase()));
              const combined = [directOption, ...prev.filter(p => p !== directOption), ...fresh];
              setShowSugerencias(combined.length > 0);
              return combined.slice(0, 20);
            });
          }
        }
      } catch {
        // Mantiene la opción directa ingresada por el vecino
      } finally {
        setIsSearchingLocation(false);
      }
    }, 350);
  }

  function handleEventImageFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          setImageCropperState({
            isOpen: true,
            rawSrc: ev.target.result as string,
            title: 'Ajustar imagen de la actividad (Cartelera)',
            target: 'activity',
            shape: 'rectangle'
          });
        }
      };
      reader.readAsDataURL(file);
    }
  }

  // Submit new activity
  async function handleSubmitEvento(e: React.FormEvent) {
    e.preventDefault();
    if (!eventoForm.nombre.trim() || !eventoForm.avance.trim() || !eventoForm.descripcion.trim() || !eventoForm.direccion.trim()) {
      showToast('Por favor completá todos los campos obligatorios del formulario.');
      return;
    }

    const scheduleText = eventoForm.frecuencia === 'recurrente'
      ? resumenRecurrente
      : `${eventoForm.fechaIni} a las ${eventoForm.horaIni} h`;

    try {
      if (editingProposalActivityId) {
        await api.resubmitProposal(editingProposalActivityId, {
          title: eventoForm.nombre.trim(),
          category: eventoForm.categoria,
          schedule: scheduleText,
          location: eventoForm.direccion.trim(),
          lat: eventoForm.lat || -34.6068,
          lng: eventoForm.lng || -58.5647,
          capacity: eventoForm.tipoCupo === 'limitado' ? Number(eventoForm.cupoMax) || 20 : 999,
          shortDescription: eventoForm.avance.trim() || eventoForm.nombre.trim(),
          description: eventoForm.descripcion.trim() || eventoForm.avance.trim() || 'Actividad barrial en Tres de Febrero.',
          image: eventoForm.imagen || 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop',
          userFeedbackNote: userFeedbackInput.trim() || 'Modificaciones realizadas según las observaciones de la administración.'
        });
        setEditingProposalActivityId(null);
        setUserFeedbackInput('');
        setModalCrearEventoOpen(false);
        setEventoForm({
          nombre: '',
          avance: '',
          categoria: 'salud',
          frecuencia: 'unico',
          fechaIni: '2026-10-26',
          horaIni: '18:00',
          fechaFin: '2026-10-26',
          horaFin: '20:00',
          direccion: '',
          lat: -34.6068,
          lng: -58.5647,
          tipoCupo: 'limitado',
          cupoMax: 20,
          descripcion: '',
          imagen: ''
        });
        await refreshData();
        showToast('¡Modificaciones reenviadas con éxito! Tu propuesta volvió a revisión del moderador.');
        return;
      }

      const newAct = await api.createActivity({
        title: eventoForm.nombre.trim(),
        category: eventoForm.categoria,
        schedule: scheduleText,
        location: eventoForm.direccion.trim(),
        lat: eventoForm.lat || -34.6068,
        lng: eventoForm.lng || -58.5647,
        capacity: eventoForm.tipoCupo === 'limitado' ? Number(eventoForm.cupoMax) || 20 : 999,
        shortDescription: eventoForm.avance.trim() || eventoForm.nombre.trim(),
        description: eventoForm.descripcion.trim() || eventoForm.avance.trim() || 'Actividad barrial en Tres de Febrero.',
        image: eventoForm.imagen || 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop',
        isInstitutional: eventoTipoCreacion === 'institucional',
        isRecurrent: eventoForm.frecuencia === 'recurrente'
      });

      setModalCrearEventoOpen(false);
      setEventoForm({
        nombre: '',
        avance: '',
        categoria: 'salud',
        frecuencia: 'unico',
        fechaIni: '2026-10-26',
        horaIni: '18:00',
        fechaFin: '2026-10-26',
        horaFin: '20:00',
        direccion: '',
        lat: -34.6068,
        lng: -58.5647,
        tipoCupo: 'limitado',
        cupoMax: 20,
        descripcion: '',
        imagen: ''
      });
      await refreshData();

      if (eventoTipoCreacion === 'institucional') {
        showToast('¡Actividad Oficial creada y publicada con éxito en la cartelera! Ya cuenta con su grupo en Mi Chat.');
      } else {
        showToast(`¡Gracias ${currentUser?.apodo || 'vecino'}! Tu propuesta "${newAct.title}" fue enviada a revisión. Debe ser aprobada por un moderador antes de aparecer en la Cartelera.`);
      }
    } catch (err: any) {
      showToast(err.message || 'Error al procesar actividad');
    }
  }

  // Multi-media review upload: validates 45-second video duration and appends photos/videos
  function handleMultiMediaReviewFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      if (file.type.startsWith('video/')) {
        const tempVideo = document.createElement('video');
        tempVideo.preload = 'metadata';
        const objectUrl = URL.createObjectURL(file);
        tempVideo.src = objectUrl;

        tempVideo.onloadedmetadata = () => {
          URL.revokeObjectURL(objectUrl);
          if (tempVideo.duration > 45) {
            showToast(`El video dura ${Math.round(tempVideo.duration)} seg. El límite máximo permitido es de 45 segundos.`);
            return;
          }
          const reader = new FileReader();
          reader.onload = (ev) => {
            if (ev.target?.result) {
              setArchivosResena(prev => [...prev, ev.target!.result as string]);
            }
          };
          reader.readAsDataURL(file);
        };
      } else {
        const reader = new FileReader();
        reader.onload = (ev) => {
          if (ev.target?.result) {
            setArchivosResena(prev => [...prev, ev.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // Remove individual photo from review
  function handleRemoveReviewMedia(indexToRemove: number) {
    setArchivosResena(prev => prev.filter((_, idx) => idx !== indexToRemove));
  }

  // Save review (create or edit)
  async function handleGuardarResena(e: React.FormEvent) {
    e.preventDefault();
    if (!resenaEditData || !textoResena.trim()) return;

    try {
      if (resenaEditData.id) {
        await api.updateReview(resenaEditData.id, {
          texto: textoResena.trim(),
          estrellas: califEstrellas,
          media: archivosResena,
          foto: archivosResena[0] || null
        });
        showToast('¡Tu reseña fue actualizada correctamente!');
      } else {
        await api.createReview({
          actividadId: resenaEditData.actividadId,
          actividad: resenaEditData.actividad,
          estrellas: califEstrellas,
          texto: textoResena.trim(),
          media: archivosResena,
          foto: archivosResena[0] || null
        });
        showToast('¡Tu reseña y contenidos multimedia se han publicado con éxito en la comunidad!');
      }
      setModalEscribirResenaOpen(false);
      setResenaEditData(null);
      setTextoResena('');
      setArchivosResena([]);
      await refreshData();
    } catch (err: any) {
      showToast(err.message || 'Error al guardar reseña');
    }
  }

  // Open Gallery Visor with all media items for the activity
  function openGalleryVisor(clickedMediaUrl: string, activityId: number) {
    const activityReviews = reviews.filter(r => r.actividadId === activityId || (!activityId && r.actividadId === 1));
    const items: GalleryItem[] = [];

    activityReviews.forEach(r => {
      const mediaList = r.media && r.media.length ? r.media : (r.foto ? [r.foto] : []);
      mediaList.forEach(url => {
        items.push({
          mediaUrl: url,
          autor: r.autor,
          estrellas: r.estrellas,
          fecha: r.fecha,
          texto: r.texto,
          actividad: r.actividad
        });
      });
    });

    if (items.length === 0) {
      setModalVisorImgSrc(clickedMediaUrl);
      return;
    }

    const clickedIdx = items.findIndex(it => it.mediaUrl === clickedMediaUrl);
    setGaleriaItems(items);
    setGaleriaIndex(clickedIdx !== -1 ? clickedIdx : 0);
    setModalGaleriaOpen(true);
  }

  function handleGaleriaPrev() {
    setGaleriaIndex(prev => (prev === 0 ? galeriaItems.length - 1 : prev - 1));
  }

  function handleGaleriaNext() {
    setGaleriaIndex(prev => (prev === galeriaItems.length - 1 ? 0 : prev + 1));
  }

  // Add contact
  async function handleAgendarContacto(nombre: string, localidad: string, avatar: string, avatarClass: string, bio: string, foto?: string) {
    if (currentUser && (nombre.toLowerCase() === currentUser.apodo.toLowerCase() || nombre.toLowerCase() === currentUser.usuario.toLowerCase())) {
      showToast('No podés agendar a tu propio usuario.');
      return;
    }
    if (contacts.some(c => c.nombre.toLowerCase() === nombre.toLowerCase())) {
      showToast(`${nombre} ya está en tus contactos.`);
      return;
    }
    try {
      await api.addContact({
        nombre,
        detalle: `${localidad} • Agendado desde grupo`,
        avatar,
        avatarClass,
        bio,
        foto
      });
      await refreshData();
      showToast(`¡${nombre} ha sido agregado a tus Contactos!`);
    } catch (err: any) {
      showToast(err.message || 'Error al agendar contacto');
    }
  }

  // Delete contact (desagendar)
  async function handleDesagendarContacto(contactId: string, contactNombre: string) {
    try {
      setContacts(prev => prev.filter(c => c.id !== contactId));
      if (modalPerfilContacto?.id === contactId) {
        setModalPerfilContacto(null);
      }
      await api.deleteContact(contactId);
      await refreshData();
      showToast(`${contactNombre} fue eliminado de tus contactos.`);
    } catch (err: any) {
      showToast(err.message || 'Error al eliminar contacto');
    }
  }

  // Create new group chat
  async function handleCrearNuevoGrupo(e: React.FormEvent) {
    e.preventDefault();
    if (!nombreNuevoGrupo.trim()) {
      showToast('Por favor escribí un nombre para el grupo.');
      return;
    }

    try {
      const newChat = await api.createChat({
        title: nombreNuevoGrupo.trim(),
        type: 'grupal',
        participants: participantesSeleccionadosGrupo
      });
      setModalCrearGrupoOpen(false);
      setNombreNuevoGrupo('');
      setParticipantesSeleccionadosGrupo([]);
      await refreshData();
      setActiveChatId(newChat.id);
      showToast(`¡Grupo "${newChat.title}" creado con éxito! Sos la moderadora del grupo.`);
    } catch (err: any) {
      showToast(err.message || 'Error al crear grupo');
    }
  }

  // Admin moderation
  async function handleAdminModerate(actId: number, action: 'approve' | 'reject') {
    try {
      await api.moderateActivity(actId, action);
      await refreshData();
      showToast(action === 'approve' ? 'Iniciativa vecinal aprobada y publicada en la cartelera.' : 'Propuesta rechazada.');
    } catch (err: any) {
      showToast(err.message || 'Error al moderar');
    }
  }

  async function handleGlobalBan(e: React.FormEvent) {
    e.preventDefault();
    if (!inputVetarGlobal.trim()) return;
    const cleanUser = inputVetarGlobal.trim().replace(/^@/, '');
    try {
      await api.addSanction({
        username: cleanUser,
        reason: MOTIVOS_REPORTE[0],
        comment: 'Sanción preventiva aplicada manualmente por la administración.',
        type: 'temporal_7'
      });
      setInputVetarGlobal('');
      await refreshData();
      showToast(`El usuario @${cleanUser} ha sido sancionado y registrado en la lista de suspensiones.`);
    } catch (err: any) {
      showToast(err.message || 'Error al sancionar usuario.');
    }
  }

  function descargarPlanillaPDF(tituloActividad: string, nomina: Array<{ nombre: string; contacto: string }>) {
    if (!window.jspdf) {
      showToast('jsPDF no está cargado.');
      return;
    }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('CLUB65 - PLANILLA OFICIAL DE ASISTENCIA', 14, 20);

    doc.setFontSize(12);
    doc.text(`Actividad: ${tituloActividad}`, 14, 30);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(`Fecha de emisión: ${new Date().toLocaleDateString('es-AR')}`, 14, 37);

    doc.setLineWidth(0.5);
    doc.line(14, 42, 196, 42);

    let y = 52;
    doc.setFont('helvetica', 'bold');
    doc.text('N°', 14, y);
    doc.text('Nombre y Apellido', 25, y);
    doc.text('Contacto de Emergencia', 95, y);
    doc.text('Firma de Asistencia', 155, y);
    doc.line(14, y + 2, 196, y + 2);

    y += 10;
    doc.setFont('helvetica', 'normal');

    nomina.forEach((p, idx) => {
      doc.text(`${idx + 1}`, 14, y);
      doc.text(p.nombre, 25, y);
      doc.text(p.contacto, 95, y);
      doc.line(155, y, 190, y);
      y += 10;
    });

    doc.save(`Planilla_Asistencia_${tituloActividad.replace(/\s+/g, '_')}.pdf`);
  }

  // Filtered activities
  const filteredActivities = activities.filter(act => {
    if (!act.isApproved) return false;
    const matchCat = currentCategory === 'todas' || act.category === currentCategory;
    const q = searchQuery.toLowerCase();
    const matchText = act.title.toLowerCase().includes(q) || act.location.toLowerCase().includes(q);
    return matchCat && matchText;
  });

  const agendaActivities = activities.filter(act => {
    if (!currentUser) return false;
    if (currentUser.tipo === 'personal') {
      return act.enrolledUsernames?.includes(currentUser.usuario) || act.organizerId === currentUser.id;
    }
    if (currentUser.tipo === 'institucional') {
      return act.organizerId === 'institucional' || act.organizerId === currentUser.id;
    }
    return false;
  });

  const pendingActivities = activities.filter(act => !act.isApproved);
  const activeChat = chats.find(c => c.id === activeChatId);
  const modalActividad = modalCustomActivity || activities.find(a => a.id === modalDetalleId);
  const opinionesActividad = reviews.filter(r => r.actividadId === modalOpinionesId || (!modalOpinionesId && r.actividadId === 1));

  const closeModalDetalle = () => {
    setModalDetalleId(null);
    setModalCustomActivity(null);
  };

  const openVersionDetail = (v: ActivityVersion, baseAct: Activity) => {
    setModalCustomActivity({
      ...baseAct,
      id: -(baseAct.id * 100 + v.version),
      title: v.title,
      schedule: v.schedule,
      location: v.location,
      lat: v.lat || baseAct.lat || -34.6068,
      lng: v.lng || baseAct.lng || -58.5647,
      capacity: v.capacity,
      shortDescription: v.shortDescription || v.title,
      description: v.description,
      image: v.image || baseAct.image
    });
    setModalDetalleId(baseAct.id);
  };

  // Calendar calculations
  const primerDiaSemana = new Date(calAnoActual, calMesActual, 1).getDay();
  const offsetLunes = primerDiaSemana === 0 ? 6 : primerDiaSemana - 1;
  const totalDiasMes = new Date(calAnoActual, calMesActual + 1, 0).getDate();
  const diasMesAnterior = new Date(calAnoActual, calMesActual, 0).getDate();

  const actividadesOctubreMap: Record<number, string> = {
    6: 'Movilidad y elongación (18:00 h)',
    8: 'Movilidad y elongación (18:00 h)',
    14: 'Tarde de Tejido y Mate (16:00 h)',
    15: 'Movilidad y elongación (18:00 h)',
    21: 'Tarde de Tejido y Mate (16:00 h)',
    28: 'Tarde de Tejido y Mate (16:00 h)'
  };

  const calNombreMesAno = `${NOMBRES_MESES[calMesActual]} ${calAnoActual}`;

  // Current active chat moderation flag
  const isCurrentUserModeratorOfActiveChat = activeChat && currentUser && (
    activeChat.creatorId === currentUser.id ||
    activeChat.creatorName === currentUser.apodo ||
    activeChat.organizerId === currentUser.id
  );

  return (
    <div className="min-h-screen flex flex-col pb-12">
      {/* BANNER DE COOKIES */}
      {showCookiesBanner && (
        <aside
          id="banner-cookies"
          className="fixed bottom-0 inset-x-0 bg-[#3D2114] text-amber-100 z-50 p-4 border-t-2 border-club-orange shadow-2xl"
        >
          <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs sm:text-sm">
            <div className="flex items-center gap-3">
              <i className="fa-solid fa-cookie-bite text-club-orange text-2xl flex-shrink-0" />
              <p className="leading-relaxed">
                <strong>Este sitio utiliza cookies:</strong> Usamos cookies técnicas para recordar tu sesión y preferencias de accesibilidad. Podés aceptar todas o elegir solo las necesarias.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => setShowCookiesBanner(false)}
                className="pill-btn px-4 py-2 bg-stone-700 hover:bg-stone-600 text-white text-xs font-bold"
              >
                Solo necesarias
              </button>
              <button
                onClick={() => setShowCookiesBanner(false)}
                className="pill-btn px-5 py-2 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold shadow-sm"
              >
                Aceptar
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* NAVBAR PRINCIPAL */}
      <nav className="bg-club-cream border-b-2 border-amber-200/60 sticky top-0 z-30 retro-shadow">
        <div className="max-w-5xl mx-auto px-4 py-2.5 flex items-center justify-between">
          {/* BRAND LOGO */}
          <button
            onClick={() => setCurrentView(currentUser ? 'explorar' : 'home-visitante')}
            className="flex items-center gap-2.5 sm:gap-3 text-left cursor-pointer border-none bg-transparent"
          >
            <div className="w-11 h-11 sm:w-12 sm:h-12 flex-shrink-0 flex items-center justify-center">
              <img
                src="/assets/aistudio/ISOLOGO_5e044cb6.png"
                alt="Club65 Isotipo"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div className="h-9 sm:h-11 flex items-center">
              <img
                src="/assets/aistudio/LOGOTIPO_10cf9c66.png"
                alt="CLUB65 Conectando Experiencias"
                className="h-full object-contain"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
          </button>

          {/* USER SESSION ACTIONS / DROPDOWN */}
          <div
            className="relative"
            onMouseEnter={() => {
              if (dropdownTimeoutRef.current) {
                clearTimeout(dropdownTimeoutRef.current);
                dropdownTimeoutRef.current = null;
              }
            }}
            onMouseLeave={() => {
              if (dropdownTimeoutRef.current) {
                clearTimeout(dropdownTimeoutRef.current);
              }
              dropdownTimeoutRef.current = setTimeout(() => {
                setUserDropdownOpen(false);
              }, 600);
            }}
          >
            {currentUser ? (
              <div>
                <button
                  onClick={() => {
                    if (dropdownTimeoutRef.current) clearTimeout(dropdownTimeoutRef.current);
                    setUserDropdownOpen(!userDropdownOpen);
                  }}
                  className="flex items-center gap-2.5 bg-amber-100/70 hover:bg-amber-100 border border-amber-200 px-3.5 py-1.5 rounded-full text-xs sm:text-sm transition cursor-pointer"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.apodo}
                    className="w-7 h-7 rounded-full object-cover border border-club-orange cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setModalVisorImgSrc(currentUser.avatar);
                    }}
                  />
                  <span className="font-bold text-club-brown flex items-center gap-1">
                    ¡Bienvenida/o, {currentUser.apodo}!
                  </span>
                  {currentUser.isVerified && (
                    <span className="text-blue-600"><i className="fa-solid fa-circle-check" /></span>
                  )}
                  <i className="fa-solid fa-chevron-down text-[10px] text-stone-500 ml-1" />
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div
                    onMouseEnter={() => {
                      if (dropdownTimeoutRef.current) {
                        clearTimeout(dropdownTimeoutRef.current);
                        dropdownTimeoutRef.current = null;
                      }
                    }}
                    className="absolute right-0 mt-1 w-56 bg-white border border-amber-200 rounded-2xl shadow-xl z-50 py-1.5 text-xs text-club-brown divide-y divide-amber-100"
                  >
                    <div className="p-1">
                      <button
                        onClick={() => {
                          setModalEditProfileOpen(true);
                          setUserDropdownOpen(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-amber-50 rounded-xl flex items-center gap-2 font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-user-pen text-club-orange" /> Mi Perfil
                      </button>
                    </div>

                    <div className="p-1">
                      <button
                        onClick={() => {
                          setCurrentView('info-util');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-amber-50 rounded-xl flex items-center gap-2 font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-shield-heart text-emerald-600" /> Información Útil
                      </button>
                      <button
                        onClick={() => {
                          setCurrentView('accesibilidad');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-amber-50 rounded-xl flex items-center gap-2 font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-universal-access text-club-teal" /> Accesibilidad
                      </button>
                    </div>

                    <div className="p-1">
                      <button
                        onClick={() => {
                          setCurrentView('soporte');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-amber-50 rounded-xl flex items-center gap-2 font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-headset text-stone-600" /> Soporte
                      </button>
                    </div>

                    <div className="p-1">
                      <button
                        onClick={handleLogout}
                        className="w-full px-3 py-2 text-left hover:bg-rose-50 text-rose-700 rounded-xl flex items-center gap-2 font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-arrow-right-from-bracket" /> Cerrar sesión
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setModalLoginOpen(true)}
                  className="pill-btn px-4 py-2 bg-white text-club-brown border border-amber-300 hover:bg-amber-50 text-xs sm:text-sm font-bold shadow-xs cursor-pointer"
                >
                  <i className="fa-solid fa-right-to-bracket mr-1.5 text-club-orange" /> Iniciar sesión
                </button>
                <button
                  onClick={() => setModalRegisterOpen(true)}
                  className="pill-btn px-4 py-2 bg-club-orange text-white hover:bg-club-orange-dark text-xs sm:text-sm font-bold shadow-sm cursor-pointer"
                >
                  <i className="fa-solid fa-user-plus mr-1.5" /> Registrarme
                </button>
              </div>
            )}
          </div>
        </div>

        {/* PESTAÑAS PRINCIPALES */}
        {currentUser && (
          <div className="max-w-5xl mx-auto px-4 pb-3 pt-1 flex gap-2 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setCurrentView('explorar')}
              className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer ${
                currentView === 'explorar'
                  ? 'bg-club-orange text-white shadow-sm'
                  : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
              }`}
            >
              <i className="fa-solid fa-compass" /> Cartelera
            </button>

            {currentUser.tipo !== 'moderador' && (
              <button
                onClick={() => setCurrentView('agenda')}
                className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer ${
                  currentView === 'agenda'
                    ? 'bg-club-orange text-white shadow-sm'
                    : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
                }`}
              >
                <i className="fa-solid fa-calendar-check text-club-orange" /> Mi Agenda{' '}
                <span className="bg-club-orange text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {agendaActivities.length}
                </span>
              </button>
            )}

            {currentUser.tipo !== 'moderador' && (
              <button
                onClick={() => setCurrentView('chat')}
                className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer ${
                  currentView === 'chat'
                    ? 'bg-club-orange text-white shadow-sm'
                    : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
                }`}
              >
                <i className="fa-solid fa-comments text-club-teal" /> Mi Chat
              </button>
            )}

            {currentUser.tipo !== 'moderador' && (() => {
              const hasModificaciones = activities.some(a =>
                (a.organizerId === currentUser.id || a.organizer === currentUser.apodo || a.organizer === currentUser.usuario || (currentUser.usuario === 'carola' && (a.id === 10 || a.id === 204 || a.organizerId === 'personal'))) &&
                a.proposalStatus === 'cambios_solicitados' &&
                !a.changesSubmittedAt
              );
              return (
                <button
                  onClick={() => setCurrentView('mis-actividades')}
                  className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer relative ${
                    currentView === 'mis-actividades'
                      ? 'bg-club-orange text-white shadow-sm'
                      : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
                  }`}
                >
                  <i className="fa-solid fa-list-check text-club-orange" /> Mis Actividades
                  {hasModificaciones && (
                    <span className="flex h-2.5 w-2.5 relative ml-0.5" title="Modificaciones solicitadas">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600" />
                    </span>
                  )}
                </button>
              );
            })()}

            {currentUser.tipo === 'personal' && (
              <button
                onClick={() => setCurrentView('resenas')}
                className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer ${
                  currentView === 'resenas'
                    ? 'bg-club-orange text-white shadow-sm'
                    : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
                }`}
              >
                <i className="fa-solid fa-star text-club-orange" /> Mis Reseñas
              </button>
            )}

            {currentUser.tipo === 'personal' && (
              <button
                onClick={() => {
                  setEventoTipoCreacion('personal');
                  setModalCrearEventoOpen(true);
                }}
                className="pill-btn px-4 py-2 text-xs sm:text-sm bg-club-blue text-club-brown hover:bg-club-orange hover:text-white border border-club-teal/30 flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer"
              >
                <i className="fa-solid fa-plus-circle" /> Proponer Actividad
              </button>
            )}

            {currentUser.tipo === 'personal' && (
              <button
                onClick={() => setCurrentView('whatsapp-comunidad')}
                className={`pill-btn px-4 py-2 text-xs sm:text-sm flex items-center gap-2 flex-shrink-0 font-bold cursor-pointer ${
                  currentView === 'whatsapp-comunidad'
                    ? 'bg-club-orange text-white shadow-sm'
                    : 'bg-white text-club-brown border border-amber-200 hover:bg-amber-50'
                }`}
              >
                <i className="fa-brands fa-whatsapp text-emerald-600 text-sm" /> Comunidad de WhatsApp
              </button>
            )}

            {currentUser.tipo === 'institucional' && (
              <button
                onClick={() => {
                  setEventoTipoCreacion('institucional');
                  setModalCrearEventoOpen(true);
                }}
                className="pill-btn px-4 py-2 text-xs sm:text-sm bg-club-orange text-white flex items-center gap-2 flex-shrink-0 font-bold ml-auto shadow-sm cursor-pointer"
              >
                <i className="fa-solid fa-circle-plus" /> Publicar actividad validada
              </button>
            )}

            {currentUser.tipo === 'moderador' && (
              <button
                onClick={() => setCurrentView('moderacion')}
                className="pill-btn px-4 py-2 text-xs sm:text-sm bg-purple-700 text-white hover:bg-purple-800 flex items-center gap-2 flex-shrink-0 font-bold ml-auto shadow-sm cursor-pointer"
              >
                <i className="fa-solid fa-shield-halved" /> Panel de Administración{' '}
                <span className="bg-amber-400 text-purple-900 font-black text-xs px-2 py-0.5 rounded-full">
                  {pendingActivities.length}
                </span>
              </button>
            )}
          </div>
        )}
      </nav>

      {/* CONTENEDOR PRINCIPAL */}
      <main className="max-w-5xl mx-auto px-4 pt-6 flex-1 w-full space-y-6">
        {/* CARTEL DE CONTEXTO */}
        {currentUser && (
          <div className="p-4 rounded-2xl bg-amber-100/80 border-2 border-amber-300 text-club-brown flex items-center gap-3 text-sm">
            <div className="w-10 h-10 rounded-full bg-club-orange/20 text-club-orange flex items-center justify-center text-lg font-bold flex-shrink-0">
              {currentUser.tipo === 'institucional' ? (
                <i className="fa-solid fa-landmark text-blue-700" />
              ) : currentUser.tipo === 'moderador' ? (
                <i className="fa-solid fa-shield-halved text-purple-700" />
              ) : (
                <i className="fa-solid fa-user" />
              )}
            </div>
            <div>
              <p className="font-bold text-base">
                Estás navegando como: {currentUser.apodo}{' '}
                {currentUser.isVerified && <i className="fa-solid fa-circle-check text-blue-600 text-xs ml-1" />}{' '}
                ({currentUser.tipo === 'institucional' ? 'Institución Verificada' : currentUser.tipo === 'moderador' ? 'Administrador' : 'Perfil Individual'})
              </p>
              <p className="text-xs text-club-brown/80">
                {currentUser.tipo === 'institucional'
                  ? 'Publicás talleres oficiales, supervisás tus actividades y chateás con tus vecinos.'
                  : currentUser.tipo === 'moderador'
                  ? 'Validás propuestas comunitarias, supervisás bajas y administrás la seguridad de la plataforma.'
                  : 'Accedé a preinscripciones, agendá encuentros y conversá con tus compañeros.'}
              </p>
            </div>
          </div>
        )}

        {/* HOME VISITANTE */}
        {(!currentUser || currentView === 'home-visitante') && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-12 border-2 border-amber-200 retro-shadow text-center space-y-6">
              <div className="max-w-2xl mx-auto space-y-3">
                <span className="text-xs font-bold tracking-widest uppercase bg-amber-100 text-club-brown px-3 py-1 rounded-full border border-amber-200">
                  Plataforma Vecinal para Mayores de 65 Años
                </span>
                <h1 className="font-brand text-3xl sm:text-4xl font-bold text-club-brown">
                  Conectá con personas de tu edad a través de actividades en tu barrio
                </h1>
                <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
                  Talleres de movimiento, estimulación cognitiva, mateadas, tejido y paseos al aire libre organizados por tus vecinos e instituciones verificadas.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
                <button
                  onClick={() => setCurrentView('explorar')}
                  className="pill-btn px-6 py-3.5 bg-club-orange hover:bg-club-orange-dark text-white font-bold text-sm shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <i className="fa-solid fa-compass" /> Explorar actividades disponibles
                </button>
                <button
                  onClick={() => setModalRegisterOpen(true)}
                  className="pill-btn px-6 py-3.5 bg-club-teal hover:bg-club-teal/80 text-white font-bold text-sm shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <i className="fa-solid fa-user-plus" /> Registrarme gratis
                </button>
                <button
                  onClick={() => setModalLoginOpen(true)}
                  className="pill-btn px-6 py-3.5 bg-white hover:bg-amber-50 text-club-brown border-2 border-amber-300 font-bold text-sm flex items-center gap-2 cursor-pointer"
                >
                  <i className="fa-solid fa-right-to-bracket" /> Iniciar sesión
                </button>
              </div>
            </div>
          </section>
        )}

        {/* 1. VISTA EXPLORAR ACTIVIDADES */}
        {currentView === 'explorar' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-5 border border-amber-200/80 retro-shadow">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <i className="fa-solid fa-magnifying-glass absolute left-4 top-3.5 text-amber-800/40 text-lg" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscá por actividad, lugar o temática (ej: memoria, elongación)..."
                    className="w-full pl-12 pr-4 py-3 bg-amber-50/50 border border-amber-200 rounded-full text-club-brown placeholder-amber-800/40 text-base focus:outline-none focus:ring-2 focus:ring-club-orange"
                  />
                </div>
                <div className="flex gap-2 overflow-x-auto pb-1 md:pb-0 scrollbar-thin">
                  <button
                    onClick={() => setCurrentCategory('todas')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'todas'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Todas
                  </button>
                  <button
                    onClick={() => setCurrentCategory('salud')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'salud'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Salud y Movimiento
                  </button>
                  <button
                    onClick={() => setCurrentCategory('cultura')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'cultura'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Cultura y Arte
                  </button>
                  <button
                    onClick={() => setCurrentCategory('social')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'social'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Juegos y Mateadas
                  </button>
                  <button
                    onClick={() => setCurrentCategory('musica')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'musica'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Música y Baile
                  </button>
                  <button
                    onClick={() => setCurrentCategory('tecnologia')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'tecnologia'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Tecnología
                  </button>
                  <button
                    onClick={() => setCurrentCategory('memoria')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'memoria'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Memoria
                  </button>
                  <button
                    onClick={() => setCurrentCategory('naturaleza')}
                    className={`cat-pill px-4 py-2 rounded-full font-bold text-xs sm:text-sm whitespace-nowrap cursor-pointer transition ${
                      currentCategory === 'naturaleza'
                        ? 'bg-club-brown text-white shadow-xs'
                        : 'bg-amber-100 text-club-brown hover:bg-amber-200'
                    }`}
                  >
                    Naturaleza y Paseos
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-brand text-2xl sm:text-3xl font-bold text-club-brown">
                  Actividades Disponibles
                </h2>
                <p className="text-sm text-club-brown/70">
                  Talleres deportivos, culturales y salidas barriales para adultos mayores
                </p>
              </div>
              <span className="text-xs font-bold bg-amber-200/60 px-3 py-1.5 rounded-full text-club-brown">
                {filteredActivities.length} disponibles
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredActivities.map((act) => {
                const isUserEnrolled = currentUser ? act.enrolledUsernames?.includes(currentUser.usuario) : false;
                const isUserOrganizer = currentUser ? (act.organizerId === currentUser.id || (currentUser.tipo === 'personal' && act.organizerId === 'personal')) : false;
                const inscriptosAct = act.enrolledUsernames ? act.enrolledUsernames.length : act.enrolledCount;
                const cuposLibresAct = Math.max(0, act.capacity - inscriptosAct);

                return (
                  <div
                    key={act.id}
                    className="bg-white rounded-3xl border border-amber-200 overflow-hidden retro-shadow flex flex-col justify-between"
                  >
                    <div>
                      <div className="relative h-48 overflow-hidden bg-amber-100">
                        <img
                          src={act.image}
                          alt={act.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop';
                          }}
                        />
                        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                          {act.isInstitutional ? (
                            <span className="bg-blue-100 text-blue-900 border border-blue-200 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5">
                              <i className="fa-solid fa-circle-check text-blue-600" /> Institución Verificada
                            </span>
                          ) : isUserOrganizer ? (
                            <span className="bg-amber-200 text-amber-950 border border-amber-400 text-xs font-black px-3 py-1 rounded-full flex items-center gap-1.5">
                              <i className="fa-solid fa-star text-club-orange" /> Tu Iniciativa Aprobada
                            </span>
                          ) : (
                            <span className="bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5">
                              <i className="fa-solid fa-users text-club-orange" /> Actividad de la comunidad
                            </span>
                          )}

                          <span
                            className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border shadow-xs ${
                              act.isRecurrent
                                ? 'bg-amber-100 text-amber-900 border-amber-300'
                                : 'bg-purple-100 text-purple-900 border-purple-200'
                            }`}
                          >
                            <i className={`fa-solid ${act.isRecurrent ? 'fa-repeat text-club-orange' : 'fa-calendar-day text-purple-700'} mr-1`} />
                            {act.isRecurrent ? 'Encuentro recurrente' : 'Encuentro único'}
                          </span>
                        </div>

                        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2.5 py-1 rounded-full font-bold">
                          <i className="fa-solid fa-clock" /> {act.schedule}
                        </div>
                      </div>

                      <div className="p-5 space-y-3">
                        <h3 className="font-brand text-xl font-bold text-club-brown">{act.title}</h3>
                        <div className="text-xs font-semibold text-club-brown/80 bg-amber-50 p-2.5 rounded-xl border border-amber-200/60 flex items-center gap-2">
                          <i className="fa-solid fa-location-dot text-club-orange" />
                          <span>
                            {didOtherBlockMe(act.organizer)
                              ? 'El organizador te ha bloqueado'
                              : didIBlockUser(act.organizer) || isUserBlocked(act.organizer)
                              ? 'Desbloqueá al organizador para ver ubicación'
                              : act.location}
                          </span>
                        </div>
                        {/* Caratula de la actividad en Cartelera muestra el Avance Corto */}
                        <p className="text-xs text-stone-600 line-clamp-2">
                          {act.shortDescription || act.description}
                        </p>
                      </div>
                    </div>

                    <div className="p-4 bg-amber-50/50 border-t border-amber-100 flex items-center justify-between gap-2 flex-wrap">
                      <div>
                        {isUserOrganizer ? (
                          <span className="text-xs font-bold text-club-orange flex items-center gap-1">
                            <i className="fa-solid fa-user-gear" /> Tu Encuentro ({inscriptosAct}/{act.capacity})
                          </span>
                        ) : isUserEnrolled ? (
                          <span className="text-emerald-700 font-black text-xs flex items-center gap-1">
                            <i className="fa-solid fa-circle-check" /> Inscripta/o ({inscriptosAct}/{act.capacity})
                          </span>
                        ) : (
                          <span className="text-xs font-bold text-stone-500">
                            Cupo: {cuposLibresAct} vacantes de {act.capacity}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 ml-auto">
                        {isUserOrganizer && currentUser?.tipo === 'personal' && (
                          <button
                            onClick={() => setModalModeracionActividadId(act.id)}
                            className="pill-btn px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-club-brown text-xs font-bold border border-amber-300 flex items-center gap-1 cursor-pointer"
                          >
                            <i className="fa-solid fa-sliders text-club-orange" /> Moderar mi actividad
                          </button>
                        )}
                        <button
                          onClick={() => setModalDetalleId(act.id)}
                          className="pill-btn px-4 py-2 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-sm cursor-pointer"
                        >
                          Ver Detalle y Mapa
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* 2. VISTA MI AGENDA */}
        {currentView === 'agenda' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-100 pb-4">
                <div>
                  <h2 className="font-brand text-2xl sm:text-3xl font-bold text-club-brown flex items-center gap-2">
                    <i className="fa-solid fa-calendar-days text-club-orange" /> Tu Calendario de Encuentros
                  </h2>
                  <p className="text-sm text-club-brown/80 mt-1">
                    Días y horarios de las actividades donde ya estás inscripta/o o que organizás.
                  </p>
                </div>
                <span className="text-sm font-bold bg-club-orange/10 text-club-orange px-4 py-2 rounded-full">
                  {calNombreMesAno}
                </span>
              </div>

              <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 bg-amber-50/70 p-4 rounded-2xl border border-amber-200/70">
                  <div className="text-center font-bold text-club-brown mb-3 flex items-center justify-between px-2">
                    <button
                      onClick={() => {
                        if (calMesActual === 0) {
                          setCalMesActual(11);
                          setCalAnoActual(prev => prev - 1);
                        } else {
                          setCalMesActual(prev => prev - 1);
                        }
                      }}
                      className="w-8 h-8 rounded-full bg-white hover:bg-amber-100 text-club-brown flex items-center justify-center transition border border-amber-200 cursor-pointer"
                    >
                      <i className="fa-solid fa-chevron-left text-xs" />
                    </button>
                    <span className="font-brand text-lg text-club-brown">{calNombreMesAno}</span>
                    <button
                      onClick={() => {
                        if (calMesActual === 11) {
                          setCalMesActual(0);
                          setCalAnoActual(prev => prev + 1);
                        } else {
                          setCalMesActual(prev => prev + 1);
                        }
                      }}
                      className="w-8 h-8 rounded-full bg-white hover:bg-amber-100 text-club-brown flex items-center justify-center transition border border-amber-200 cursor-pointer"
                    >
                      <i className="fa-solid fa-chevron-right text-xs" />
                    </button>
                  </div>

                  <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-club-brown/60 mb-2">
                    <span>Lu</span><span>Ma</span><span>Mi</span><span>Ju</span><span>Vi</span><span>Sá</span><span>Do</span>
                  </div>

                  <div className="grid grid-cols-7 gap-1 text-center text-sm font-semibold">
                    {Array.from({ length: offsetLunes }).map((_, i) => (
                      <span key={`prev-${i}`} className="p-2 text-stone-300 text-xs">
                        {diasMesAnterior - offsetLunes + 1 + i}
                      </span>
                    ))}

                    {Array.from({ length: totalDiasMes }).map((_, i) => {
                      const d = i + 1;
                      const actTooltip = (calAnoActual === 2026 && calMesActual === 9) ? actividadesOctubreMap[d] : undefined;

                      if (actTooltip) {
                        return (
                          <span
                            key={`d-${d}`}
                            className="p-1.5 bg-club-orange text-white rounded-full font-bold text-xs shadow-sm cursor-pointer transition hover:scale-110 flex items-center justify-center"
                            title={actTooltip}
                          >
                            {d}
                          </span>
                        );
                      }
                      return (
                        <span key={`d-${d}`} className="p-1.5 hover:bg-amber-100 rounded-full cursor-pointer text-xs flex items-center justify-center">
                          {d}
                        </span>
                      );
                    })}
                  </div>

                  <div className="mt-4 pt-3 border-t border-amber-200 text-[11px] text-stone-500 flex items-center gap-2">
                    <span className="w-3.5 h-3.5 rounded-full bg-club-orange inline-block" />
                    <span>Pasá el cursor sobre el día marcado para ver la actividad</span>
                  </div>
                </div>

                <div className="lg:col-span-2 space-y-4">
                  {agendaActivities.length === 0 ? (
                    <p className="text-xs text-stone-500 py-6 text-center">
                      No hay actividades programadas en tu agenda.
                    </p>
                  ) : (
                    agendaActivities.map((act) => (
                      <div
                        key={act.id}
                        className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div>
                          <span className="text-[11px] font-bold uppercase bg-amber-200 text-club-brown px-2 py-0.5 rounded-full">
                            {act.organizerId === currentUser?.id || act.organizerId === 'personal'
                              ? 'Organizado por vos'
                              : 'Próximo Encuentro'}
                          </span>
                          <h4 className="font-bold text-base text-club-brown mt-1">{act.title}</h4>
                          <p className="text-xs text-stone-600">
                            {act.schedule} • {act.location}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setModalDetalleId(act.id)}
                            className="pill-btn px-4 py-2 bg-white hover:bg-amber-100 border border-amber-300 text-club-brown text-xs font-bold shadow-xs cursor-pointer"
                          >
                            Ver detalles de la Actividad
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* 3. VISTA MIS ACTIVIDADES */}
        {currentView === 'mis-actividades' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow space-y-6">
              <div className="border-b border-amber-100 pb-3">
                <h2 className="font-brand text-2xl sm:text-3xl font-bold text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-list-check text-club-orange" /> Mis Actividades
                </h2>
                <p className="text-xs text-stone-600">
                  {currentUser?.tipo === 'institucional'
                    ? 'Supervisá tus talleres vigentes y analizá las valoraciones y fotos de talleres finalizados.'
                    : 'Supervisá las actividades comunitarias que propusiste y su estado de aprobación.'}
                </p>
              </div>

              {/* Vista Institucional */}
              {currentUser?.tipo === 'institucional' && (
                <div className="space-y-4">
                  <div className="flex bg-amber-50 p-1.5 rounded-2xl border border-amber-200 max-w-md">
                    <button
                      onClick={() => setSubTabMisActividades('moderar')}
                      className={`flex-1 py-2 text-xs font-bold rounded-xl cursor-pointer ${
                        subTabMisActividades === 'moderar'
                          ? 'bg-club-orange text-white shadow-xs'
                          : 'text-club-brown hover:text-club-orange'
                      }`}
                    >
                      Moderar mis actividades
                    </button>
                    <button
                      onClick={() => setSubTabMisActividades('realizadas')}
                      className={`flex-1 py-2 text-xs font-bold rounded-xl cursor-pointer ${
                        subTabMisActividades === 'realizadas'
                          ? 'bg-club-orange text-white shadow-xs'
                          : 'text-club-brown hover:text-club-orange'
                      }`}
                    >
                      Actividades realizadas (reseñas)
                    </button>
                  </div>

                  {subTabMisActividades === 'moderar' && (
                    <div className="space-y-4">
                      {activities.filter(a => a.organizerId === 'institucional' || a.organizerId === currentUser?.id).map(act => (
                        <div
                          key={act.id}
                          className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full">
                                Taller en curso
                              </span>
                              <span className="text-xs text-stone-500">{act.schedule}</span>
                            </div>
                            <h3 className="font-bold text-base text-club-brown">{act.title}</h3>
                            <p className="text-xs text-stone-600">
                              <strong>Inscriptos:</strong> {act.enrolledCount} de {act.capacity} (
                              {Math.max(0, act.capacity - act.enrolledCount)} cupos libres) • <strong>Lugar:</strong>{' '}
                              {act.location}
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <button
                              onClick={() => setModalInscriptosId(act.id)}
                              className="pill-btn px-3.5 py-1.5 bg-club-blue text-club-brown text-xs font-bold hover:bg-club-teal hover:text-white border border-club-teal/30 cursor-pointer"
                            >
                              <i className="fa-solid fa-users text-club-orange mr-1" /> Ver Inscriptos ({act.enrolledCount})
                            </button>
                            <button
                              onClick={() =>
                                setModalConfirmarCancelacion({
                                  nombre: act.title,
                                  dia: act.schedule,
                                  hora: '',
                                  tipo: 'institucional'
                                })
                              }
                              className="pill-btn px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                            >
                              <i className="fa-solid fa-ban text-rose-600 mr-1" /> Cancelar actividad
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {subTabMisActividades === 'realizadas' && (
                    <div className="space-y-4">
                      <div className="p-5 bg-amber-50/40 rounded-2xl border border-amber-200 space-y-4">
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-amber-200/80 pb-3 gap-2">
                          <div>
                            <span className="text-[10px] font-bold bg-stone-200 text-stone-700 px-2 py-0.5 rounded-full">
                              Actividad finalizada • 16 de Septiembre 2026
                            </span>
                            <h3 className="font-bold text-lg text-club-brown mt-1">
                              Gimnasia Adaptada y Ritmos Latinos (CEDEM 1)
                            </h3>
                            <p className="text-xs text-stone-500">Concluyó con 30 participantes.</p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center gap-1 text-amber-500 font-bold text-base justify-end">
                              <i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star-half-stroke" />
                              <span className="text-xs text-club-brown font-extrabold ml-1">4.8 / 5.0</span>
                            </div>
                            <span className="text-xs text-club-orange font-bold">24 reseñas</span>
                          </div>
                        </div>

                        <div className="flex justify-between items-center bg-white p-3.5 rounded-2xl border border-amber-200">
                          <div className="text-xs">
                            <p className="font-bold text-club-brown">
                              <i className="fa-solid fa-camera-retro text-club-orange mr-1" /> Fotos y videos aportados por los vecinos (24)
                            </p>
                            <p className="text-[11px] text-stone-500">
                              Aportados por los propios participantes en sus reseñas.
                            </p>
                          </div>
                          <button
                            onClick={() => setModalOpinionesId(1)}
                            className="pill-btn px-4 py-2 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-sm cursor-pointer"
                          >
                            Ver opiniones y fotos
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Vista Personal */}
              {currentUser?.tipo === 'personal' && (
                <div className="space-y-4">
                  {/* Approved personal activities organized by user */}
                  {activities.filter(a => a.isApproved && (a.organizerId === currentUser.id || (a.id === 10 && currentUser.usuario === 'carola'))).map(act => (
                    <div
                      key={act.id}
                      className="p-4 bg-amber-50/80 rounded-2xl border-2 border-amber-300 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
                    >
                      <div>
                        <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full uppercase">
                          Aprobada y Publicada ✓
                        </span>
                        <h4 className="font-bold text-base text-club-brown mt-1">{act.title}</h4>
                        <p className="text-xs text-stone-600">
                          {act.schedule} • {act.location} • Inscriptos: {act.enrolledUsernames ? act.enrolledUsernames.length : act.enrolledCount}/{act.capacity}
                        </p>
                      </div>
                      <button
                        onClick={() => setModalModeracionActividadId(act.id)}
                        className="pill-btn px-4 py-2 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold shadow-sm cursor-pointer"
                      >
                        <i className="fa-solid fa-sliders mr-1" /> Moderar mi actividad
                      </button>
                    </div>
                  ))}

                  {/* Pending personal activities (in revision & with requested changes) */}
                  {activities.filter(a => !a.isApproved && a.proposalStatus !== 'aprobada' && (
                    a.organizerId === currentUser.id ||
                    a.organizer === currentUser.apodo ||
                    a.organizer === currentUser.usuario ||
                    a.organizerId === 'personal' ||
                    (currentUser.usuario === 'carola' && (a.id === 10 || a.id === 204))
                  )).map(p => (
                    <div key={p.id} className="p-4 bg-amber-100/60 rounded-2xl border-2 border-amber-300 space-y-2.5 shadow-xs animate-in fade-in">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-black bg-amber-300 text-amber-950 px-2.5 py-0.5 rounded-full uppercase">
                          ⏳ Aprobación pendiente
                        </span>
                        {p.changesSubmittedAt ? (
                          <span className="text-[10px] font-black bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full uppercase flex items-center gap-1 border border-emerald-300 shadow-xs">
                            <i className="fa-solid fa-check" /> Modificaciones enviadas a revisión
                          </span>
                        ) : p.proposalStatus === 'cambios_solicitados' ? (
                          <span className="text-[10px] font-black bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full uppercase flex items-center gap-1 border border-rose-300 shadow-xs">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-600 animate-pulse" />
                            <i className="fa-solid fa-bell text-rose-600" /> Modificaciones solicitadas
                          </span>
                        ) : null}
                        <span className="text-xs font-bold text-amber-900">En revisión de seguridad</span>
                      </div>
                      <h4 className="font-bold text-base text-club-brown">{p.title}</h4>
                      <p className="text-xs text-stone-600">{p.schedule} • {p.location}</p>
                      
                      <div className="p-3 bg-white/80 rounded-xl border border-amber-200 text-xs text-amber-900 font-semibold flex items-center gap-2">
                        <i className="fa-solid fa-circle-exclamation text-club-orange text-sm flex-shrink-0" />
                        <span>Esta actividad no estará disponible en la Cartelera hasta que sea aprobada.</span>
                      </div>

                      {p.changesSubmittedAt ? (
                        <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900 font-semibold flex items-center gap-2">
                          <i className="fa-solid fa-clock-rotate-left text-emerald-600 text-sm flex-shrink-0" />
                          <span>Tus modificaciones fueron enviadas ({p.changesSubmittedAt}). La propuesta está en revisión del Administrador Oficial.</span>
                        </div>
                      ) : p.proposalStatus === 'cambios_solicitados' ? (
                        <div className="p-3.5 bg-white rounded-xl border-2 border-rose-300 text-xs text-amber-950 space-y-2.5 shadow-xs">
                          <div className="flex items-center gap-1.5 font-bold text-rose-700">
                            <i className="fa-solid fa-comment-dots" /> Modificaciones solicitadas por el Administrador Oficial:
                          </div>
                          <p className="italic text-stone-700 font-medium">
                            "{p.proposalNote || 'Por favor revisá los detalles del punto de encuentro y los cupos asignados antes de la aprobación final.'}"
                          </p>
                          <div className="flex justify-end pt-1">
                            <button
                              onClick={() => {
                                setEditingProposalActivityId(p.id);
                                setUserFeedbackInput('');
                                setEventoForm({
                                  nombre: p.title,
                                  avance: p.shortDescription || p.title,
                                  categoria: p.category,
                                  frecuencia: p.isRecurrent ? 'recurrente' : 'unico',
                                  fechaIni: '2026-10-26',
                                  horaIni: '18:00',
                                  fechaFin: '2026-10-26',
                                  horaFin: '20:00',
                                  direccion: p.location,
                                  lat: p.lat || -34.6068,
                                  lng: p.lng || -58.5647,
                                  tipoCupo: p.capacity < 900 ? 'limitado' : 'ilimitado',
                                  cupoMax: p.capacity < 900 ? p.capacity : 20,
                                  descripcion: p.description,
                                  imagen: p.image
                                });
                                setEventoTipoCreacion('personal');
                                setModalCrearEventoOpen(true);
                              }}
                              className="pill-btn px-4 py-2 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold shadow-sm flex items-center gap-1.5 cursor-pointer"
                            >
                              <i className="fa-solid fa-pen" /> Modificar y reenviar propuesta
                            </button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* 4. VISTA MI CHAT */}
        {currentView === 'chat' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl border border-amber-200 retro-shadow overflow-hidden flex flex-col md:flex-row h-[620px]">
              {/* Sidebar */}
              <div className="w-full md:w-80 border-r border-amber-200/80 bg-amber-50/40 flex flex-col">
                <div className="p-4 border-b border-amber-200/80 space-y-2.5">
                  <h3 className="font-brand text-xl font-bold text-club-brown">Mi Chat</h3>

                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      onClick={() => setModalCrearGrupoOpen(true)}
                      className="p-2 bg-white hover:bg-amber-100 border border-amber-200 rounded-xl text-[11px] font-bold text-club-brown flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <i className="fa-solid fa-users text-club-orange" /> Crear Grupo
                    </button>
                    <button
                      onClick={() => setModalDirectorioOpen(true)}
                      className="p-2 bg-white hover:bg-amber-100 border border-amber-200 rounded-xl text-[11px] font-bold text-club-brown flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <i className="fa-solid fa-address-book text-club-teal" /> Mis Contactos
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-amber-100/80">
                  {chats.length === 0 ? (
                    <p className="p-4 text-xs text-stone-400 text-center">No tenés conversaciones activas.</p>
                  ) : (
                    chats.map((c) => {
                      const lastMsg = c.messages[c.messages.length - 1] || { text: 'Sin mensajes', time: '' };
                      const isCurrent = c.id === activeChatId;
                      const cDisplayTitle = getChatDisplayTitle(c, currentUser);
                      const cPhoto = getChatDisplayPhoto(c);

                      return (
                        <div
                          key={c.id}
                          onClick={() => setActiveChatId(c.id)}
                          className={`p-3.5 hover:bg-amber-100/60 cursor-pointer transition flex items-center gap-3 ${
                            isCurrent ? 'bg-amber-100/70 border-l-4 border-club-orange' : ''
                          }`}
                        >
                          <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 overflow-hidden ${
                              c.type === 'grupal' ? 'bg-club-orange text-white' : 'bg-club-blue text-club-brown'
                            }`}
                          >
                            {cPhoto ? (
                              <img src={cPhoto} alt={cDisplayTitle} className="w-full h-full object-cover aspect-square rounded-full" />
                            ) : c.type === 'grupal' ? (
                              <i className="fa-solid fa-users" />
                            ) : (
                              cDisplayTitle.charAt(0)
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-baseline mb-0.5">
                              <div className="flex items-center gap-1.5 truncate">
                                <h5 className="font-bold text-xs text-club-brown truncate">{cDisplayTitle}</h5>
                                <span className={`font-bold text-[9px] px-1.5 py-0.2 rounded-md ${
                                  c.type === 'grupal' ? 'bg-orange-100 text-club-orange' : 'bg-blue-100 text-blue-800'
                                }`}>
                                  {c.type === 'grupal' ? 'Grupo' : 'Privado'}
                                </span>
                              </div>
                              <span className="text-[10px] text-stone-400 flex-shrink-0 ml-1">{lastMsg.time}</span>
                            </div>
                            <p className="text-[11px] text-stone-500 truncate">
                              {lastMsg.sender}: {lastMsg.text}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Chat View Area */}
              <div className="flex-1 flex flex-col bg-club-cream relative">
                {!activeChat ? (
                  <div className="absolute inset-0 bg-[#FBF7F0] flex flex-col items-center justify-center p-6 text-center z-10 space-y-4">
                    <div className="w-24 h-24 rounded-full bg-amber-100/80 flex items-center justify-center border-2 border-amber-200 shadow-inner">
                      <img
                        src="/assets/aistudio/ISOLOGO_5e044cb6.png"
                        alt="Club65"
                        className="w-14 h-14 object-contain"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>
                    <div className="max-w-sm space-y-1">
                      <h4 className="font-brand text-2xl font-bold text-club-brown">CLUB65 Conectando Experiencias</h4>
                      <p className="text-xs text-stone-500">
                        Seleccioná una conversación a la izquierda o comunicate con tus grupos de actividades barriales.
                      </p>
                    </div>
                    <span className="text-[11px] text-club-orange font-bold bg-amber-100/60 px-3 py-1 rounded-full border border-amber-200">
                      <i className="fa-solid fa-lock text-[10px] mr-1" /> Mensajes seguros entre vecinos e instituciones
                    </span>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col h-full">
                    <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-11 h-11 rounded-full flex items-center justify-center font-bold text-lg shadow-sm flex-shrink-0 overflow-hidden ${
                            activeChat.type === 'grupal' ? 'bg-club-orange text-white' : 'bg-club-blue text-club-brown'
                          }`}
                        >
                          {getChatDisplayPhoto(activeChat) ? (
                            <img src={getChatDisplayPhoto(activeChat)} alt={getChatDisplayTitle(activeChat, currentUser)} className="w-full h-full object-cover aspect-square rounded-full" />
                          ) : activeChat.type === 'grupal' ? (
                            <i className="fa-solid fa-users" />
                          ) : (
                            getChatDisplayTitle(activeChat, currentUser).charAt(0)
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-base text-club-brown">{getChatDisplayTitle(activeChat, currentUser)}</h4>
                          </div>
                          <p className="text-xs">
                            {activeChat.type === 'grupal' ? (
                              <button
                                onClick={() => setModalVerParticipantesOpen(true)}
                                className="text-club-teal hover:underline font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <i className="fa-solid fa-users-viewfinder" /> Ver participantes ({activeChat.participants?.length || 1})
                              </button>
                            ) : (
                              <span className="text-stone-400">Chat privado directo</span>
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Ver perfil option in direct private chats */}
                        {activeChat.type === 'privado' && (
                          <button
                            onClick={() => {
                              const activeDisplayTitle = getChatDisplayTitle(activeChat, currentUser);
                              const contact = contacts.find(c => c.nombre.toLowerCase() === activeDisplayTitle.toLowerCase()) || {
                                id: `priv_${activeChat.id}`,
                                nombre: activeDisplayTitle,
                                detalle: 'Contacto privado',
                                avatar: activeDisplayTitle.slice(0, 2).toUpperCase(),
                                avatarClass: 'bg-club-blue',
                                bio: 'Miembro de la comunidad de CLUB65.',
                                foto: getUserPhotoByName(activeDisplayTitle)
                              };
                              setModalPerfilContacto(contact);
                            }}
                            className="text-xs font-bold bg-white hover:bg-amber-50 text-club-brown px-3 py-1.5 rounded-full border border-amber-300 flex items-center gap-1.5 shadow-xs cursor-pointer"
                          >
                            <i className="fa-solid fa-user text-club-orange" /> Ver perfil
                          </button>
                        )}

                        {activeChat.activityId && (
                          <button
                            onClick={() => setModalDetalleId(activeChat.activityId!)}
                            className="text-xs font-bold bg-white hover:bg-amber-50 text-club-brown px-3 py-1.5 rounded-full border border-amber-200 flex items-center gap-1.5 shadow-xs cursor-pointer"
                          >
                            <i className="fa-solid fa-circle-info text-club-orange" /> Ver detalles de la Actividad
                          </button>
                        )}

                        {activeChat.type === 'grupal' && currentUser && (
                          currentUser.tipo === 'moderador' ||
                          activeChat.creatorId === currentUser.id ||
                          activeChat.organizerId === currentUser.id ||
                          activeChat.adminUsernames?.includes(currentUser.apodo) ||
                          activeChat.adminUsernames?.includes(currentUser.usuario)
                        ) && (
                          <button
                            onClick={() => setModalModerarGrupoOpen(true)}
                            className="text-xs font-bold bg-amber-100 hover:bg-amber-200 text-club-brown px-3 py-1.5 rounded-full border border-amber-300 flex items-center gap-1.5 shadow-xs cursor-pointer"
                          >
                            <i className="fa-solid fa-gear text-club-orange" /> Moderar grupo
                          </button>
                        )}

                        {activeChat.type === 'grupal' && (
                          <button
                            onClick={handleSalirGrupoActivo}
                            className="text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 px-3 py-1.5 rounded-full border border-rose-200 flex items-center gap-1 cursor-pointer"
                          >
                            <i className="fa-solid fa-right-from-bracket" /> Salir del grupo
                          </button>
                        )}
                      </div>
                    </div>

                    {/* PINNED MESSAGE BANNER */}
                    {activeChat.pinnedMessageId && (() => {
                      const pinned = activeChat.messages.find(m => m.id === activeChat.pinnedMessageId);
                      if (!pinned || pinned.isDeleted || pinned.deletedByAdmin) return null;
                      return (
                        <div
                          onClick={() => {
                            const elem = document.getElementById(`msg-${pinned.id}`);
                            if (elem) {
                              elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
                              elem.classList.add('ring-4', 'ring-amber-400', 'rounded-2xl', 'transition-all');
                              setTimeout(() => {
                                elem.classList.remove('ring-4', 'ring-amber-400');
                              }, 2500);
                            }
                          }}
                          className="bg-amber-100/95 hover:bg-amber-200/90 border-b border-amber-300 px-4 py-2 flex items-center justify-between text-xs text-club-brown shadow-xs animate-in fade-in cursor-pointer"
                          title="Hacé clic para ver el mensaje fijado en la conversación"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <i className="fa-solid fa-thumbtack text-club-orange" />
                            <span className="font-bold text-amber-900">Mensaje fijado:</span>
                            <span className="truncate italic text-stone-700">"{pinned.text}"</span>
                          </div>
                          {isCurrentUserModeratorOfActiveChat && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handlePinChatMessage(pinned.id || '');
                              }}
                              className="text-[11px] text-amber-900 hover:text-rose-700 font-bold ml-2 cursor-pointer underline flex-shrink-0"
                            >
                              Desfijar
                            </button>
                          )}
                        </div>
                      );
                    })()}

                    <div className="flex-1 p-4 overflow-y-auto space-y-3">
                      {activeChat.messages.map((m, idx) => {
                        const esPropio = currentUser ? (m.senderId === currentUser.id || m.sender === currentUser.apodo || m.senderId === currentUser.usuario) : false;

                        let bubbleBg = '';
                        let align = '';

                        if (m.isDeleted || m.deletedByAdmin) {
                          align = esPropio ? 'ml-auto flex-row-reverse' : 'max-w-[85%]';
                          bubbleBg = 'bg-stone-100 text-stone-500 border border-stone-300';
                        } else if (esPropio) {
                          align = 'ml-auto flex-row-reverse';
                          bubbleBg = currentUser?.tipo === 'institucional' ? 'bg-club-teal text-white' : 'bg-club-orange text-white';
                        } else if (m.role === 'institucional' || m.role === 'inst') {
                          align = 'max-w-[85%]';
                          bubbleBg = 'bg-amber-100 text-club-brown border border-amber-300';
                        } else {
                          align = 'max-w-[85%]';
                          bubbleBg = 'bg-white text-club-brown border border-amber-200/80';
                        }

                        // Retroactive author apodo for current user
                        const displayName = esPropio ? currentUser!.apodo : m.sender;
                        const isMsgAdmin = currentUser && (
                          currentUser.tipo === 'moderador' ||
                          activeChat.creatorId === currentUser.id ||
                          activeChat.organizerId === currentUser.id ||
                          activeChat.adminUsernames?.includes(currentUser.apodo) ||
                          activeChat.adminUsernames?.includes(currentUser.usuario)
                        );
                        const msgKey = m.id || `msg_${idx}`;
                        const isDeleted = m.isDeleted || m.deletedByAdmin;

                        const senderPhoto = getUserPhotoByName(esPropio ? currentUser?.apodo : m.sender);

                        return (
                          <div key={idx} id={`msg-${m.id}`} className={`flex items-start gap-2.5 ${align}`}>
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 overflow-hidden ${
                                esPropio ? 'bg-club-orange text-white' : 'bg-club-blue text-club-brown'
                              }`}
                            >
                              {senderPhoto ? (
                                <img src={senderPhoto} alt={displayName} className="w-full h-full object-cover rounded-full" />
                              ) : (
                                esPropio ? displayName.charAt(0) : m.avatar
                              )}
                            </div>
                            <div className={`${bubbleBg} p-3 rounded-2xl ${esPropio ? 'rounded-tr-none' : 'rounded-tl-none'} text-sm shadow-xs relative min-w-[130px]`}>
                              <div className="flex justify-between items-start gap-2 mb-0.5">
                                <p className="font-bold text-[11px] opacity-90 flex items-center gap-1">
                                  {displayName}
                                  {(m.isOrganizer || (activeChat.creatorId === m.senderId) || (activeChat.creatorName === displayName) || (activeChat.adminUsernames?.includes(displayName))) && (
                                    <span className="bg-amber-200 text-amber-950 font-black px-1.5 py-0.2 rounded-full text-[9px] ml-1">
                                      👑 Admin
                                    </span>
                                  )}
                                  {m.isVerifiedInst && (
                                    <i className="fa-solid fa-circle-check text-blue-600 text-[10px] ml-1" />
                                  )}
                                </p>

                                {/* Three dots options menu: only shown if message is NOT deleted */}
                                {!isDeleted && (
                                  <div className="relative">
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setOpenMessageMenuId(openMessageMenuId === msgKey ? null : msgKey);
                                      }}
                                      className="opacity-70 hover:opacity-100 p-0.5 rounded cursor-pointer leading-none text-xs"
                                      title="Opciones de mensaje"
                                    >
                                      <i className="fa-solid fa-ellipsis-vertical" />
                                    </button>

                                    {openMessageMenuId === msgKey && (
                                      <div className="absolute right-0 top-5 bg-white text-club-brown border border-amber-200 rounded-xl shadow-xl z-30 py-1 min-w-[160px] text-xs divide-y divide-amber-100">
                                        {/* Option: Responder (tipo WhatsApp) */}
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setOpenMessageMenuId(null);
                                            setReplyingToMessage({
                                              id: m.id || String(idx),
                                              sender: displayName,
                                              text: m.text
                                            });
                                          }}
                                          className="w-full px-3 py-1.5 text-left hover:bg-amber-50 font-bold flex items-center gap-1.5 text-stone-700 cursor-pointer"
                                        >
                                          <i className="fa-solid fa-reply text-club-teal text-[10px]" /> Responder
                                        </button>

                                        {/* Option: Fijar / Desfijar mensaje (solo administradores de grupo) */}
                                        {isMsgAdmin && activeChat.type === 'grupal' && (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setOpenMessageMenuId(null);
                                              handlePinChatMessage(m.id || String(idx));
                                            }}
                                            className="w-full px-3 py-1.5 text-left hover:bg-amber-50 font-bold flex items-center gap-1.5 text-amber-900 cursor-pointer"
                                          >
                                            <i className="fa-solid fa-thumbtack text-club-orange text-[10px]" />
                                            {activeChat.pinnedMessageId === (m.id || String(idx)) ? 'Desfijar mensaje' : 'Fijar mensaje'}
                                          </button>
                                        )}

                                        {/* Option: Reportar (NO mostrar para mensajes propios) */}
                                        {!esPropio && (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setOpenMessageMenuId(null);
                                              openReportModal({
                                                type: 'chat_message',
                                                chatId: activeChat.id,
                                                messageId: m.id || String(idx),
                                                messageText: m.text,
                                                reportedUser: displayName
                                              });
                                            }}
                                            className="w-full px-3 py-1.5 text-left hover:bg-amber-50 font-bold flex items-center gap-1.5 text-stone-700 cursor-pointer"
                                          >
                                            <i className="fa-solid fa-flag text-club-orange text-[10px]" /> Reportar
                                          </button>
                                        )}

                                        {/* Option: Eliminar mensaje por admin */}
                                        {isMsgAdmin && !m.isDeleted && (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setOpenMessageMenuId(null);
                                              setMessageToDelete({
                                                chatId: activeChat.id,
                                                messageId: m.id || String(idx),
                                                messageText: m.text,
                                                sender: displayName
                                              });
                                            }}
                                            className="w-full px-3 py-1.5 text-left hover:bg-rose-50 text-rose-700 font-bold flex items-center gap-1.5 cursor-pointer"
                                          >
                                            <i className="fa-solid fa-trash-can text-rose-600 text-[10px]" /> Eliminar mensaje
                                          </button>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>

                              {/* WhatsApp style Reply reference if present */}
                              {m.replyTo && (
                                <div className="mb-2 p-2 rounded-xl bg-black/10 border-l-4 border-amber-500 text-xs text-left">
                                  <p className="font-bold text-[10px] text-amber-900">{m.replyTo.sender}</p>
                                  <p className="line-clamp-1 italic text-[11px] opacity-90">{m.replyTo.text}</p>
                                </div>
                              )}

                              {isDeleted ? (
                                <p className="text-xs italic text-stone-500 py-1">
                                  Este mensaje ha sido retirado por el administrador del grupo
                                </p>
                              ) : (
                                <p className="text-xs font-medium leading-relaxed whitespace-pre-line">{m.text}</p>
                              )}
                              <span className="text-[9px] block text-right mt-1 opacity-70">{m.time}</span>
                            </div>
                          </div>
                        );
                      })}
                      <div ref={chatMessagesEndRef} />
                    </div>

                    <div className="p-3 bg-white border-t border-amber-200">
                      {/* WhatsApp-style Replying to Banner */}
                      {replyingToMessage && (
                        <div className="bg-amber-100/90 border border-amber-300 rounded-2xl p-2.5 mb-2 flex items-center justify-between text-xs animate-in fade-in">
                          <div className="border-l-4 border-club-orange pl-2.5">
                            <span className="font-bold text-club-brown block">Respondiendo a {replyingToMessage.sender}</span>
                            <span className="text-stone-600 truncate block max-w-md">{replyingToMessage.text}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setReplyingToMessage(null)}
                            className="text-stone-400 hover:text-stone-700 p-1 text-sm font-bold cursor-pointer"
                            title="Cancelar respuesta"
                          >
                            &times;
                          </button>
                        </div>
                      )}

                      {activeChat.type === 'privado' && isUserBlocked(activeChat.title) ? (
                        <div className="p-3 bg-rose-50 text-rose-700 text-xs font-semibold text-center rounded-2xl border border-rose-200">
                          <i className="fa-solid fa-ban text-rose-500 mr-1.5" />
                          No podés enviar mensajes a este usuario porque la comunicación está restringida.
                        </div>
                      ) : (
                        <form onSubmit={handleSendChatMessage} className="flex gap-2">
                          <input
                            type="text"
                            value={chatInputText}
                            onChange={(e) => setChatInputText(e.target.value)}
                            placeholder="Escribí un mensaje aquí con letra clara..."
                            className="flex-1 px-4 py-2.5 bg-amber-50/60 border border-amber-200 rounded-full text-club-brown focus:outline-none focus:ring-2 focus:ring-club-orange text-sm"
                          />
                          <button
                            type="submit"
                            className="pill-btn px-5 py-2.5 bg-club-orange text-white hover:bg-club-orange-dark flex items-center gap-2 text-sm shadow-sm cursor-pointer"
                          >
                            <span>Enviar</span>
                            <i className="fa-solid fa-paper-plane" />
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}

        {/* 5. VISTA COMUNIDAD DE WHATSAPP */}
        {currentView === 'whatsapp-comunidad' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200 retro-shadow space-y-6 max-w-2xl mx-auto">
              <div className="flex items-center gap-3 border-b border-amber-100 pb-4">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl flex-shrink-0">
                  <i className="fa-brands fa-whatsapp" />
                </div>
                <div>
                  <h2 className="font-brand text-2xl font-bold text-club-brown">Comunidad de WhatsApp</h2>
                  <p className="text-xs text-stone-600">Conectate con los grupos barriales y recibí avisos al instante en tu celular.</p>
                </div>
              </div>

              <div className="bg-amber-50/60 p-5 rounded-2xl border border-amber-200 space-y-3">
                <h3 className="font-bold text-sm text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-circle-check text-emerald-600" /> ¿Qué vas a encontrar en la comunidad?
                </h3>
                <ul className="text-xs space-y-2 text-club-brown/90">
                  <li className="flex items-start gap-2">
                    <i className="fa-solid fa-check text-emerald-600 mt-0.5" /> Avisos de nuevas actividades y talleres antes de que se agoten los cupos.
                  </li>
                  <li className="flex items-start gap-2">
                    <i className="fa-solid fa-check text-emerald-600 mt-0.5" /> Grupos organizados por localidades (Caseros, Ciudadela, Santos Lugares, Ciudad Jardín).
                  </li>
                  <li className="flex items-start gap-2">
                    <i className="fa-solid fa-check text-emerald-600 mt-0.5" /> Espacio moderado y cuidado exclusivo para miembros de CLUB65.
                  </li>
                </ul>
              </div>

              <div className="text-center pt-2">
                <a
                  href="https://chat.whatsapp.com/invite/club65-comunidad-demo"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="pill-btn inline-flex items-center gap-2.5 px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition"
                >
                  <i className="fa-brands fa-whatsapp text-lg" />
                  <span>Unirme a la Comunidad de WhatsApp</span>
                  <i className="fa-solid fa-arrow-up-right-from-square text-xs" />
                </a>
                <p className="text-[11px] text-stone-400 mt-2">Se abrirá la aplicación oficial de WhatsApp en tu dispositivo.</p>
              </div>
            </div>
          </section>
        )}

        {/* 6. VISTA MIS RESEÑAS */}
        {currentView === 'resenas' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow space-y-5">
              <div className="border-b border-amber-100 pb-3">
                <h2 className="font-brand text-2xl font-bold text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-star text-club-orange" /> Tus Reseñas y Experiencias
                </h2>
                <p className="text-xs text-stone-600">
                  Compartí tu opinión sobre actividades a las que fuiste o revisá qué opinan de tus encuentros.
                </p>
              </div>

              <div className="flex bg-amber-50 p-1.5 rounded-2xl border border-amber-200 max-w-md">
                <button
                  onClick={() => setSubTabResenas('mis-opiniones')}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl cursor-pointer ${
                    subTabResenas === 'mis-opiniones'
                      ? 'bg-club-orange text-white shadow-xs'
                      : 'text-club-brown hover:text-club-orange'
                  }`}
                >
                  Reseñas publicadas
                </button>
                <button
                  onClick={() => setSubTabResenas('actividades-organizadas')}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl cursor-pointer ${
                    subTabResenas === 'actividades-organizadas'
                      ? 'bg-club-orange text-white shadow-xs'
                      : 'text-club-brown hover:text-club-orange'
                  }`}
                >
                  Actividades realizadas (reseñas)
                </button>
              </div>

              {subTabResenas === 'mis-opiniones' && (
                <div className="space-y-4">
                  {/* Dynamic pending review prompt card */}
                  {(() => {
                    if (!currentUser) return null;
                    const pendingActivity = activities.find(a => {
                      const wasEnrolled = a.enrolledUsernames?.includes(currentUser.usuario) || a.enrolledUsernames?.includes(currentUser.apodo) || (currentUser.usuario === 'carola' && a.id === 3);
                      if (!wasEnrolled) return false;
                      const hasReviewed = reviews.some(r => r.actividadId === a.id && (
                        r.autor === currentUser.apodo ||
                        r.autor === currentUser.usuario ||
                        r.autor === 'Carola Márquez'
                      ));
                      return !hasReviewed;
                    });

                    if (!pendingActivity) return null;

                    return (
                      <div className="p-4 bg-orange-50/70 rounded-2xl border-2 border-dashed border-club-orange/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 animate-in fade-in">
                        <div>
                          <span className="text-[10px] font-bold bg-club-orange text-white px-2.5 py-0.5 rounded-full uppercase">
                            Pendiente de tu reseña
                          </span>
                          <h3 className="font-bold text-base text-club-brown mt-1">
                            {pendingActivity.title}
                          </h3>
                          <p className="text-xs text-stone-600">
                            Asististe en {pendingActivity.location}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setResenaEditData({
                              actividadId: pendingActivity.id,
                              actividad: pendingActivity.title,
                              estrellas: 5,
                              texto: ''
                            });
                            setCalifEstrellas(5);
                            setTextoResena('');
                            setArchivosResena([]);
                            setModalEscribirResenaOpen(true);
                          }}
                          className="pill-btn px-4 py-2 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-sm flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
                        >
                          <i className="fa-solid fa-pen-to-square" /> Dejar mi reseña
                        </button>
                      </div>
                    );
                  })()}

                  {/* Published reviews list */}
                  <div className="space-y-3">
                    {reviews.map((r) => {
                      const mediaItems = r.media && r.media.length ? r.media : (r.foto ? [r.foto] : []);

                      return (
                        <div
                          key={r.id}
                          className="bg-amber-50/60 p-4 rounded-2xl border border-amber-200 flex flex-col md:flex-row justify-between gap-3"
                        >
                          <div className="flex-1">
                            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                              Reseña publicada
                            </span>
                            <h3 className="font-bold text-base text-club-brown mt-1">{r.actividad}</h3>
                            <div className="flex text-amber-500 text-sm my-1">
                              {Array.from({ length: r.estrellas }).map((_, i) => (
                                <i key={i} className="fa-solid fa-star" />
                              ))}
                              <span className="text-xs text-stone-400 ml-1">• {r.fecha}</span>
                            </div>
                            <p className="text-xs text-club-brown/90">"{r.texto}"</p>

                            {/* Multi-media preview (photos and videos click-to-expand) */}
                            {mediaItems.length > 0 && (
                              <div className="mt-2.5 flex flex-wrap gap-2">
                                {mediaItems.map((url, mIdx) => {
                                  const isVid = isVideoMedia(url);
                                  return (
                                    <div
                                      key={mIdx}
                                      className="rounded-xl overflow-hidden h-28 w-36 border border-amber-200 relative shadow-xs bg-black flex items-center justify-center cursor-pointer group"
                                      onClick={() => openGalleryVisor(url, r.actividadId)}
                                    >
                                      {isVid ? (
                                        <div className="w-full h-full relative flex items-center justify-center">
                                          <video
                                            src={url}
                                            playsInline
                                            preload="metadata"
                                            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition pointer-events-none"
                                          />
                                          <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition">
                                            <div className="w-10 h-10 rounded-full bg-club-orange/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                                              <i className="fa-solid fa-play text-sm ml-0.5" />
                                            </div>
                                          </div>
                                          <span className="absolute bottom-1 left-1.5 bg-black/75 text-white text-[9px] px-1.5 py-0.5 rounded font-bold">
                                            <i className="fa-solid fa-video mr-1" /> Video
                                          </span>
                                        </div>
                                      ) : (
                                        <img
                                          src={url}
                                          alt={`Adjunto ${mIdx + 1}`}
                                          className="w-full h-full object-cover group-hover:scale-105 transition"
                                        />
                                      )}
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          openGalleryVisor(url, r.actividadId);
                                        }}
                                        className="absolute top-1 right-1 bg-black/60 hover:bg-club-orange text-white text-[10px] px-1.5 py-0.5 rounded-md font-bold cursor-pointer"
                                        title="Ver en pantalla completa"
                                      >
                                        <i className="fa-solid fa-expand" />
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-2 self-start md:self-center">
                            <button
                              onClick={() => {
                                setResenasOriginActivityId(null);
                                setModalOpinionesId(r.actividadId);
                              }}
                              className="pill-btn px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-club-brown text-xs font-bold border border-amber-300 cursor-pointer"
                            >
                              Ver otras reseñas
                            </button>
                            <button
                              onClick={() => {
                                setResenaEditData({
                                  id: r.id,
                                  actividadId: r.actividadId,
                                  actividad: r.actividad,
                                  estrellas: r.estrellas,
                                  texto: r.texto
                                });
                                setCalifEstrellas(r.estrellas);
                                setTextoResena(r.texto);
                                setArchivosResena(r.media && r.media.length ? [...r.media] : (r.foto ? [r.foto] : []));
                                setModalEscribirResenaOpen(true);
                              }}
                              className="pill-btn px-3 py-1.5 bg-white border border-amber-300 text-club-brown text-xs font-bold hover:bg-stone-50 cursor-pointer"
                            >
                              Editar Reseña
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {subTabResenas === 'actividades-organizadas' && (
                <div className="space-y-4">
                  <div className="p-5 bg-amber-50/50 rounded-2xl border border-amber-200 space-y-3">
                    <div className="flex justify-between items-center border-b border-amber-200/80 pb-2">
                      <div>
                        <span className="text-[10px] font-bold bg-stone-200 text-stone-700 px-2 py-0.5 rounded-full uppercase">
                          Actividad finalizada • 16 de Septiembre 2026
                        </span>
                        <h4 className="font-bold text-base text-club-brown mt-1">Tarde de Tejido, Cartas y Mate</h4>
                      </div>
                      <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                        <i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star" /><i className="fa-solid fa-star" />
                        <span className="text-xs text-club-brown font-extrabold ml-1">2 reseñas</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center bg-white p-3.5 rounded-2xl border border-amber-200">
                      <div className="text-xs">
                        <p className="font-bold text-club-brown">
                          <i className="fa-solid fa-camera-retro text-club-orange mr-1" /> Fotos y reseñas de vecinos (2)
                        </p>
                        <p className="text-[11px] text-stone-500">Aportadas por los propios participantes.</p>
                      </div>
                      <button
                        onClick={() => {
                          setResenasOriginActivityId(null);
                          setModalOpinionesId(10);
                        }}
                        className="pill-btn px-4 py-2 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-sm cursor-pointer"
                      >
                        Ver reseñas y fotos
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* 7. VISTA INFORMACIÓN ÚTIL */}
        {currentView === 'info-util' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow space-y-6">
              <div className="border-b border-amber-100 pb-3">
                <h2 className="font-brand text-2xl font-bold text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-shield-heart text-emerald-600" /> Información Útil y Seguridad de Datos
                </h2>
                <p className="text-xs text-stone-600">
                  Cuidado de tus datos personales, recomendaciones de seguridad y teléfonos de asistencia.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-amber-50 p-5 rounded-2xl border border-amber-200 space-y-2">
                  <h3 className="font-bold text-base text-club-brown flex items-center gap-2">
                    <i className="fa-solid fa-user-shield text-club-orange" /> Seguridad y Cuidado Digital
                  </h3>
                  <ul className="text-xs space-y-1.5 text-club-brown/90 list-disc list-inside">
                    <li>CLUB65 <strong>nunca te solicitará claves bancarias ni datos confidenciales</strong> por chat.</li>
                    <li>Todas las actividades comunitarias son revisadas por moderadores antes de salir en cartelera.</li>
                    <li>Podés reportar perfiles sospechosos o mensajes inapropiados con un solo clic.</li>
                  </ul>
                </div>

                <div className="bg-amber-50 p-5 rounded-2xl border border-amber-200 space-y-2">
                  <h3 className="font-bold text-base text-club-brown flex items-center gap-2">
                    <i className="fa-solid fa-arrow-up-right-from-square text-club-teal" /> Enlaces y Trámites Frecuentes
                  </h3>
                  <div className="space-y-1.5 text-xs">
                    <a
                      href="https://www.pami.org.ar"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block p-2 bg-white rounded-xl border border-amber-200 text-club-teal font-bold hover:underline"
                    >
                      Portal Oficial PAMI • Cartilla y Turnos Médicos →
                    </a>
                    <a
                      href="https://www.anses.gob.ar"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block p-2 bg-white rounded-xl border border-amber-200 text-club-teal font-bold hover:underline"
                    >
                      ANSES • Calendario de Pagos y Asignaciones →
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* 8. VISTA ACCESIBILIDAD */}
        {currentView === 'accesibilidad' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow space-y-6 max-w-xl mx-auto">
              <div className="border-b border-amber-100 pb-3">
                <h2 className="font-brand text-2xl font-bold text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-universal-access text-club-teal" /> Configuración de Accesibilidad
                </h2>
                <p className="text-xs text-stone-600">Ajustá la visualización de la plataforma para tu cuenta.</p>
              </div>

              <div className="space-y-4">
                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-2">
                  <h3 className="font-bold text-sm text-club-brown">Tamaño de letra en pantalla:</h3>
                  <p className="text-xs text-stone-500">Aumenta de forma legible todos los textos, descripciones y botones.</p>
                  <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                    <button
                      onClick={() => handleSetTextSize('normal')}
                      className={`pill-btn py-2 font-bold cursor-pointer ${
                        currentUser?.textSize === 'normal'
                          ? 'bg-club-orange text-white border border-club-orange'
                          : 'bg-white text-club-brown border border-amber-300'
                      }`}
                    >
                      Normal
                    </button>
                    <button
                      onClick={() => handleSetTextSize('grande')}
                      className={`pill-btn py-2 font-bold cursor-pointer ${
                        currentUser?.textSize === 'grande'
                          ? 'bg-club-orange text-white border border-club-orange'
                          : 'bg-white text-club-brown border border-amber-300'
                      }`}
                    >
                      Grande
                    </button>
                    <button
                      onClick={() => handleSetTextSize('gigante')}
                      className={`pill-btn py-2 font-bold cursor-pointer ${
                        currentUser?.textSize === 'gigante'
                          ? 'bg-club-orange text-white border border-club-orange'
                          : 'bg-white text-club-brown border border-amber-300'
                      }`}
                    >
                      Gigante
                    </button>
                  </div>
                </div>

                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-club-brown">Modo de alto contraste</h3>
                    <p className="text-xs text-stone-500">Fondo oscuro con texto blanco para descansar la vista.</p>
                  </div>
                  <button
                    onClick={handleToggleContrast}
                    className="pill-btn px-4 py-2 bg-white border border-amber-300 text-xs text-club-brown cursor-pointer"
                  >
                    {currentUser?.contrast ? 'Desactivar' : 'Activar'}
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* 9. VISTA SOPORTE */}
        {currentView === 'soporte' && (
          <section className="space-y-6">
            <div className="bg-white rounded-3xl p-6 border border-amber-200 retro-shadow space-y-5 max-w-lg mx-auto">
              <div className="border-b border-amber-100 pb-3">
                <h2 className="font-brand text-2xl font-bold text-club-brown flex items-center gap-2">
                  <i className="fa-solid fa-headset text-club-orange" /> Contactar Soporte CLUB65
                </h2>
                <p className="text-xs text-stone-600">Asistencia técnica para usuarios e instituciones colaboradoras.</p>
              </div>

              <div className="space-y-3">
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-center gap-3">
                  <i className="fa-solid fa-phone text-2xl text-club-orange" />
                  <div>
                    <p className="font-bold text-sm text-club-brown">Línea Telefónica Gratuita</p>
                    <p className="text-xs text-stone-600">0800-666-CLUB (2582) • Lun a Vie de 9 a 18 hs</p>
                  </div>
                </div>

                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-center gap-3">
                  <i className="fa-brands fa-whatsapp text-2xl text-emerald-600" />
                  <div>
                    <p className="font-bold text-sm text-club-brown">WhatsApp de Asistencia</p>
                    <p className="text-xs text-stone-600">+54 11 4000-6565 • Mensajes y notas de voz</p>
                  </div>
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    showToast('¡Mensaje enviado al equipo de soporte! Te responderemos a la brevedad.');
                  }}
                  className="space-y-2 pt-2"
                >
                  <label className="block text-xs font-bold text-club-brown">Escribinos tu consulta directa:</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Escribí aquí en qué podemos ayudarte..."
                    className="w-full px-3 py-2 bg-amber-50/50 border border-amber-200 rounded-xl text-xs outline-none focus:ring-2 focus:ring-club-orange"
                  />
                  <button type="submit" className="pill-btn w-full py-2.5 bg-club-orange text-white text-xs shadow-sm cursor-pointer">
                    Enviar Mensaje al Equipo
                  </button>
                </form>
              </div>
            </div>
          </section>
        )}

        {/* 10. VISTA PANEL DE ADMINISTRACIÓN / DASHBOARD - CLUB65 */}
        {currentView === 'moderacion' && currentUser?.tipo === 'moderador' && (() => {
          const pendingInstsList = pendingInstitutions.filter(i => !i.estadoAlta || i.estadoAlta === 'pendiente');
          const pendingRepsList = reports.filter(r => r.status === 'pending' || r.status === 'pendiente');
          const activeApprovedActivities = activities.filter(a => a.isApproved && !a.baja_forzada);

          return (
            <section className="space-y-6">
              <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-purple-200 retro-shadow space-y-6">
                
                {/* TOP HEADER & KEY METRICS */}
                <div className="border-b border-purple-100 pb-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                    <div>
                      <h2 className="font-brand text-2xl sm:text-3xl font-black text-purple-950 flex items-center gap-2">
                        <i className="fa-solid fa-shield-halved text-purple-700" /> DASHBOARD - CLUB65
                      </h2>
                      <p className="text-xs sm:text-sm text-purple-900/80">
                        Panel de trabajo operativo: supervisión de propuestas, seguridad comunitaria y control institucional.
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                      <span className="bg-purple-100 text-purple-800 text-xs font-black px-3.5 py-1.5 rounded-full border border-purple-300">
                        Rol: Administrador oficial
                      </span>
                      <button
                        type="button"
                        onClick={() => setModalDesignarAdminOpen(true)}
                        className="pill-btn px-4 py-1.5 bg-purple-800 hover:bg-purple-900 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                      >
                        <i className="fa-solid fa-crown text-amber-300" /> Designar nuevo Administrador oficial
                      </button>
                    </div>
                  </div>

                  {/* 4 SUMMARY STAT CARDS (INDICADORES DE MÉTRICAS OPERATIVAS) */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                    <div className="p-4 rounded-2xl border-2 bg-amber-50/70 border-amber-200 text-center select-none shadow-xs">
                      <div className="font-brand text-2xl sm:text-3xl font-black text-amber-900">
                        [ {pendingActivities.length} ]
                      </div>
                      <div className="text-xs font-bold text-amber-950 mt-0.5">Propuestas Pendientes</div>
                    </div>

                    <div className="p-4 rounded-2xl border-2 bg-blue-50/70 border-blue-200 text-center select-none shadow-xs">
                      <div className="font-brand text-2xl sm:text-3xl font-black text-blue-900">
                        [ {pendingInstsList.length} ]
                      </div>
                      <div className="text-xs font-bold text-blue-950 mt-0.5">Instituciones por Validar</div>
                    </div>

                    <div className="p-4 rounded-2xl border-2 bg-rose-50/70 border-rose-200 text-center select-none shadow-xs">
                      <div className="font-brand text-2xl sm:text-3xl font-black text-rose-900">
                        [ {pendingRepsList.length} ]
                      </div>
                      <div className="text-xs font-bold text-rose-950 mt-0.5">Reportes de Seguridad</div>
                    </div>

                    <div className="p-4 rounded-2xl border-2 bg-stone-100/70 border-stone-300 text-center select-none shadow-xs">
                      <div className="font-brand text-2xl sm:text-3xl font-black text-stone-900">
                        [ {sanctionsList.length > 0 ? sanctionsList.length : bannedUsersList.length} ]
                      </div>
                      <div className="text-xs font-bold text-stone-950 mt-0.5">Usuarios Sancionados</div>
                    </div>
                  </div>
                </div>

                {/* INTERNAL TABS */}
                <div className="flex gap-2 overflow-x-auto pb-1 border-b border-purple-100 text-xs sm:text-sm font-bold">
                  <button
                    onClick={() => setDashboardTab('propuestas')}
                    className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                      dashboardTab === 'propuestas'
                        ? 'bg-purple-800 text-white shadow-sm'
                        : 'bg-purple-50 text-purple-900 hover:bg-purple-100'
                    }`}
                  >
                    <i className="fa-solid fa-inbox" />
                    <span>1. Propuestas Vecinales ({pendingActivities.length})</span>
                  </button>
                  <button
                    onClick={() => setDashboardTab('instituciones')}
                    className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                      dashboardTab === 'instituciones'
                        ? 'bg-purple-800 text-white shadow-sm'
                        : 'bg-purple-50 text-purple-900 hover:bg-purple-100'
                    }`}
                  >
                    <i className="fa-solid fa-landmark" />
                    <span>2. Validación Institucional ({pendingInstsList.length})</span>
                  </button>
                  <button
                    onClick={() => setDashboardTab('reportes')}
                    className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                      dashboardTab === 'reportes'
                        ? 'bg-purple-800 text-white shadow-sm'
                        : 'bg-purple-50 text-purple-900 hover:bg-purple-100'
                    }`}
                  >
                    <i className="fa-solid fa-triangle-exclamation" />
                    <span>3. Centro de Reportes ({pendingRepsList.length})</span>
                  </button>
                  <button
                    onClick={() => setDashboardTab('sanciones')}
                    className={`px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                      dashboardTab === 'sanciones'
                        ? 'bg-purple-800 text-white shadow-sm'
                        : 'bg-purple-50 text-purple-900 hover:bg-purple-100'
                    }`}
                  >
                    <i className="fa-solid fa-ban" />
                    <span>4. Gestión de Sanciones</span>
                  </button>
                </div>

                {/* ============================================================== */}
                {/* PILAR 1: BANDEJA DE ENTRADA DE INICIATIVAS VECINALES (PROPUESTAS) */}
                {/* ============================================================== */}
                {dashboardTab === 'propuestas' && (
                  <div className="space-y-4">
                    <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-200 text-xs text-amber-950">
                      <p className="font-bold flex items-center gap-2">
                        <i className="fa-solid fa-circle-info text-amber-600 text-sm" /> Bandeja de Entrada de Iniciativas Vecinales:
                      </p>
                      <p className="mt-1 text-stone-700">
                        Cada vez que un usuario personal propone una actividad, el evento cae en esta cola. Podés <strong>Aprobar y Publicar</strong>, <strong>Solicitar cambios</strong> con devolución directa, o <strong>Rechazar</strong>.
                      </p>
                    </div>

                    {pendingActivities.length === 0 ? (
                      <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-500 text-xs">
                        <i className="fa-solid fa-circle-check text-2xl text-emerald-600 mb-2 block" />
                        No hay propuestas vecinales pendientes de moderación en este momento.
                      </div>
                    ) : (
                      pendingActivities.map((act) => (
                        <div
                          key={act.id}
                          className="bg-white border-2 border-amber-200 p-5 rounded-2xl shadow-xs space-y-3 hover:border-amber-300 transition"
                        >
                          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-amber-100 pb-3">
                            <div>
                              <span className="bg-amber-100 text-amber-900 font-bold px-2.5 py-0.5 rounded-full text-xs">
                                Iniciativa Vecinal
                              </span>
                              <h3 className="font-brand text-lg font-bold text-club-brown mt-1">{act.title}</h3>
                            </div>
                            <div className="text-xs text-stone-600">
                              <strong>Propuesto por:</strong>{' '}
                              <button
                                type="button"
                                onClick={() => openUserProfileByName(act.organizer)}
                                className="font-bold text-club-orange hover:underline cursor-pointer inline-flex items-center gap-1 ml-1"
                                title="Ver perfil del vecino"
                              >
                                <i className="fa-solid fa-user-circle text-xs" /> @{act.organizer}
                              </button>
                            </div>
                          </div>

                          <div className="flex flex-col sm:flex-row gap-4">
                            <div className="w-full sm:w-48 h-36 rounded-2xl overflow-hidden bg-amber-100 flex-shrink-0 border border-amber-200 shadow-xs">
                              <img
                                src={act.image}
                                alt={act.title}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop';
                                }}
                              />
                            </div>
                            <div className="flex-1 space-y-2">
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-amber-50/50 p-3 rounded-xl border border-amber-200 text-xs">
                                <div>
                                  <span className="text-stone-500 font-bold block">Día y Horario:</span>
                                  <span className="font-bold text-club-brown">{act.schedule}</span>
                                </div>
                                <div>
                                  <span className="text-stone-500 font-bold block">Lugar / Encuentro:</span>
                                  <span className="font-bold text-club-brown">{act.location}</span>
                                </div>
                                <div>
                                  <span className="text-stone-500 font-bold block">Cupo Previsto:</span>
                                  <span className="font-bold text-club-brown">{act.capacity} personas</span>
                                </div>
                              </div>
                              <div className="text-xs text-stone-700 bg-white p-3 rounded-xl border border-amber-100">
                                <span className="font-bold text-club-brown block mb-0.5">Descripción de la actividad:</span>
                                <p className="italic leading-relaxed">"{act.description}"</p>
                              </div>
                            </div>
                          </div>

                          {/* Ubicación y Mapa interactivo de la propuesta */}
                          <div className="bg-white p-4 rounded-2xl border border-amber-200 space-y-2">
                            <div className="flex items-center justify-between">
                              <div>
                                <h5 className="font-brand text-xs font-bold text-club-brown flex items-center gap-1.5">
                                  <i className="fa-solid fa-map-location-dot text-club-orange" /> Ubicación y Mapa (OpenStreetMap)
                                </h5>
                                <p className="text-xs text-stone-600 font-semibold">{act.location}</p>
                              </div>
                              <a
                                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(act.location)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="pill-btn px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold flex items-center gap-1.5 border border-blue-200 shadow-2xs"
                                title="Abrir en Google Maps"
                              >
                                <i className="fa-solid fa-diamond-turn-right text-blue-600" /> Cómo llegar
                              </a>
                            </div>
                            <div className="h-44 w-full rounded-xl overflow-hidden border border-amber-200 shadow-inner">
                              <LeafletMap
                                lat={act.lat}
                                lng={act.lng}
                                title={act.title}
                                locationName={act.location}
                                height={176}
                              />
                            </div>
                          </div>

                          {/* Cronología de la propuesta vecinal */}
                          <div className="p-3 bg-amber-100/50 rounded-xl border border-amber-200 text-[11px] space-y-1.5">
                            <div className="font-bold text-stone-700 flex items-center gap-1.5">
                              <i className="fa-solid fa-clock-rotate-left text-club-orange" /> Cronología de la propuesta:
                            </div>
                            <div className="flex flex-wrap gap-4 text-stone-600">
                              <div>
                                <span className="font-bold block text-club-brown">Propuesta enviada:</span>
                                <span>{act.proposedAt || '23/10/2026, 14:00 hs'}</span>
                              </div>
                              {act.changesRequestedAt && (
                                <div>
                                  <span className="font-bold block text-rose-800">Modificaciones solicitadas:</span>
                                  <span>{act.changesRequestedAt}</span>
                                </div>
                              )}
                              {act.changesSubmittedAt && (
                                <div>
                                  <span className="font-bold block text-emerald-800">Modificaciones reenviadas:</span>
                                  <span>{act.changesSubmittedAt}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Historial de versiones intercalado con Devolución de moderación */}
                          <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200 text-xs space-y-2">
                            <div className="font-bold text-club-brown flex items-center justify-between">
                              <span className="flex items-center gap-1.5">
                                <i className="fa-solid fa-code-branch text-club-orange" /> Historial de versiones y moderación
                              </span>
                              {(!act.versions || act.versions.length === 0) && (
                                <button
                                  type="button"
                                  onClick={() => setModalDetalleId(act.id)}
                                  className="pill-btn px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-club-brown text-[11px] font-bold flex items-center gap-1 border border-amber-300 shadow-2xs cursor-pointer"
                                >
                                  <i className="fa-solid fa-eye text-club-orange" /> ver detalle
                                </button>
                              )}
                            </div>

                            {act.versions && act.versions.length > 0 ? (
                              <div className="space-y-2.5">
                                {act.versions.map((v, vIdx) => (
                                  <React.Fragment key={vIdx}>
                                    <div className="p-3 bg-white rounded-xl border border-amber-200 text-[11px] space-y-1.5 shadow-2xs">
                                      <div className="flex justify-between items-center font-bold">
                                        <div className="flex items-center gap-2">
                                          <span className="text-purple-900 font-bold bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                                            Versión {v.version}
                                          </span>
                                          <span className="text-stone-400 font-normal">
                                            {v.date || (v as any).timestamp || 'Fecha no registrada'}
                                          </span>
                                        </div>
                                        <button
                                          type="button"
                                          onClick={() => openVersionDetail(v, act)}
                                          className="pill-btn px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-club-brown text-[11px] font-bold flex items-center gap-1 border border-amber-300 shadow-2xs cursor-pointer"
                                        >
                                          <i className="fa-solid fa-eye text-club-orange" /> ver detalle
                                        </button>
                                      </div>
                                      <p className="text-stone-700 leading-snug">
                                        <strong>Título:</strong> {v.title} • <strong>Horario:</strong> {v.schedule} • <strong>Lugar:</strong> {v.location} • <strong>Cupo:</strong> {v.capacity}
                                      </p>
                                      {v.note && (
                                        <p className="text-stone-500 italic bg-amber-50/50 p-1.5 rounded-lg border border-amber-100">
                                          "{v.note}"
                                        </p>
                                      )}
                                    </div>

                                    {/* Intercalación de la Devolución de moderación tras la versión revisada */}
                                    {vIdx === 0 && act.proposalNote && (
                                      <div className="p-3 my-1.5 bg-rose-50 border-l-4 border-rose-500 rounded-r-xl text-rose-900 text-xs space-y-1 shadow-2xs">
                                        <div className="flex flex-wrap items-center justify-between gap-1 font-bold">
                                          <span className="flex items-center gap-1.5 text-rose-900">
                                            <i className="fa-solid fa-comment-dots text-rose-600" />
                                            Devolución de moderación
                                          </span>
                                          <span className="text-[11px] text-stone-500 font-semibold">
                                            Moderador General • {act.changesRequestedAt || '23/10/2026, 16:30 hs'}
                                          </span>
                                        </div>
                                        <p className="font-semibold text-rose-800 leading-snug">{act.proposalNote}</p>
                                      </div>
                                    )}
                                  </React.Fragment>
                                ))}
                              </div>
                            ) : (
                              <>
                                <p className="text-[11px] text-stone-600">
                                  <strong>Versión actual:</strong> {act.title} • {act.schedule} • {act.location} • Cupo: {act.capacity} personas
                                </p>
                                {act.proposalNote && (
                                  <div className="p-3 my-1.5 bg-rose-50 border-l-4 border-rose-500 rounded-r-xl text-rose-900 text-xs space-y-1 shadow-2xs">
                                    <div className="flex flex-wrap items-center justify-between gap-1 font-bold">
                                      <span className="flex items-center gap-1.5 text-rose-900">
                                        <i className="fa-solid fa-comment-dots text-rose-600" />
                                        Devolución de moderación
                                      </span>
                                      <span className="text-[11px] text-stone-500 font-semibold">
                                        Moderador General • {act.changesRequestedAt || '23/10/2026, 16:30 hs'}
                                      </span>
                                    </div>
                                    <p className="font-semibold text-rose-800 leading-snug">{act.proposalNote}</p>
                                  </div>
                                )}
                              </>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-amber-100">
                            <button
                              onClick={() => handleAdminModerateProposal(act.id, 'approve')}
                              className="pill-btn px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <i className="fa-solid fa-check" /> Aprobar y Publicar
                            </button>
                            <button
                              onClick={() => setModalSolicitarCambiosAct(act)}
                              className="pill-btn px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <i className="fa-solid fa-pen-to-square" /> Solicitar cambios
                            </button>
                            <button
                              onClick={() => handleAdminModerateProposal(act.id, 'reject')}
                              className="pill-btn px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <i className="fa-solid fa-trash-can" /> Rechazar
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* ============================================================== */}
                {/* PILAR 2: VALIDACIÓN DE NUEVAS INSTITUCIONES                     */}
                {/* ============================================================== */}
                {dashboardTab === 'instituciones' && (
                  <div className="space-y-4">
                    <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 text-xs text-blue-950">
                      <p className="font-bold flex items-center gap-2">
                        <i className="fa-solid fa-shield-halved text-blue-700 text-sm" /> Validación de Nuevas Instituciones:
                      </p>
                      <p className="mt-1 text-stone-700">
                        Las instituciones pueden publicar talleres oficiales sin filtro previo. Su alta requiere revisión rigurosa del tipo de entidad, número de contacto institucional, personería jurídica y documentación legal adjunta.
                      </p>
                    </div>

                    {pendingInstsList.length === 0 ? (
                      <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-500 text-xs">
                        <i className="fa-solid fa-circle-check text-2xl text-emerald-600 mb-2 block" />
                        No hay instituciones pendientes de validación en este momento.
                      </div>
                    ) : (
                      pendingInstsList.map((inst) => (
                        <div
                          key={inst.id}
                          className="bg-white border-2 border-blue-200 p-5 rounded-2xl shadow-xs space-y-4 hover:border-blue-300 transition"
                        >
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-blue-100 pb-3">
                            <div>
                              <span className="bg-blue-100 text-blue-900 font-bold px-2.5 py-0.5 rounded-full text-xs">
                                Solicitud de Alta Institucional
                              </span>
                              <h3 className="font-brand text-lg font-bold text-club-brown mt-1">{inst.apodo}</h3>
                              <p className="text-xs text-stone-500">
                                Usuario: <span className="font-bold text-stone-700">@{inst.usuario}</span> <span className="text-[10px] text-amber-800 bg-amber-100 font-bold px-2 py-0.5 rounded-full ml-1">(Cuenta en espera de ser dada de alta)</span>
                                {' '}• {inst.email || 'institucion@tresdefebrero.gov.ar'}
                              </p>
                            </div>
                            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                              Pendiente de Alta
                            </span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-blue-50/40 p-3.5 rounded-2xl border border-blue-100 text-xs">
                            <div>
                              <span className="text-stone-500 font-bold block">Tipo de Entidad:</span>
                              <span className="font-bold text-club-brown">{inst.entidadTipo || 'Asociación Civil / Club Social'}</span>
                            </div>
                            <div>
                              <span className="text-stone-500 font-bold block">Contacto Institucional:</span>
                              <span className="font-bold text-club-brown flex items-center gap-1">
                                <i className="fa-solid fa-phone text-club-teal text-[10px]" />
                                {inst.contactoInstitucional || inst.telefonoInstitucional || '11 4750-1234'}
                              </span>
                            </div>
                            <div>
                              <span className="text-stone-500 font-bold block">CUIT / Personería:</span>
                              <span className="font-bold text-club-brown">{inst.cuit || '30-71192845-6'}</span>
                            </div>
                            <div>
                              <span className="text-stone-500 font-bold block">Funcionario / Presidente:</span>
                              <span className="font-bold text-club-brown">{inst.responsableLegal || 'Lic. Alberto Valenzuela (Presidente)'}</span>
                            </div>
                          </div>

                          <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-200 flex flex-col sm:flex-row justify-between sm:items-center gap-2 text-xs">
                            <div className="flex items-center gap-2">
                              <i className="fa-solid fa-file-pdf text-rose-600 text-lg" />
                              <div>
                                <p className="font-bold text-blue-950">Documentación adjunta:</p>
                                <p className="text-[11px] text-stone-600">{inst.documentoLegal || 'Estatuto_Social_Personeria.pdf'}</p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                const a = document.createElement('a');
                                a.href = inst.documentoDescargaUrl || 'data:text/plain;charset=utf-8,Documentacion%20Institucional%20CLUB65';
                                a.download = inst.documentoLegal || 'Documento_Legal.pdf';
                                a.click();
                                showToast('Descargando documento legal adjunto: ' + (inst.documentoLegal || 'Documento_Legal.pdf'));
                              }}
                              className="pill-btn px-3 py-1.5 bg-white hover:bg-blue-50 text-blue-800 border border-blue-300 font-bold text-xs inline-flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <i className="fa-solid fa-file-arrow-down text-blue-600" /> Descargar documentación adjunta
                            </button>
                          </div>

                          <div className="flex items-center justify-end gap-2 pt-2 border-t border-blue-100">
                            <button
                              onClick={() => handleRejectInstitution(inst.id)}
                              className="pill-btn px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                            >
                              <i className="fa-solid fa-xmark" /> Rechazar alta
                            </button>
                            <button
                              onClick={() => handleApproveInstitution(inst.id)}
                              className="pill-btn px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <i className="fa-solid fa-check" /> Dar de alta institución
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* ============================================================== */}
                {/* PILAR 3: CENTRO DE REPORTES Y SEGURIDAD                        */}
                {/* ============================================================== */}
                {dashboardTab === 'reportes' && (() => {
                  const pendingReports = reports.filter(r => r.status === 'pending' || r.status === 'pendiente');
                  const resolvedReports = reports.filter(r => r.status === 'resolved' || r.status === 'resuelto' || r.status === 'desestimado');

                  return (
                    <div className="space-y-4">
                      <div className="bg-rose-50/70 p-4 rounded-2xl border border-rose-200 text-xs text-rose-950">
                        <p className="font-bold flex items-center gap-2">
                          <i className="fa-solid fa-triangle-exclamation text-rose-600 text-sm" /> Centro de Reportes y Seguridad Comunitaria:
                        </p>
                        <p className="mt-1 text-stone-700">
                          Alertas vecinales de mensajes o contenido inapropiado. Podés revisar la <strong>conversación en contexto (24 horas)</strong> y pulsar <strong>Dictar resolución</strong> para aplicar la medida correspondiente con notificación automática y correo electrónico al denunciante.
                        </p>
                      </div>

                      {/* Sub-pestañas: Alertas pendientes vs Historial de resoluciones */}
                      <div className="flex gap-2 border-b border-rose-200 pb-2">
                        <button
                          type="button"
                          onClick={() => setFiltroReportes('pendientes')}
                          className={`pill-btn px-4 py-2 text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                            filtroReportes === 'pendientes'
                              ? 'bg-rose-700 text-white shadow-xs'
                              : 'bg-white text-stone-700 border border-stone-200 hover:bg-rose-50'
                          }`}
                        >
                          <i className="fa-solid fa-bell" />
                          <span>Alertas Pendientes ({pendingReports.length})</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setFiltroReportes('historial')}
                          className={`pill-btn px-4 py-2 text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                            filtroReportes === 'historial'
                              ? 'bg-rose-700 text-white shadow-xs'
                              : 'bg-white text-stone-700 border border-stone-200 hover:bg-rose-50'
                          }`}
                        >
                          <i className="fa-solid fa-clock-rotate-left" />
                          <span>Historial de Resoluciones (Últimos 30 días) ({resolvedReports.length})</span>
                        </button>
                      </div>

                      {/* VISTA 1: REPORTES PENDIENTES */}
                      {filtroReportes === 'pendientes' && (
                        <div className="space-y-4">
                          {pendingReports.length === 0 ? (
                            <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-500 text-xs">
                              <i className="fa-solid fa-shield text-2xl text-emerald-600 mb-2 block" />
                              No hay alertas de seguridad pendientes en este momento.
                            </div>
                          ) : (
                            pendingReports.map((rep) => (
                              <div
                                key={rep.id}
                                className="bg-white border-2 border-rose-200 hover:border-rose-300 p-5 rounded-2xl shadow-xs space-y-3 transition"
                              >
                                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-rose-100 pb-3">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="bg-rose-100 text-rose-900 font-bold px-2.5 py-0.5 rounded-full text-xs">
                                      Motivo: {rep.reason}
                                    </span>
                                    <span className="text-xs text-stone-500">
                                      Reportado por{' '}
                                      <button
                                        type="button"
                                        onClick={() => openUserProfileByName(rep.reporterUsername || rep.reporterUser)}
                                        className="font-bold text-club-brown hover:underline cursor-pointer"
                                      >
                                        @{rep.reporterUsername || rep.reporterUser || 'vecino'}
                                      </button>
                                      {' '}• {rep.createdAt || rep.timestamp || 'Reciente'}
                                    </span>
                                  </div>
                                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-rose-100 text-rose-800">
                                    Alerta Pendiente
                                  </span>
                                </div>

                                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-2">
                                  <div className="flex justify-between items-center text-stone-500 font-bold">
                                    <span>Tipo: {rep.type}</span>
                                    {rep.reportedUser && (
                                      <span>
                                        Usuario denunciado:{' '}
                                        <button
                                          type="button"
                                          onClick={() => openUserProfileByName(rep.reportedUser)}
                                          className="font-bold text-rose-700 hover:underline cursor-pointer ml-1"
                                        >
                                          @{rep.reportedUser}
                                        </button>
                                      </span>
                                    )}
                                  </div>

                                  {rep.messageText && (
                                    <p className="p-2.5 bg-white rounded-lg border border-stone-200 text-stone-800 font-medium italic">
                                      "{rep.messageText}"
                                    </p>
                                  )}

                                  {rep.mediaUrl && (
                                    <div className="pt-1">
                                      <span className="text-[10px] text-stone-500 block mb-1">Contenido multimedia adjunto:</span>
                                      <img src={rep.mediaUrl} alt="Contenido" className="h-28 rounded-lg object-cover border" />
                                    </div>
                                  )}

                                  {rep.comment && (
                                    <p className="text-[11px] text-stone-600">
                                      <strong>Comentario del vecino denunciante:</strong> {rep.comment}
                                    </p>
                                  )}

                                  {/* VER CONVERSACIÓN EN CONTEXTO (24 HORAS) */}
                                  {rep.chatId && (
                                    <div className="pt-2 border-t border-stone-200">
                                      <button
                                        type="button"
                                        onClick={() => setVerContextoReporteId(verContextoReporteId === rep.id ? null : rep.id)}
                                        className="text-xs font-bold text-purple-700 hover:text-purple-900 inline-flex items-center gap-1.5 underline cursor-pointer"
                                      >
                                        <i className="fa-solid fa-comments" />
                                        {verContextoReporteId === rep.id ? 'Ocultar chat en contexto' : 'Ver conversación en contexto (24 horas antes y después)'}
                                      </button>

                                      {verContextoReporteId === rep.id && (() => {
                                        const chat = chats.find(c => c.id === rep.chatId);
                                        if (!chat) return <p className="text-[11px] text-stone-400 italic mt-1">Chat no disponible.</p>;
                                        const mIdx = chat.messages.findIndex(m => m.id === rep.messageId);
                                        const startIdx = mIdx === -1 ? Math.max(0, chat.messages.length - 8) : Math.max(0, mIdx - 4);
                                        const endIdx = mIdx === -1 ? chat.messages.length : Math.min(chat.messages.length, mIdx + 5);
                                        const contextThread = chat.messages.slice(startIdx, endIdx);

                                        return (
                                          <div className="mt-2 p-3.5 bg-purple-50/70 rounded-xl border border-purple-200 space-y-2">
                                            <div className="flex items-center justify-between">
                                              <p className="text-[10px] font-black text-purple-900 uppercase">
                                                Grupo: {chat.title} • Contexto del chat (24 hs):
                                              </p>
                                              <span className="text-[10px] text-stone-500">Conforme a normativas de seguridad comunitaria</span>
                                            </div>
                                            <div className="space-y-1.5 max-h-60 overflow-y-auto pr-1">
                                              {contextThread.map((ctxMsg, cIdx) => {
                                                const isReported = ctxMsg.id === rep.messageId || ctxMsg.text === rep.messageText;
                                                return (
                                                  <div
                                                    key={cIdx}
                                                    className={`p-2.5 rounded-xl text-xs transition ${
                                                      isReported
                                                        ? 'bg-rose-100 border-2 border-rose-400 font-semibold text-rose-950 shadow-xs'
                                                        : 'bg-white border border-stone-200 text-stone-700'
                                                    }`}
                                                  >
                                                    <div className="flex justify-between items-center text-[10px] mb-1">
                                                      <span className={`font-bold ${isReported ? 'text-rose-900 flex items-center gap-1' : 'text-stone-600'}`}>
                                                        {isReported && <i className="fa-solid fa-triangle-exclamation text-rose-600" />}
                                                        {ctxMsg.sender} {isReported && '• [MENSAJE DENUNCIADO]'}
                                                      </span>
                                                      <span className="text-stone-400">{ctxMsg.time}</span>
                                                    </div>
                                                    <p className="leading-relaxed">{ctxMsg.text}</p>
                                                  </div>
                                                );
                                              })}
                                            </div>
                                          </div>
                                        );
                                      })()}
                                    </div>
                                  )}
                                </div>

                                <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-rose-100">
                                  <button
                                    onClick={() => setModalDecisionReporte({
                                      report: rep,
                                      actionType: 'sancionar',
                                      motive: rep.reason || MOTIVOS_REPORTE[0],
                                      comment: '',
                                      sanctionType: 'temporal_7',
                                      alsoDelete: true
                                    })}
                                    className="pill-btn px-5 py-2.5 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                                  >
                                    <i className="fa-solid fa-gavel" /> Dictar resolución
                                  </button>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      )}

                      {/* VISTA 2: HISTORIAL DE RESOLUCIONES (ÚLTIMOS 30 DÍAS) */}
                      {filtroReportes === 'historial' && (
                        <div className="space-y-4">
                          {resolvedReports.length === 0 ? (
                            <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-500 text-xs">
                              <i className="fa-solid fa-inbox text-2xl text-stone-400 mb-2 block" />
                              No hay resoluciones registradas en los últimos 30 días.
                            </div>
                          ) : (
                            <div className="space-y-3">
                              {resolvedReports.map((rep) => (
                                <div
                                  key={rep.id}
                                  className="bg-white border-2 border-stone-200 p-4 rounded-2xl shadow-xs text-xs space-y-2.5 hover:border-stone-300 transition"
                                >
                                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-stone-100 pb-2">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                                        rep.resolutionDecision === 'desestimado' || rep.status === 'desestimado'
                                          ? 'bg-stone-100 text-stone-800 border border-stone-300'
                                          : rep.resolutionAction === 'ban_user'
                                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                                      }`}>
                                        {rep.resolutionDecision === 'desestimado' || rep.status === 'desestimado'
                                          ? 'Caso Desestimado'
                                          : rep.resolutionAction === 'ban_user'
                                          ? 'Usuario Sancionado'
                                          : (rep.resolutionAction === 'delete_content' ? 'Contenido Retirado' : 'Resolución con Medidas')}
                                      </span>
                                      <span className="text-stone-500 font-bold">
                                        Fecha: <span className="text-club-brown">{rep.resolvedAt || rep.timestamp || 'Reciente'}</span>
                                      </span>
                                      <span className="text-stone-500 font-bold">
                                        • Dictada por: <span className="text-club-teal font-extrabold">@{rep.resolvedBy || 'administrador'}</span>
                                      </span>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-stone-50 p-3 rounded-xl border border-stone-100">
                                    <div>
                                      <span className="text-stone-400 font-bold block text-[10px]">DENUNCIANTE:</span>
                                      <button
                                        type="button"
                                        onClick={() => openUserProfileByName(rep.reporterUsername || rep.reporterUser)}
                                        className="font-bold text-club-brown hover:underline cursor-pointer"
                                      >
                                        @{rep.reporterUsername || rep.reporterUser}
                                      </button>
                                    </div>
                                    <div>
                                      <span className="text-stone-400 font-bold block text-[10px]">DENUNCIADO:</span>
                                      {rep.reportedUser ? (
                                        <button
                                          type="button"
                                          onClick={() => openUserProfileByName(rep.reportedUser)}
                                          className="font-bold text-rose-700 hover:underline cursor-pointer"
                                        >
                                          @{rep.reportedUser}
                                        </button>
                                      ) : (
                                        <span className="text-stone-600">Contenido multimedia</span>
                                      )}
                                    </div>
                                    <div>
                                      <span className="text-stone-400 font-bold block text-[10px]">MOTIVO:</span>
                                      <span className="font-bold text-club-brown">{rep.sanctionReason || rep.reason}</span>
                                    </div>
                                  </div>

                                  {rep.messageText && (
                                    <p className="text-stone-600 italic bg-stone-50 p-2 rounded-lg border border-stone-100">
                                      Contenido reportado: "{rep.messageText}"
                                    </p>
                                  )}

                                  <div className="p-2.5 bg-blue-50/60 rounded-xl border border-blue-100 text-stone-800">
                                    <span className="font-bold text-blue-900 block mb-0.5">Fundamentación y medidas de la resolución:</span>
                                    <p className="italic text-stone-700 leading-relaxed">
                                      "{rep.adminComment || rep.resolutionNote || 'Resolución administrativa aplicada conforme al reglamento de convivencia comunitaria.'}"
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* ============================================================== */}
                {/* PILAR 4: GESTIÓN DE SANCIONES Y BAJAS (VETO GLOBAL)            */}
                {/* ============================================================== */}
                {dashboardTab === 'sanciones' && (
                  <div className="space-y-6">
                    <div className="bg-stone-100 p-4 rounded-2xl border border-stone-300 text-xs text-stone-900">
                      <p className="font-bold flex items-center gap-2">
                        <i className="fa-solid fa-ban text-stone-700 text-sm" /> Gestión de Sanciones y Bajas de Actividades:
                      </p>
                      <p className="mt-1 text-stone-600">
                        Administración de suspensiones de usuarios con detalle de motivos, comentarios, y fecha de levantamiento automático, junto a la baja forzada de actividades de la cartelera y designación de administradores.
                      </p>
                    </div>

                    {/* SECTION: BAJA FORZADA DE ACTIVIDADES DE LA CARTELERA */}
                    <div className="p-4 bg-white rounded-2xl border border-purple-200 space-y-3">
                      <div className="border-b border-purple-100 pb-2">
                        <h4 className="font-bold text-xs text-club-brown uppercase tracking-wider">
                          Baja Forzada de Actividades de la Cartelera
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          Podés revisar el detalle completo de la actividad antes de darla de baja forzada de la cartelera comunitaria.
                        </p>
                      </div>

                      <div className="space-y-2 max-h-56 overflow-y-auto">
                        {activeApprovedActivities.length === 0 ? (
                          <p className="text-xs text-stone-400 py-3 text-center">No hay actividades activas en la Cartelera.</p>
                        ) : (
                          activeApprovedActivities.map((act) => (
                            <div
                              key={act.id}
                              className="p-3 bg-amber-50/50 rounded-xl border border-amber-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs"
                            >
                              <div>
                                <span className="font-bold text-club-brown text-sm">{act.title}</span>
                                <span className="text-[11px] text-stone-500 block sm:inline sm:ml-2">
                                  ({act.location} • {act.schedule}) • Organizador:{' '}
                                  <button
                                    type="button"
                                    onClick={() => openUserProfileByName(act.organizer)}
                                    className="font-bold text-club-orange hover:underline cursor-pointer"
                                  >
                                    @{act.organizer}
                                  </button>
                                </span>
                              </div>
                              <div className="flex items-center gap-2 self-end sm:self-auto">
                                <button
                                  type="button"
                                  onClick={() => setModalDetalleId(act.id)}
                                  className="pill-btn px-3 py-1 bg-white hover:bg-amber-100 text-club-brown border border-amber-300 font-bold text-xs cursor-pointer"
                                >
                                  Ver detalle
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleForceCancelActivity(act.id, act.title)}
                                  className="pill-btn px-3 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-bold text-xs cursor-pointer flex items-center gap-1"
                                >
                                  <i className="fa-solid fa-ban" /> Dar de baja
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    {/* SECTION: LISTA DE USUARIOS SANCIONADOS CON MOTIVO, COMENTARIO, ADMIN, FECHA Y TIPO */}
                    <div className="p-4 bg-white rounded-2xl border border-purple-200 space-y-3">
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-purple-100 pb-2">
                        <div>
                          <h4 className="font-bold text-xs text-club-brown uppercase tracking-wider">
                            Lista de Usuarios Sancionados ({sanctionsList.length})
                          </h4>
                          <p className="text-[11px] text-stone-500">
                            Registro de suspensiones temporales y vetos permanentes aplicados.
                          </p>
                        </div>
                        <input
                          type="text"
                          value={searchBannedQuery}
                          onChange={(e) => setSearchBannedQuery(e.target.value)}
                          placeholder="Buscar usuario o motivo..."
                          className="px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs outline-none w-full sm:w-56"
                        />
                      </div>

                      <div className="space-y-2.5 max-h-72 overflow-y-auto">
                        {sanctionsList.length === 0 ? (
                          <p className="text-xs text-stone-400 py-4 text-center">No hay usuarios sancionados actualmente.</p>
                        ) : (
                          sanctionsList
                            .filter(s =>
                              s.username.toLowerCase().includes(searchBannedQuery.toLowerCase()) ||
                              s.reason.toLowerCase().includes(searchBannedQuery.toLowerCase()) ||
                              (s.comment && s.comment.toLowerCase().includes(searchBannedQuery.toLowerCase()))
                            )
                            .map((sanc) => (
                              <div
                                key={sanc.id}
                                className="p-3.5 bg-rose-50/50 rounded-2xl border border-rose-200 text-xs space-y-2"
                              >
                                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                                  <div className="flex items-center gap-2">
                                    <span className="w-7 h-7 rounded-full bg-rose-200 text-rose-800 flex items-center justify-center font-bold text-xs">
                                      <i className="fa-solid fa-user-slash" />
                                    </span>
                                    <div>
                                      <button
                                        type="button"
                                        onClick={() => openUserProfileByName(sanc.username)}
                                        className="font-bold text-sm text-stone-900 hover:text-rose-700 hover:underline cursor-pointer"
                                      >
                                        @{sanc.username}
                                      </button>
                                      <span className="ml-2 bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-bold text-[10px]">
                                        {sanc.type === 'temporal_7'
                                          ? 'Suspensión temporal (7 días)'
                                          : sanc.type === 'temporal_30'
                                          ? 'Suspensión temporal (30 días)'
                                          : 'Vetado de forma permanente'}
                                      </span>
                                    </div>
                                  </div>

                                  <button
                                    onClick={() => handleLiftSanction(sanc.username)}
                                    className="pill-btn px-3 py-1 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold cursor-pointer self-end sm:self-auto"
                                  >
                                    Levantar sanción
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 bg-white p-2.5 rounded-xl border border-rose-100 text-[11px]">
                                  <div>
                                    <span className="text-stone-500 font-bold block">Motivo de sanción:</span>
                                    <span className="font-bold text-rose-800">{sanc.reason}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 font-bold block">Administrador que sancionó:</span>
                                    <span className="font-bold text-purple-900">@{sanc.adminUsername}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 font-bold block">Fecha de sanción:</span>
                                    <span className="font-bold text-stone-700">{sanc.date}</span>
                                  </div>
                                  <div>
                                    <span className="text-stone-500 font-bold block">Levantamiento automático:</span>
                                    <span className="font-bold text-stone-700">
                                      {sanc.type === 'permanente'
                                        ? 'Permanente (no se levanta automáticamente)'
                                        : (sanc.liftDate || 'En plazo')}
                                    </span>
                                  </div>
                                </div>

                                {sanc.comment && (
                                  <p className="text-[11px] text-stone-600 bg-white p-2 rounded-lg border border-rose-100 italic">
                                    <strong>Comentario del admin:</strong> "{sanc.comment}"
                                  </p>
                                )}
                              </div>
                            ))
                        )}
                      </div>
                    </div>

                    {/* SECTION: APLICAR SANCIÓN PREVENTIVA A USUARIO */}
                    <div className="p-4 bg-white rounded-2xl border border-purple-200 space-y-3">
                      <h4 className="font-bold text-xs text-club-brown uppercase tracking-wider">
                        Suspender o Vetar nuevo usuario globalmente
                      </h4>
                      <form onSubmit={handleGlobalBan} className="space-y-3 text-xs">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          <input
                            type="text"
                            required
                            value={inputVetarGlobal}
                            onChange={(e) => setInputVetarGlobal(e.target.value)}
                            placeholder="Nombre de usuario a sancionar..."
                            className="px-3 py-2 bg-purple-50/40 border border-purple-200 rounded-xl outline-none"
                          />
                          <select
                            className="px-3 py-2 bg-purple-50/40 border border-purple-200 rounded-xl outline-none font-bold"
                            defaultValue={MOTIVOS_REPORTE[0]}
                          >
                            {MOTIVOS_REPORTE.map((m, idx) => (
                              <option key={idx} value={m}>{m}</option>
                            ))}
                          </select>
                          <select
                            className="px-3 py-2 bg-purple-50/40 border border-purple-200 rounded-xl outline-none font-bold"
                            defaultValue="temporal_7"
                          >
                            <option value="temporal_7">Suspensión temporal (7 días)</option>
                            <option value="temporal_30">Suspensión temporal (30 días)</option>
                            <option value="permanente">Vetado de forma permanente</option>
                          </select>
                        </div>
                        <button
                          type="submit"
                          className="pill-btn px-5 py-2 bg-purple-800 hover:bg-purple-900 text-white font-bold shadow-xs cursor-pointer"
                        >
                          Aplicar Sanción
                        </button>
                      </form>
                    </div>

                  </div>
                )}

              </div>
            </section>
          );
        })()}
      </main>

      {/* ========================================================= */}
      {/* ========================= MODALS ======================== */}
      {/* ========================================================= */}

      {/* MODAL: INICIAR SESIÓN */}
      {modalLoginOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-sm rounded-3xl border-2 border-amber-200 p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-amber-200 pb-2">
              <h3 className="font-brand text-xl font-bold text-club-brown">Iniciar Sesión</h3>
              <button
                onClick={() => setModalLoginOpen(false)}
                className="text-2xl text-stone-400 font-bold leading-none cursor-pointer"
              >
                &times;
              </button>
            </div>

            {loginError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                {loginError}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-3 text-xs text-club-brown">
              <div>
                <label className="block font-bold mb-1">Usuario o Correo Electrónico:</label>
                <input
                  type="text"
                  required
                  value={loginForm.usuario}
                  onChange={(e) => setLoginForm({ ...loginForm, usuario: e.target.value })}
                  placeholder="Ej: carola o carola@correo.club65.ar"
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>
              <div>
                <label className="block font-bold mb-1">Contraseña:</label>
                <input
                  type="password"
                  required
                  value={loginForm.clave}
                  onChange={(e) => setLoginForm({ ...loginForm, clave: e.target.value })}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div className="flex justify-between items-center text-[11px]">
                <button
                  type="button"
                  onClick={() => {
                    const mail = prompt('Ingresá tu correo electrónico para recibir el enlace de recuperación:');
                    if (mail) showToast(`Enlace de restablecimiento enviado a ${mail}.`);
                  }}
                  className="text-club-orange font-bold hover:underline cursor-pointer"
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </div>

              {/* Quick test accounts */}
              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 space-y-1.5 text-[11px]">
                <span className="font-bold text-stone-500 block">Acceso rápido de prueba:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => quickLogin('carola', 'caro')}
                    className="px-2.5 py-1 bg-white hover:bg-amber-100 rounded-lg border border-amber-300 font-bold text-club-brown cursor-pointer"
                  >
                    Carola (Personal)
                  </button>
                  <button
                    type="button"
                    onClick={() => quickLogin('Municipio 3F', 'untref')}
                    className="px-2.5 py-1 bg-white hover:bg-amber-100 rounded-lg border border-amber-300 font-bold text-club-brown cursor-pointer"
                  >
                    Municipio 3F (Institución)
                  </button>
                  <button
                    type="button"
                    onClick={() => quickLogin('administrador', '12345')}
                    className="px-2.5 py-1 bg-white hover:bg-amber-100 rounded-lg border border-amber-300 font-bold text-club-brown cursor-pointer"
                  >
                    Admin
                  </button>
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  type="submit"
                  className="pill-btn w-full py-2.5 bg-club-orange text-white font-bold shadow-md cursor-pointer"
                >
                  Ingresar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setModalLoginOpen(false);
                    setModalRegisterOpen(true);
                  }}
                  className="text-[11px] text-center text-stone-500 hover:text-club-brown font-bold cursor-pointer"
                >
                  ¿No tenés cuenta? Registrate acá
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTRARSE */}
      {modalRegisterOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-amber-200 pb-2">
              <h3 className="font-brand text-xl font-bold text-club-brown">Crear Nueva Cuenta</h3>
              <button
                onClick={() => setModalRegisterOpen(false)}
                className="text-2xl text-stone-400 font-bold leading-none cursor-pointer"
              >
                &times;
              </button>
            </div>

            {regError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                {regError}
              </div>
            )}

            <form onSubmit={handleRegister} className="space-y-3.5 text-xs text-club-brown">
              <div>
                <label className="block font-bold mb-1.5">¿Qué tipo de cuenta deseás registrar?</label>
                <div className="grid grid-cols-2 gap-2">
                  <label className="flex items-center gap-2 p-2.5 rounded-xl border border-amber-200 bg-white cursor-pointer font-bold">
                    <input
                      type="radio"
                      name="reg_tipo"
                      value="personal"
                      checked={regForm.tipo === 'personal'}
                      onChange={() => setRegForm({ ...regForm, tipo: 'personal' })}
                    />{' '}
                    Personal (Mayor +65)
                  </label>
                  <label className="flex items-center gap-2 p-2.5 rounded-xl border border-amber-200 bg-white cursor-pointer font-bold">
                    <input
                      type="radio"
                      name="reg_tipo"
                      value="institucional"
                      checked={regForm.tipo === 'institucional'}
                      onChange={() => setRegForm({ ...regForm, tipo: 'institucional' })}
                    />{' '}
                    Institucional
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1">
                  {regForm.tipo === 'institucional' ? 'Nombre oficial de la Institución o Centro:' : 'Nombre completo:'}
                </label>
                <input
                  type="text"
                  required
                  value={regForm.nombre}
                  onChange={(e) => setRegForm({ ...regForm, nombre: e.target.value })}
                  placeholder={regForm.tipo === 'institucional' ? 'Ej: Centro de Jubilados Caseros' : 'Ej: Mario Gómez'}
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">Nombre de Usuario (para iniciar sesión):</label>
                <input
                  type="text"
                  required
                  value={regForm.usuario}
                  onChange={(e) => setRegForm({ ...regForm, usuario: e.target.value })}
                  placeholder="Ej: mario65"
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">Correo electrónico oficial:</label>
                <input
                  type="email"
                  required
                  value={regForm.email}
                  onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                  placeholder="nombre@correo.com"
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>

              {regForm.tipo === 'institucional' && (
                <div className="p-3.5 bg-blue-50/70 border-2 border-blue-200 rounded-2xl space-y-3">
                  <div className="flex items-center gap-2 text-blue-900 font-bold">
                    <i className="fa-solid fa-shield-halved text-club-teal text-base" />
                    <span>Datos de Validación y Personería Jurídica</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-bold mb-1">Tipo de entidad:</label>
                      <select
                        value={regForm.entidadTipo}
                        onChange={(e) => setRegForm({ ...regForm, entidadTipo: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white border border-blue-200 rounded-xl outline-none text-xs"
                      >
                        <option value="municipio">Municipio / Ente Estatal</option>
                        <option value="centro">Centro de Jubilados</option>
                        <option value="club">Club Social y Deportivo</option>
                        <option value="ong">Asociación Civil / ONG</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold mb-1">CUIT / N° de Personería:</label>
                      <input
                        type="text"
                        value={regForm.cuit}
                        onChange={(e) => setRegForm({ ...regForm, cuit: e.target.value })}
                        placeholder="30-XXXXXXXX-X"
                        className="w-full px-2.5 py-1.5 bg-white border border-blue-200 rounded-xl outline-none text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Número de contacto institucional: *</label>
                    <input
                      type="text"
                      required={regForm.tipo === 'institucional'}
                      value={regForm.contactoInstitucional}
                      onChange={(e) => setRegForm({ ...regForm, contactoInstitucional: e.target.value })}
                      placeholder="Ej: 11 4750-1234 / 11 5533-8899"
                      className="w-full px-2.5 py-1.5 bg-white border border-blue-200 rounded-xl outline-none text-xs"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold mb-1">Contraseña:</label>
                  <input
                    type="password"
                    required
                    value={regForm.clave}
                    onChange={(e) => setRegForm({ ...regForm, clave: e.target.value })}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1">Localidad (Barrio):</label>
                  <input
                    type="text"
                    required
                    value={regForm.localidad}
                    onChange={(e) => setRegForm({ ...regForm, localidad: e.target.value })}
                    placeholder="Ej: Caseros"
                    className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1.5">
                <label className="flex items-start gap-2 cursor-pointer font-bold text-[11px]">
                  <input
                    type="checkbox"
                    required
                    checked={regForm.terminos}
                    onChange={(e) => setRegForm({ ...regForm, terminos: e.target.checked })}
                    className="mt-0.5"
                  />
                  <span>Acepto los Términos y Condiciones y las Políticas de Privacidad y Convivencia de CLUB65.</span>
                </label>
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  type="submit"
                  className="pill-btn w-full py-2.5 bg-club-orange text-white font-bold shadow-md cursor-pointer"
                >
                  Crear mi cuenta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDITAR MI PERFIL */}
      {modalEditProfileOpen && currentUser && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden flex flex-col">
            <div className="p-4 bg-white border-b border-amber-200">
              <h3 className="font-brand text-lg font-bold text-club-brown">Mi Perfil</h3>
            </div>

            <form onSubmit={handleSaveProfile} className="p-5 space-y-4 text-xs text-club-brown">
              <div className="flex items-center gap-4">
                <img
                  src={profileForm.avatar}
                  alt={profileForm.apodo}
                  className="w-16 h-16 rounded-full object-cover border-2 border-club-orange shadow-sm cursor-pointer"
                  onClick={() => setModalVisorImgSrc(profileForm.avatar)}
                  title="Hacé clic para ver en grande"
                />
                <div className="space-y-1">
                  <p className="text-xs font-black text-club-brown">
                    Usuario: <span className="text-club-orange">@{currentUser.usuario}</span>
                  </p>
                  <label className="pill-btn px-3.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-club-brown font-bold border border-amber-300 cursor-pointer inline-flex items-center gap-1.5">
                    <i className="fa-solid fa-upload text-club-orange" /> Subir foto desde mi dispositivo
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleProfilePhotoFile}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-bold mb-1 text-club-brown">Nombre o Apodo en la plataforma:</label>
                <input
                  type="text"
                  required
                  value={profileForm.apodo}
                  onChange={(e) => setProfileForm({ ...profileForm, apodo: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none text-xs font-bold focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-bold text-club-brown">Breve descripción:</label>
                  <span className="text-[10px] text-stone-400">{profileForm.bio.length} / 140</span>
                </div>
                <textarea
                  maxLength={140}
                  rows={3}
                  value={profileForm.bio}
                  onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                  placeholder="Contá un poco sobre tus gustos o hobbies..."
                  className="w-full p-2.5 bg-white border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-amber-200">
                <button
                  type="button"
                  onClick={() => setModalEditProfileOpen(false)}
                  className="pill-btn px-4 py-2 bg-stone-100 text-stone-700 font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="pill-btn px-5 py-2 bg-club-orange text-white font-bold shadow-sm cursor-pointer"
                >
                  Guardar cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRMAR CANCELACIÓN */}
      {modalConfirmarCancelacion && (
        <div className="fixed inset-0 bg-black/75 z-[60] flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-rose-300 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="w-12 h-12 rounded-full bg-rose-100 flex items-center justify-center text-2xl flex-shrink-0">
                <i className="fa-solid fa-triangle-exclamation" />
              </div>
              <div>
                <h3 className="font-brand text-lg font-bold text-club-brown">Cancelar Actividad</h3>
                <p className="text-xs text-rose-600 font-semibold">Esta acción no se puede deshacer.</p>
              </div>
            </div>

            <p className="text-xs text-club-brown leading-relaxed bg-white p-3.5 rounded-2xl border border-rose-200">
              ¿Estás seguro de que querés cancelar tu actividad "{modalConfirmarCancelacion.nombre}" programada para {modalConfirmarCancelacion.dia} a las {modalConfirmarCancelacion.hora}?
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t border-amber-200">
              <button
                onClick={() => setModalConfirmarCancelacion(null)}
                className="pill-btn px-5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                NO
              </button>
              <button
                onClick={executeCancelActivity}
                className="pill-btn px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-sm cursor-pointer"
              >
                SÍ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: VER PARTICIPANTES CON AGENDAR CONTACTO Y MODERADOR BADGE */}
      {modalVerParticipantesOpen && activeChat && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-5 space-y-4 shadow-xl">
            <div className="flex justify-between items-center border-b border-amber-200 pb-2">
              <h3 className="font-brand text-lg font-bold text-club-brown">Participantes del Grupo</h3>
              <button
                onClick={() => setModalVerParticipantesOpen(false)}
                className="text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-2 text-xs max-h-80 overflow-y-auto">
              {(activeChat.participants && activeChat.participants.length > 0
                ? activeChat.participants
                : [currentUser ? currentUser.apodo : 'Carola Márquez', 'Roberto Gómez', 'Graciela Pérez']
              ).map((partName, idx) => {
                const contactInfo = contacts.find(c => c.nombre === partName);
                const isModerator = partName === activeChat.creatorName ||
                  partName === activeChat.organizerId ||
                  (activeChat.id === 10 && partName === 'Carola Márquez') ||
                  (currentUser && partName === currentUser.apodo && isCurrentUserModeratorOfActiveChat);
                const isSelf = !!currentUser && (partName === currentUser.apodo || partName === currentUser.usuario);
                const yaEsContacto = currentUser ? (isSelf || contacts.some(c => c.nombre === partName)) : false;

                return (
                  <div key={idx} className="p-3 bg-white rounded-2xl border border-amber-200 flex justify-between items-center">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-club-blue text-club-brown font-bold flex items-center justify-center text-xs overflow-hidden">
                        {contactInfo?.foto ? (
                          <img src={contactInfo.foto} alt={partName} className="w-full h-full object-cover" />
                        ) : (
                          partName.slice(0, 2).toUpperCase()
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="font-bold text-xs text-club-brown">{partName}</p>
                          {isModerator && (
                            <span className="text-[9px] font-bold bg-amber-200 text-amber-950 px-1.5 py-0.2 rounded-full">
                              👑 Moderadora
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-stone-400">
                          {contactInfo?.detalle || (isSelf ? 'Tú' : 'Participante')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {currentUser && !isSelf && (
                        yaEsContacto ? (
                          <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <i className="fa-solid fa-check mr-1" /> Agendado
                          </span>
                        ) : (
                          <button
                            onClick={() => handleAgendarContacto(partName, 'Tres de Febrero', partName.slice(0, 2).toUpperCase(), 'bg-club-teal', 'Miembro del grupo.')}
                            className="pill-btn px-2.5 py-1 bg-club-teal text-white font-bold text-[10px] shadow-xs hover:bg-club-teal/80 cursor-pointer"
                          >
                            <i className="fa-solid fa-user-plus mr-1" /> Agendar
                          </button>
                        )
                      )}
                      <button
                        onClick={() => {
                          setModalVerParticipantesOpen(false);
                          setModalPerfilContacto(contactInfo || {
                            id: `part_${idx}`,
                            nombre: partName,
                            detalle: 'Participante del grupo',
                            avatar: partName.slice(0, 2).toUpperCase(),
                            avatarClass: 'bg-club-blue',
                            bio: 'Miembro activo de la comunidad de CLUB65.',
                            foto: undefined
                          });
                        }}
                        className="pill-btn px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-club-brown font-bold text-[10px] border border-amber-300 cursor-pointer"
                      >
                        Ver perfil
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-2 flex justify-end border-t border-amber-200">
              <button
                onClick={() => setModalVerParticipantesOpen(false)}
                className="pill-btn px-4 py-2 bg-stone-100 text-stone-700 font-bold text-xs cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DETALLE DE ACTIVIDAD (Con Días y Horarios vs Día y Horario y Evento Recurrente/Único) */}
      {modalActividad && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-2xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 bg-white border-b border-amber-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={closeModalDetalle}
                  className="w-9 h-9 rounded-full bg-amber-100 hover:bg-amber-200 text-club-brown flex items-center justify-center font-bold cursor-pointer"
                >
                  <i className="fa-solid fa-arrow-left" />
                </button>
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className={`text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full inline-block ${
                        modalActividad.isInstitutional
                          ? 'bg-blue-100 text-blue-900'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {modalActividad.isInstitutional ? (
                        <>
                          <i className="fa-solid fa-circle-check text-blue-600 mr-1" /> Institución Verificada
                        </>
                      ) : (
                        <>
                          <i className="fa-solid fa-users text-club-orange mr-1" /> Actividad de la comunidad
                        </>
                      )}
                    </span>
                  </div>

                  <h3 className="font-brand text-xl sm:text-2xl font-bold text-club-brown mt-0.5">
                    {modalActividad.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={closeModalDetalle}
                className="text-stone-400 hover:text-club-brown text-xl p-1 cursor-pointer"
              >
                <i className="fa-solid fa-xmark" />
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-club-brown">
              <div className="p-3.5 bg-amber-100/70 rounded-2xl border border-amber-300 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-full flex items-center justify-center text-lg font-bold shadow-xs ${
                      modalActividad.isInstitutional ? 'bg-club-blue text-club-brown' : 'bg-club-orange text-white'
                    }`}
                  >
                    {modalActividad.isInstitutional ? <i className="fa-solid fa-landmark" /> : <i className="fa-solid fa-user" />}
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-stone-500 uppercase block">Organizado por</span>
                    <p className="font-bold text-sm text-club-brown flex items-center gap-1">
                      {modalActividad.organizer}
                      {modalActividad.isInstitutional && <i className="fa-solid fa-circle-check text-blue-600 text-xs" />}
                    </p>
                    <p className="text-[11px] text-stone-600">
                      {modalActividad.isInstitutional ? 'Institución oficial verificada • Tres de Febrero' : 'Iniciativa de vecino/a de la comunidad'}
                    </p>
                  </div>
                </div>

                {currentUser && (
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      onClick={() => {
                        setModalDetalleId(null);
                        setModalPerfilContacto({
                          id: `org_${modalActividad.id}`,
                          nombre: modalActividad.organizer,
                          detalle: modalActividad.isInstitutional ? 'Institución oficial' : 'Vecino organizador',
                          avatar: modalActividad.organizer.slice(0, 2).toUpperCase(),
                          avatarClass: modalActividad.isInstitutional ? 'bg-club-blue' : 'bg-club-orange',
                          bio: modalActividad.organizerBio || 'Organizador activo de actividades en CLUB65.',
                          foto: modalActividad.isInstitutional ? 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=100&h=100&fit=crop' : 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop'
                        });
                      }}
                      className="pill-btn px-3 py-1.5 bg-white hover:bg-amber-50 text-club-brown text-xs font-bold border border-amber-300 cursor-pointer"
                    >
                      Ver perfil
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-4 rounded-2xl border border-amber-200/70 text-sm">
                <div>
                  {/* Dynamic label: Días y Horarios if recurrent, Día y Horario if unique */}
                  <p className="text-xs text-stone-500 font-bold">
                    {modalActividad.isRecurrent ? 'Días y Horarios' : 'Día y Horario'}
                  </p>
                  <p className="font-bold text-club-brown">{modalActividad.schedule}</p>
                </div>
                <div>
                  <p className="text-xs text-stone-500 font-bold">Cupos</p>
                  <p className="font-bold text-club-brown">
                    {modalActividad.enrolledUsernames ? modalActividad.enrolledUsernames.length : modalActividad.enrolledCount} de {modalActividad.capacity} inscriptos ({Math.max(0, modalActividad.capacity - (modalActividad.enrolledUsernames ? modalActividad.enrolledUsernames.length : modalActividad.enrolledCount))} vacantes libres)
                  </p>
                </div>
              </div>

              {/* Opiniones de vecinos */}
              {didOtherBlockMe(modalActividad.organizer) ? (
                <div className="p-3 bg-stone-100 rounded-2xl border border-stone-200 text-stone-500 text-xs font-semibold">
                  <i className="fa-solid fa-ban mr-1.5" /> Reseñas no disponibles (el organizador te ha bloqueado)
                </div>
              ) : isUserBlocked(modalActividad.organizer) ? (
                <div className="p-3 bg-stone-100 rounded-2xl border border-stone-200 text-stone-500 text-xs font-semibold">
                  <i className="fa-solid fa-ban mr-1.5" /> Reseñas no disponibles (organizador bloqueado)
                </div>
              ) : (
                <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between">
                  <div className="text-xs">
                    <span className="font-bold text-club-brown block">Esta actividad cuenta con opiniones de vecinos</span>
                    <span className="text-stone-500 text-[11px]">Consultá las valoraciones y fotos de los participantes.</span>
                  </div>
                  <button
                    onClick={() => {
                      const id = modalActividad.id;
                      setResenasOriginActivityId(id);
                      setModalDetalleId(null);
                      setModalOpinionesId(id);
                    }}
                    className="pill-btn px-3.5 py-1.5 bg-amber-200 hover:bg-amber-300 text-club-brown font-bold text-xs border border-amber-400 flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <i className="fa-solid fa-star text-club-orange" /> Ver Reseñas
                  </button>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                  <h4 className="font-brand text-lg font-bold text-club-brown">Sobre este encuentro</h4>
                  <span
                    className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border shadow-xs ${
                      modalActividad.isRecurrent
                        ? 'bg-amber-100 text-amber-900 border-amber-300'
                        : 'bg-purple-100 text-purple-900 border-purple-200'
                    }`}
                  >
                    <i className={`fa-solid ${modalActividad.isRecurrent ? 'fa-repeat text-club-orange' : 'fa-calendar-day text-purple-700'} mr-1`} />
                    {modalActividad.isRecurrent ? 'Encuentro recurrente' : 'Encuentro único'}
                  </span>
                </div>
                {/* Lo que está en "Acerca del evento (Detalles)" aparece aquí */}
                <p className="text-sm text-club-brown/90 leading-relaxed whitespace-pre-line">
                  {modalActividad.description}
                </p>
              </div>

              {/* Ubicación y Mapa */}
              <div className="bg-white p-4 rounded-2xl border border-amber-200">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-brand text-base font-bold text-club-brown flex items-center gap-2">
                      <i className="fa-solid fa-map-location-dot text-club-orange" /> Ubicación
                    </h4>
                    <p className={`text-xs font-semibold ${isUserBlocked(modalActividad.organizer) ? 'text-rose-700 italic' : 'text-club-brown/80'}`}>
                      {didOtherBlockMe(modalActividad.organizer)
                        ? 'El organizador te ha bloqueado'
                        : didIBlockUser(modalActividad.organizer) || isUserBlocked(modalActividad.organizer)
                        ? 'Desbloqueá al organizador para ver ubicación'
                        : modalActividad.location}
                    </p>
                  </div>
                  {!isUserBlocked(modalActividad.organizer) && (
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(modalActividad.location)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="pill-btn px-3.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold flex items-center gap-1.5 border border-blue-200 shadow-2xs"
                      title="Abrir indicaciones en Google Maps"
                    >
                      <i className="fa-solid fa-diamond-turn-right text-blue-600" /> Cómo llegar
                    </a>
                  )}
                </div>
                {!isUserBlocked(modalActividad.organizer) && (
                  <div className="mt-2 rounded-2xl overflow-hidden border border-amber-200 shadow-inner">
                    <LeafletMap
                      lat={modalActividad.lat}
                      lng={modalActividad.lng}
                      title={modalActividad.title}
                      locationName={modalActividad.location}
                      height={260}
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 bg-white border-t border-amber-200 flex items-center justify-end gap-2">
              {modalCustomActivity ? (
                <div className="w-full flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-purple-900 bg-purple-50 px-3 py-1.5 rounded-xl border border-purple-200 flex items-center gap-1.5">
                    <i className="fa-solid fa-eye text-purple-600" /> Vista previa de versión
                  </span>
                  <button
                    onClick={closeModalDetalle}
                    className="pill-btn px-5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs border border-stone-300 cursor-pointer"
                  >
                    Cerrar detalle
                  </button>
                </div>
              ) : !currentUser ? (
                <button
                  onClick={() => {
                    setModalDetalleId(null);
                    setModalLoginOpen(true);
                  }}
                  className="pill-btn px-6 py-3 bg-club-orange text-white text-xs font-bold shadow-md cursor-pointer"
                >
                  Iniciá sesión para anotarte
                </button>
              ) : isUserBlocked(modalActividad.organizer) ? (
                <span className="text-xs font-bold text-rose-700 bg-rose-50 px-4 py-2 rounded-xl border border-rose-200">
                  <i className="fa-solid fa-user-slash mr-1" />
                  {didOtherBlockMe(modalActividad.organizer)
                    ? 'El organizador te ha bloqueado'
                    : 'Desbloqueá al organizador para ver ubicación'}
                </span>
              ) : currentUser.id === modalActividad.organizerId || (modalActividad.id === 10 && currentUser.usuario === 'carola') ? (
                <>
                  <button
                    onClick={() => {
                      setModalDetalleId(null);
                      setModalModeracionActividadId(modalActividad.id);
                    }}
                    className="pill-btn px-5 py-2.5 bg-amber-100 hover:bg-amber-200 text-club-brown text-xs font-bold border border-amber-300 flex items-center gap-1.5 cursor-pointer"
                  >
                    <i className="fa-solid fa-sliders text-club-orange" /> Moderar mi actividad
                  </button>
                  <button
                    onClick={() => {
                      setModalDetalleId(null);
                      setCurrentView('chat');
                      const c = chats.find(x => x.activityId === modalActividad.id);
                      if (c) setActiveChatId(c.id);
                    }}
                    className="pill-btn px-5 py-2.5 bg-club-teal text-white text-xs font-bold cursor-pointer"
                  >
                    Ir al Chat del Encuentro
                  </button>
                </>
              ) : currentUser.tipo === 'personal' ? (
                modalActividad.enrolledUsernames?.includes(currentUser.usuario) ? (
                  <button
                    onClick={() => toggleEnrollment(modalActividad.id)}
                    className="pill-btn px-6 py-3 bg-emerald-600 text-white text-xs font-bold shadow-md cursor-pointer"
                  >
                    Inscripta ✓ (Cancelar inscripción)
                  </button>
                ) : (
                  <button
                    onClick={() => toggleEnrollment(modalActividad.id)}
                    className="pill-btn px-6 py-3 bg-club-orange text-white text-xs font-bold shadow-md cursor-pointer"
                  >
                    Preinscribirme a la actividad
                  </button>
                )
              ) : (
                <span className="text-xs font-bold text-stone-500">Inscripción inhabilitada para este perfil</span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RESEÑAS DE LA COMUNIDAD (Si se abrió desde detalle, al cerrar vuelve a detalle) */}
      {modalOpinionesId !== null && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-3xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold bg-amber-200 text-club-brown px-2.5 py-0.5 rounded-full uppercase">
                  Reseñas de la comunidad
                </span>
                <h3 className="font-brand text-xl font-bold text-club-brown mt-1">
                  Opiniones y Experiencias ({opinionesActividad.length} reseñas)
                </h3>
              </div>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs text-club-brown">
              {opinionesActividad.length === 0 ? (
                <p className="p-8 text-center text-sm text-stone-500 font-semibold">Esta actividad aún no cuenta con reseñas</p>
              ) : (
                opinionesActividad.map((r) => {
                  const mediaItems = r.media && r.media.length ? r.media : (r.foto ? [r.foto] : []);

                  return (
                    <div key={r.id} className="bg-white p-4 rounded-2xl border border-amber-200 space-y-2">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-club-brown text-sm">{r.autor}</span>
                          {currentUser && currentUser.apodo !== r.autor && (
                            <button
                              type="button"
                              onClick={() => openReportModal({
                                type: 'review_text',
                                reviewId: r.id,
                                activityId: r.actividadId,
                                reportedUser: r.autor,
                                messageText: r.texto
                              })}
                              className="text-[11px] text-stone-400 hover:text-rose-600 font-bold flex items-center gap-1 cursor-pointer transition ml-2"
                              title="Reportar esta reseña"
                            >
                              <i className="fa-solid fa-flag text-[10px]" /> Reportar
                            </button>
                          )}
                        </div>
                        <span className="text-[11px] text-stone-400">
                          {Array.from({ length: r.estrellas }).map((_, i) => (
                            <i key={i} className="fa-solid fa-star text-amber-400" />
                          ))}{' '}
                          • {r.fecha}
                        </span>
                      </div>
                      <p className="text-stone-600 text-xs leading-relaxed italic">"{r.texto}"</p>

                      {/* Multi-media gallery items */}
                      {mediaItems.length > 0 && (
                        <div className="mt-2.5 flex flex-wrap gap-2">
                          {mediaItems.map((url, mIdx) => {
                            const isVid = isVideoMedia(url);
                            return (
                              <div
                                key={mIdx}
                                className="rounded-xl overflow-hidden h-28 w-36 border border-amber-200 relative shadow-xs bg-black flex items-center justify-center cursor-pointer group"
                                onClick={() => openGalleryVisor(url, r.actividadId)}
                              >
                                {isVid ? (
                                  <div className="w-full h-full relative flex items-center justify-center">
                                    <video
                                      src={url}
                                      playsInline
                                      preload="metadata"
                                      className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition pointer-events-none"
                                    />
                                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition">
                                      <div className="w-10 h-10 rounded-full bg-club-orange/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                                        <i className="fa-solid fa-play text-sm ml-0.5" />
                                      </div>
                                    </div>
                                    <span className="absolute bottom-1 left-1.5 bg-black/75 text-white text-[9px] px-1.5 py-0.5 rounded font-bold">
                                      <i className="fa-solid fa-video mr-1" /> Video
                                    </span>
                                  </div>
                                ) : (
                                  <img
                                    src={url}
                                    alt={`Foto ${mIdx + 1}`}
                                    className="w-full h-full object-cover group-hover:scale-105 transition"
                                  />
                                )}
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openGalleryVisor(url, r.actividadId);
                                  }}
                                  className="absolute top-1 right-1 bg-black/60 hover:bg-club-orange text-white text-[10px] px-1.5 py-0.5 rounded-md font-bold cursor-pointer"
                                  title="Ver en pantalla completa"
                                >
                                  <i className="fa-solid fa-expand" />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-3 bg-white border-t border-amber-200 flex justify-end">
              <button
                onClick={() => {
                  if (resenasOriginActivityId) {
                    setModalDetalleId(resenasOriginActivityId);
                    setResenasOriginActivityId(null);
                  }
                  setModalOpinionesId(null);
                }}
                className="pill-btn px-5 py-2 bg-club-orange text-white text-xs font-bold shadow-sm cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: GALERÍA VISOR DE FOTOS CON FLECHAS, TRES PUNTITOS PARA REPORTAR, RESEÑA ESCRITA Y AUTOR */}
      {modalGaleriaOpen && galeriaItems.length > 0 && (
        <div
          className="fixed inset-0 bg-black/90 z-[75] flex items-center justify-center p-3 sm:p-6"
          onClick={() => setModalGaleriaOpen(false)}
        >
          <div
            className="relative max-w-2xl w-full bg-[#18110D] border-2 border-amber-500/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-white"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Bar with counter, three dots and close */}
            <div className="p-4 bg-black/40 border-b border-amber-500/20 flex justify-between items-center text-xs">
              <span className="font-bold text-amber-200">
                <i className="fa-solid fa-camera mr-1 text-club-orange" />
                Foto {galeriaIndex + 1} de {galeriaItems.length}
              </span>
              <div className="flex items-center gap-2">
                {/* Three dots options menu on expanded media: do NOT show for own media */}
                {currentUser &&
                  galeriaItems[galeriaIndex]?.autor !== currentUser.apodo &&
                  galeriaItems[galeriaIndex]?.autor !== currentUser.usuario && (
                  <div className="relative">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setVisorMenuOpen(!visorMenuOpen);
                      }}
                      className="p-1.5 text-stone-300 hover:text-white rounded-md cursor-pointer text-sm"
                      title="Opciones"
                    >
                      <i className="fa-solid fa-ellipsis-vertical" />
                    </button>

                    {visorMenuOpen && (
                      <div className="absolute right-0 top-7 bg-white text-club-brown rounded-xl shadow-xl z-50 py-1 min-w-[120px] text-xs">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setVisorMenuOpen(false);
                            setModalConfirmReportVisor(true);
                          }}
                          className="w-full px-3 py-1.5 text-left hover:bg-rose-50 text-rose-700 font-bold flex items-center gap-1.5 cursor-pointer"
                        >
                          <i className="fa-solid fa-flag text-rose-600 text-[10px]" /> Reportar
                        </button>
                      </div>
                    )}
                  </div>
                )}

                <button
                  onClick={() => setModalGaleriaOpen(false)}
                  className="pill-btn px-3 py-1 bg-stone-800 hover:bg-stone-700 text-white text-xs font-bold cursor-pointer"
                >
                  Cerrar &times;
                </button>
              </div>
            </div>

            {/* Media Area with Left & Right arrows */}
            <div className="relative h-80 sm:h-96 bg-black flex items-center justify-center overflow-hidden">
              {isVideoMedia(galeriaItems[galeriaIndex]?.mediaUrl) ? (
                <video
                  key={galeriaItems[galeriaIndex]?.mediaUrl}
                  src={galeriaItems[galeriaIndex]?.mediaUrl}
                  controls
                  autoPlay
                  playsInline
                  className="max-h-full max-w-full object-contain"
                />
              ) : (
                <img
                  src={galeriaItems[galeriaIndex]?.mediaUrl}
                  alt="Foto reseña"
                  className="max-h-full max-w-full object-contain"
                />
              )}

              {/* Prev Button */}
              {galeriaItems.length > 1 && (
                <button
                  onClick={handleGaleriaPrev}
                  className="absolute left-3 w-10 h-10 rounded-full bg-black/70 hover:bg-club-orange text-white flex items-center justify-center text-base transition border border-white/20 cursor-pointer shadow-lg"
                  title="Foto anterior"
                >
                  <i className="fa-solid fa-chevron-left" />
                </button>
              )}

              {/* Next Button */}
              {galeriaItems.length > 1 && (
                <button
                  onClick={handleGaleriaNext}
                  className="absolute right-3 w-10 h-10 rounded-full bg-black/70 hover:bg-club-orange text-white flex items-center justify-center text-base transition border border-white/20 cursor-pointer shadow-lg"
                  title="Foto siguiente"
                >
                  <i className="fa-solid fa-chevron-right" />
                </button>
              )}
            </div>

            {/* Bottom info section: Review written text, Author, Rating, Activity */}
            <div className="p-4 sm:p-5 bg-[#241712] border-t border-amber-500/20 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-club-orange text-white font-bold flex items-center justify-center text-xs">
                    {galeriaItems[galeriaIndex]?.autor.charAt(0)}
                  </div>
                  <div>
                    <span className="font-bold text-amber-200 block">{galeriaItems[galeriaIndex]?.autor}</span>
                    <span className="text-[10px] text-stone-400">{galeriaItems[galeriaIndex]?.actividad}</span>
                  </div>
                </div>
                <div className="text-amber-400 text-sm flex items-center gap-1">
                  {Array.from({ length: galeriaItems[galeriaIndex]?.estrellas || 5 }).map((_, i) => (
                    <i key={i} className="fa-solid fa-star" />
                  ))}
                  <span className="text-[10px] text-stone-400 ml-1">• {galeriaItems[galeriaIndex]?.fecha}</span>
                </div>
              </div>

              <div className="p-3 bg-black/30 rounded-2xl border border-amber-900/40 text-xs sm:text-sm text-amber-100/90 leading-relaxed italic">
                "{galeriaItems[galeriaIndex]?.texto}"
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ESCRIBIR O EDITAR RESEÑA (Con soporte para adjuntar/eliminar múltiples fotos sin reemplazarlas) */}
      {modalEscribirResenaOpen && resenaEditData && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-lg rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden flex flex-col max-h-[92vh]">
            <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
              <h3 className="font-brand text-lg font-bold text-club-brown">
                {resenaEditData.id ? 'Editar mi reseña' : 'Dejar mi reseña'}
              </h3>
              <button
                onClick={() => setModalEscribirResenaOpen(false)}
                className="pill-btn px-3 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cerrar
              </button>
            </div>

            <form onSubmit={handleGuardarResena} className="p-5 space-y-4 text-xs text-club-brown overflow-y-auto">
              <div>
                <span className="text-[10px] font-bold text-stone-500 uppercase">Actividad:</span>
                <h4 className="font-bold text-base text-club-brown">{resenaEditData.actividad}</h4>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-club-brown block">¿Cómo calificarías este encuentro?</label>
                <div className="flex gap-2 text-2xl text-amber-400 cursor-pointer">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <i
                      key={num}
                      className={num <= califEstrellas ? 'fa-solid fa-star text-amber-400' : 'fa-regular fa-star text-stone-300'}
                      onClick={() => setCalifEstrellas(num)}
                    />
                  ))}
                </div>
                <span className="text-[11px] text-stone-500 font-bold">
                  {['Muy mala (1/5)', 'Regular (2/5)', 'Buena (3/5)', 'Muy buena (4/5)', 'Excelente (5/5)'][califEstrellas - 1]}
                </span>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-club-brown block">Escribí tu opinión para los demás vecinos:</label>
                <textarea
                  rows={3}
                  required
                  value={textoResena}
                  onChange={(e) => setTextoResena(e.target.value)}
                  placeholder="Contanos qué te parecieron los profesores, la música o el grupo..."
                  className="w-full p-3 bg-white border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                />
              </div>

              {/* Multi-media upload and management */}
              <div className="space-y-2 bg-amber-50 p-3.5 rounded-2xl border border-amber-200">
                <div className="p-2.5 bg-amber-100/80 border border-amber-300 rounded-xl text-[11px] text-amber-950 font-semibold flex items-center gap-2">
                  <i className="fa-solid fa-clock text-club-orange text-sm flex-shrink-0" />
                  <span><strong>Límite de duración:</strong> La duración máxima permitida para los videos es de <strong>45 segundos</strong>.</span>
                </div>

                <label className="font-bold text-club-brown flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <i className="fa-solid fa-camera text-club-orange" /> Fotos o videos de la actividad ({archivosResena.length})
                  </span>
                  <label className="pill-btn px-3 py-1 bg-club-orange text-white text-[11px] font-bold cursor-pointer hover:bg-club-orange-dark shadow-xs inline-flex items-center gap-1">
                    <i className="fa-solid fa-plus" /> Agregar fotos/videos
                    <input
                      type="file"
                      accept="image/*,video/*"
                      multiple
                      onChange={handleMultiMediaReviewFiles}
                      className="hidden"
                    />
                  </label>
                </label>

                {archivosResena.length === 0 ? (
                  <p className="text-[11px] text-stone-500 italic py-2 text-center">
                    No hay fotos o videos adjuntos aún. Podés subir más de uno.
                  </p>
                ) : (
                  <div className="grid grid-cols-3 gap-2 pt-1 max-h-48 overflow-y-auto">
                    {archivosResena.map((url, idx) => {
                      const isVid = isVideoMedia(url);
                      return (
                        <div key={idx} className="relative group rounded-xl overflow-hidden border border-amber-300 h-24 bg-black flex items-center justify-center">
                          {isVid ? (
                            <video src={url} controls className="w-full h-full object-contain" />
                          ) : (
                            <img src={url} alt={`Adjunto ${idx + 1}`} className="w-full h-full object-cover" />
                          )}
                          <button
                            type="button"
                            onClick={() => handleRemoveReviewMedia(idx)}
                            className="absolute top-1 right-1 w-6 h-6 rounded-full bg-rose-600 text-white font-bold text-xs flex items-center justify-center hover:bg-rose-700 shadow z-10 cursor-pointer"
                            title="Eliminar este contenido"
                          >
                            &times;
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-amber-200">
                <button
                  type="button"
                  onClick={() => setModalEscribirResenaOpen(false)}
                  className="pill-btn px-4 py-2 bg-stone-100 text-stone-700 font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="pill-btn px-5 py-2 bg-club-orange text-white font-bold shadow-sm cursor-pointer"
                >
                  {resenaEditData.id ? 'Guardar cambios' : 'Publicar mi reseña'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: MIS CONTACTOS (Con opción de desagendar / eliminar contacto) */}
      {modalDirectorioOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-5 space-y-4">
            <div className="flex justify-between items-center border-b border-amber-200 pb-2">
              <h3 className="font-brand text-lg font-bold text-club-brown flex items-center gap-2">
                <i className="fa-solid fa-address-book text-club-orange" /> Contactos de CLUB65
              </h3>
              <button
                onClick={() => setModalDirectorioOpen(false)}
                className="text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>
            <p className="text-xs text-stone-600">Explorá a los vecinos y miembros que tenés agendados:</p>

            <div className="space-y-2 max-h-72 overflow-y-auto">
              {contacts.length === 0 ? (
                <p className="p-3 text-center text-xs text-stone-400">No tenés contactos agendados aún.</p>
              ) : (
                contacts.map((u) => (
                  <div key={u.id} className="p-3 bg-white rounded-2xl border border-amber-200 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-full ${u.avatarClass} text-white font-bold flex items-center justify-center text-xs overflow-hidden`}>
                        {u.foto ? <img src={u.foto} alt={u.nombre} className="w-full h-full object-cover" /> : u.avatar}
                      </div>
                      <div>
                        <p className="font-bold text-xs text-club-brown">{u.nombre}</p>
                        <p className="text-[10px] text-stone-500">{u.detalle}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setModalDirectorioOpen(false);
                          setModalPerfilContacto(u);
                        }}
                        className="pill-btn px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-club-brown font-bold text-xs border border-amber-300 cursor-pointer"
                      >
                        Ver perfil
                      </button>
                      {/* Desagendar / Borrar contacto option */}
                      <button
                        onClick={() => handleDesagendarContacto(u.id, u.nombre)}
                        className="pill-btn px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 flex items-center gap-1 cursor-pointer"
                        title="Desagendar contacto"
                      >
                        <i className="fa-solid fa-user-minus" /> Desagendar
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: FICHA DE PERFIL DE CONTACTO */}
      {modalPerfilContacto && (
        <div className="fixed inset-0 bg-black/60 z-[105] flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-5 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-amber-200 pb-3">
              <div className="flex items-center gap-3">
                <div
                  className="cursor-pointer"
                  onClick={() => {
                    if (modalPerfilContacto.foto) setModalVisorImgSrc(modalPerfilContacto.foto);
                  }}
                >
                  {modalPerfilContacto.foto ? (
                    <img
                      src={modalPerfilContacto.foto}
                      alt={modalPerfilContacto.nombre}
                      className="w-14 h-14 rounded-full object-cover border-2 border-club-orange shadow-sm"
                    />
                  ) : (
                    <div className={`w-14 h-14 rounded-full ${modalPerfilContacto.avatarClass} text-club-brown flex items-center justify-center text-lg font-bold shadow-sm`}>
                      {modalPerfilContacto.avatar}
                    </div>
                  )}
                </div>
                <div>
                  <h4 className="font-bold text-base text-club-brown">{modalPerfilContacto.nombre}</h4>
                  <span className="text-[10px] text-emerald-700 bg-emerald-100 font-bold px-2 py-0.5 rounded-full">
                    Miembro Verificado
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {currentUser && currentUser.apodo !== modalPerfilContacto.nombre && currentUser.usuario !== modalPerfilContacto.nombre && (() => {
                  const isBlockedByMe = didIBlockContact(modalPerfilContacto) || didIBlockUser(modalPerfilContacto.nombre);
                  const isOtherBlockingMe = didOtherBlockMe(modalPerfilContacto.nombre);

                  if (isOtherBlockingMe) {
                    return (
                      <span className="text-[10px] font-bold text-rose-800 bg-rose-100 border border-rose-300 px-2 py-0.5 rounded-full">
                        <i className="fa-solid fa-lock mr-1" /> Bloqueado por el usuario
                      </span>
                    );
                  }

                  if (isBlockedByMe) {
                    return (
                      <button
                        type="button"
                        onClick={() => handleUnblockUser(modalPerfilContacto.nombre)}
                        className="pill-btn px-3 py-1 text-xs font-bold border transition cursor-pointer bg-stone-200 hover:bg-stone-300 text-stone-800 border-stone-300 flex items-center gap-1 shadow-xs"
                        title="Hacé clic para desbloquear al usuario"
                      >
                        <i className="fa-solid fa-user-lock text-stone-600" /> Bloqueado
                      </button>
                    );
                  }

                  return (
                    <button
                      type="button"
                      onClick={() => handleBlockUser(modalPerfilContacto.nombre)}
                      className="pill-btn px-3 py-1 text-xs font-bold border transition cursor-pointer bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-300 shadow-xs"
                    >
                      Bloquear
                    </button>
                  );
                })()}
                <button
                  onClick={() => setModalPerfilContacto(null)}
                  className="text-xl font-bold text-stone-400 cursor-pointer"
                >
                  &times;
                </button>
              </div>
            </div>

            {didOtherBlockMe(modalPerfilContacto.nombre) ? (
              <div className="p-6 bg-rose-50 border-2 border-rose-300 rounded-2xl text-center space-y-2">
                <i className="fa-solid fa-user-slash text-2xl text-rose-600 block" />
                <p className="font-bold text-xs text-rose-900">
                  {modalPerfilContacto.nombre} te ha bloqueado
                </p>
                <p className="text-[11px] text-rose-700">
                  No es posible ver la información, reseñas ni interactuar con este miembro de la comunidad. No tienes permisos para desbloquear a este usuario.
                </p>
              </div>
            ) : (didIBlockContact(modalPerfilContacto) || didIBlockUser(modalPerfilContacto.nombre)) ? (
              <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-2">
                <i className="fa-solid fa-user-slash text-2xl text-rose-600 block" />
                <p className="font-bold text-xs text-rose-800">
                  Has bloqueado a {modalPerfilContacto.nombre}
                </p>
                <p className="text-[11px] text-rose-700">
                  Desbloqueá a este usuario para volver a ver su información y contactarte.
                </p>
              </div>
            ) : (
              <>
                <p className="text-xs text-stone-600 leading-relaxed bg-white p-3 rounded-2xl border border-amber-100">
                  {modalPerfilContacto.bio}
                </p>

                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between">
                    <h5 className="font-bold text-xs text-club-brown flex items-center gap-1.5">
                      <i className="fa-solid fa-star text-amber-500" /> Reseñas de sus actividades:
                    </h5>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setIndiceResenaPerfil(prev => (prev === 0 ? 2 : prev - 1))}
                        className="w-6 h-6 rounded-full bg-amber-100 hover:bg-amber-200 text-club-brown flex items-center justify-center text-[10px] font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-chevron-left" />
                      </button>
                      <button
                        onClick={() => setIndiceResenaPerfil(prev => (prev === 2 ? 0 : prev + 1))}
                        className="w-6 h-6 rounded-full bg-amber-100 hover:bg-amber-200 text-club-brown flex items-center justify-center text-[10px] font-bold cursor-pointer"
                      >
                        <i className="fa-solid fa-chevron-right" />
                      </button>
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-amber-200 text-[11px] min-h-[70px]">
                    {[
                      { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                      { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                      { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                    ][indiceResenaPerfil] && (
                      <div>
                        <div className="flex justify-between font-bold text-club-brown">
                          <span>
                            {[
                              { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                              { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                              { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                            ][indiceResenaPerfil].autor}{' '}
                            <span className="text-[10px] text-stone-400 font-normal">
                              • {[
                                { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                                { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                                { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                              ][indiceResenaPerfil].fecha}
                            </span>
                          </span>
                          <span className="text-amber-500">
                            {[
                              { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                              { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                              { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                            ][indiceResenaPerfil].estrellas}
                          </span>
                        </div>
                        <p className="text-[10px] font-bold text-club-orange mt-0.5">
                          {[
                            { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                            { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                            { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                          ][indiceResenaPerfil].actividad}
                        </p>
                        <p className="text-stone-500 mt-1 italic">
                          "{[
                            { autor: 'Carola Márquez', actividad: 'Movilidad y elongación', fecha: '10 de Octubre 2026', texto: 'Gran compañero y siempre muy puntual para compartir los talleres.', estrellas: '★★★★★' },
                            { autor: 'Marta Sánchez', actividad: 'Tarde de Tejido y Mate', fecha: '14 de Octubre 2026', texto: 'Muy buena predisposición para armar grupos de caminata.', estrellas: '★★★★★' },
                            { autor: 'Graciela Pérez', actividad: 'Taller de Memoria', fecha: '2 de Octubre 2026', texto: 'Siempre dispuesto a ayudar en el centro vecinal.', estrellas: '★★★★★' }
                          ][indiceResenaPerfil].texto}"
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}

            <div className="pt-2 flex justify-end gap-2 border-t border-amber-200">
              <button
                onClick={() => setModalPerfilContacto(null)}
                className="pill-btn px-4 py-2 bg-stone-100 text-stone-700 font-bold text-xs cursor-pointer"
              >
                Cerrar
              </button>
              {!isUserBlocked(modalPerfilContacto.nombre) && (
                <button
                  onClick={async () => {
                    const targetNombre = modalPerfilContacto.nombre;
                    setModalPerfilContacto(null);
                    setCurrentView('chat');
                    const existing = chats.find(c => c.title === targetNombre && c.type === 'privado');
                    if (existing) {
                      setActiveChatId(existing.id);
                    } else {
                      const newChat = await api.createChat({
                        title: targetNombre,
                        type: 'privado',
                        participants: [targetNombre]
                      });
                      await refreshData();
                      setActiveChatId(newChat.id);
                    }
                  }}
                  className="pill-btn px-4 py-2 bg-club-teal text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <i className="fa-solid fa-comments" /> Iniciar Chat Privado
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LISTADO OFICIAL DE INSCRIPTOS (Con Veto funcional de usuarios) */}
      {modalInscriptosId !== null && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-2xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold bg-blue-100 text-blue-900 px-2.5 py-0.5 rounded-full uppercase">
                  Nómina de Participantes
                </span>
                <h3 className="font-brand text-xl font-bold text-club-brown mt-1">
                  {activities.find(a => a.id === modalInscriptosId)?.title || 'Movilidad y elongación (CEDEM 4)'}
                </h3>
              </div>
              <button
                onClick={() => setModalInscriptosId(null)}
                className="pill-btn px-3 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cerrar
              </button>
            </div>

            <div className="p-4 sm:p-5 overflow-y-auto space-y-3">
              <div className="flex items-center justify-between text-xs text-stone-600 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                <span className="font-bold">
                  <i className="fa-solid fa-users text-club-orange mr-1" /> Vecinos anotados en la actividad
                </span>
                <span className="text-emerald-700 font-bold">
                  <i className="fa-solid fa-circle-check mr-1" /> Vacantes disponibles
                </span>
              </div>

              <div className="space-y-2 text-xs">
                {(activities.find(a => a.id === modalInscriptosId)?.enrolledUsernames?.length
                  ? activities.find(a => a.id === modalInscriptosId)!.enrolledUsernames
                  : ['Carola Márquez', 'Roberto Gómez']
                ).map((uName, idx) => (
                  <div key={idx} className="bg-white p-3.5 rounded-2xl border border-amber-200 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-club-orange text-white font-bold flex items-center justify-center text-xs">
                        {uName.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-sm text-club-brown">{uName}</p>
                        <p className="text-[11px] text-stone-500">Inscripto confirmado • Tres de Febrero</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleVetoUser(modalInscriptosId, uName)}
                      className="pill-btn px-3 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                    >
                      <i className="fa-solid fa-user-slash mr-1" /> Vetar de la actividad
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3 bg-white border-t border-amber-200 flex justify-between items-center">
              <button
                onClick={() => {
                  const act = activities.find(a => a.id === modalInscriptosId);
                  const nomina = (act?.enrolledUsernames || ['Carola Márquez', 'Roberto Gómez']).map(n => ({
                    nombre: n,
                    contacto: '11 5544-2211'
                  }));
                  descargarPlanillaPDF(act?.title || 'Actividad', nomina);
                }}
                className="pill-btn px-4 py-2 bg-amber-100 hover:bg-amber-200 text-club-brown text-xs font-bold flex items-center gap-1.5 border border-amber-300 cursor-pointer"
              >
                <i className="fa-solid fa-file-arrow-down text-club-orange" /> Descargar Planilla
              </button>
              <button
                onClick={() => setModalInscriptosId(null)}
                className="pill-btn px-4 py-2 bg-club-orange text-white text-xs font-bold shadow-sm cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: MODERACIÓN PERSONAL DE LA ACTIVIDAD (Dinámico por actividad) */}
      {modalModeracionActividadId !== null && (() => {
        const actModerar = activities.find(a => a.id === modalModeracionActividadId);
        if (!actModerar) return null;
        const inscriptosCount = actModerar.enrolledUsernames ? actModerar.enrolledUsernames.length : actModerar.enrolledCount;
        const libresCount = Math.max(0, actModerar.capacity - inscriptosCount);
        const enrolledParticipants = (actModerar.enrolledUsernames && actModerar.enrolledUsernames.length > 0)
          ? actModerar.enrolledUsernames.filter(u => u !== currentUser?.usuario && u !== currentUser?.apodo)
          : [];
        const relatedChat = chats.find(c => c.activityId === actModerar.id);

        return (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
            <div className="bg-club-cream w-full max-w-xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden max-h-[90vh] flex flex-col">
              <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold bg-amber-200 text-club-brown px-2.5 py-0.5 rounded-full uppercase">
                    Panel de Organización Vecinal
                  </span>
                  <h3 className="font-brand text-xl font-bold text-club-brown mt-1">
                    Moderar mi actividad: {actModerar.title}
                  </h3>
                </div>
                <button
                  onClick={() => setModalModeracionActividadId(null)}
                  className="pill-btn px-3 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
                >
                  Cerrar
                </button>
              </div>

              <div className="p-5 overflow-y-auto space-y-4 text-xs text-club-brown">
                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 space-y-2">
                  <p className="font-bold text-sm text-club-brown">Estado de la actividad</p>
                  <p className="text-stone-600">
                    <strong>{actModerar.isApproved ? 'Aprobada por moderación CLUB65 ✓' : 'En revisión de seguridad'}</strong> • {actModerar.isApproved ? 'Visible para todos los vecinos en la Cartelera.' : 'Pendiente de aprobación.'}
                  </p>
                  <p className="text-stone-600">
                    Cupos: <strong>
                      {inscriptosCount} de {actModerar.capacity} personas anotadas
                    </strong> (
                      {libresCount} lugares libres
                    ).
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="font-bold text-sm text-club-brown">Participantes confirmados:</h4>
                  {enrolledParticipants.length === 0 ? (
                    <p className="p-3 bg-white rounded-xl border border-amber-200 text-stone-500 italic text-center">
                      Aún no hay otros participantes anotados en esta actividad.
                    </p>
                  ) : (
                    <div className="space-y-1.5">
                      {enrolledParticipants.map((uName, idx) => (
                        <div key={idx} className="p-3 bg-white rounded-xl border border-amber-200 flex justify-between items-center">
                          <div>
                            <p className="font-bold text-club-brown">{uName}</p>
                            <p className="text-[11px] text-stone-400">Inscripta/o en tu actividad</p>
                          </div>
                          <button
                            onClick={() => handleVetoUser(actModerar.id, uName)}
                            className="pill-btn px-3 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-[11px] cursor-pointer"
                          >
                            Vetar de la actividad
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-amber-200 flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() =>
                      setModalConfirmarCancelacion({
                        nombre: actModerar.title,
                        dia: actModerar.schedule,
                        hora: '',
                        tipo: 'personal'
                      })
                    }
                    className="pill-btn flex-1 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs text-center flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <i className="fa-solid fa-ban" /> Cancelar actividad
                  </button>
                  {relatedChat && (
                    <button
                      onClick={() => {
                        setModalModeracionActividadId(null);
                        setCurrentView('chat');
                        setActiveChatId(relatedChat.id);
                      }}
                      className="pill-btn flex-1 py-2 bg-club-teal hover:bg-club-teal/80 text-white font-bold text-xs text-center shadow-xs cursor-pointer"
                    >
                      Enviar mensaje al grupo
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* MODAL: CREAR / PROPONER EVENTO */}
      {modalCrearEventoOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-4xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 bg-white border-b border-amber-200 flex items-center justify-between">
              <h3 className="font-brand text-lg sm:text-xl font-bold text-club-brown">
                {editingProposalActivityId ? 'Modificar y reenviar propuesta comunitaria' : (eventoTipoCreacion === 'institucional' ? 'Crear actividad validada' : 'Proponer actividad comunitaria')}
              </h3>
              <button
                onClick={() => setModalCrearEventoOpen(false)}
                className="text-2xl text-stone-400 hover:text-club-brown font-bold leading-none p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmitEvento} className="p-4 sm:p-6 overflow-y-auto space-y-6 text-sm text-club-brown">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-amber-200 space-y-4">
                  <h4 className="font-brand text-base font-bold text-club-brown border-b border-amber-100 pb-2">Información general</h4>
                  <div>
                    <label className="block font-bold text-xs text-club-brown mb-1">Nombre de la actividad *</label>
                    <input
                      type="text"
                      required
                      value={eventoForm.nombre}
                      onChange={(e) => setEventoForm({ ...eventoForm, nombre: e.target.value })}
                      placeholder="Elige un nombre corto y memorable"
                      className="w-full px-3.5 py-2.5 bg-amber-50/50 border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-xs text-club-brown mb-1">Avance corto *</label>
                    <textarea
                      rows={2}
                      required
                      value={eventoForm.avance}
                      onChange={(e) => setEventoForm({ ...eventoForm, avance: e.target.value })}
                      placeholder="Agrega algunas palabras debajo del nombre de la actividad para incentivar a los participantes (aparecerá en la carátula de la Cartelera)."
                      className="w-full px-3.5 py-2 bg-amber-50/50 border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-xs text-club-brown mb-1">Categoría de actividad</label>
                    <select
                      value={eventoForm.categoria}
                      onChange={(e) => setEventoForm({ ...eventoForm, categoria: e.target.value as any })}
                      className="w-full px-3 py-2.5 bg-amber-50/50 border border-amber-200 rounded-xl outline-none text-xs"
                    >
                      <option value="salud">Salud y Movimiento</option>
                      <option value="cultura">Cultura y Arte</option>
                      <option value="social">Juegos y Mateadas</option>
                      <option value="musica">Música y Baile</option>
                      <option value="tecnologia">Tecnología y Celulares</option>
                      <option value="memoria">Estimulación y Memoria</option>
                      <option value="naturaleza">Naturaleza y Paseos</option>
                    </select>
                  </div>
                </div>

                <div className="lg:col-span-1 bg-white p-5 rounded-2xl border border-amber-200 flex flex-col justify-between space-y-3">
                  <div>
                    <h4 className="font-brand text-base font-bold text-club-brown border-b border-amber-100 pb-2">Imagen de la actividad</h4>
                    <label className="mt-3 border-2 border-dashed border-amber-300 rounded-2xl h-36 flex flex-col items-center justify-center text-center p-3 hover:bg-amber-50/50 cursor-pointer">
                      <div className="w-10 h-10 rounded-full bg-club-orange/10 text-club-orange flex items-center justify-center text-xl mb-1">
                        <i className="fa-solid fa-cloud-arrow-up" />
                      </div>
                      <span className="text-xs font-bold text-club-orange">Subir desde dispositivo</span>
                      <span className="text-[10px] text-stone-400 mt-1">Recomendado 16:9</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleEventImageFile}
                        className="hidden"
                      />
                    </label>
                  </div>
                  <div className="text-[11px] text-stone-500 pt-2 border-t border-amber-100">
                    <span className="font-bold text-club-brown block mb-1">Imagen activa:</span>
                    <span className="text-emerald-700 font-bold">{eventoImgLabel}</span>
                    {eventoForm.imagen && (
                      <button
                        type="button"
                        onClick={() => {
                          setImageCropperState({
                            isOpen: true,
                            rawSrc: eventoForm.imagen,
                            title: 'Ajustar imagen de la actividad (Cartelera)',
                            target: 'activity',
                            shape: 'rectangle'
                          });
                        }}
                        className="mt-2 w-full py-1.5 px-3 bg-amber-100 hover:bg-amber-200 text-club-brown rounded-xl text-[11px] font-bold border border-amber-300 flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <i className="fa-solid fa-crop-simple text-club-orange" /> Re-ajustar / Recortar foto
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-amber-200 space-y-4">
                <h4 className="font-brand text-base font-bold text-club-brown border-b border-amber-100 pb-2">Fecha y horario</h4>
                <div className="flex flex-wrap gap-2 text-xs">
                  <label className="flex items-center gap-2 p-2.5 px-4 rounded-xl border border-amber-200 bg-amber-50 font-bold cursor-pointer">
                    <input
                      type="radio"
                      name="ev_frecuencia"
                      value="unico"
                      checked={eventoForm.frecuencia === 'unico'}
                      onChange={() => setEventoForm({ ...eventoForm, frecuencia: 'unico' })}
                    />
                    <span>Encuentro único</span>
                  </label>
                  <label className="flex items-center gap-2 p-2.5 px-4 rounded-xl border border-amber-200 hover:bg-amber-50 font-bold cursor-pointer">
                    <input
                      type="radio"
                      name="ev_frecuencia"
                      value="recurrente"
                      checked={eventoForm.frecuencia === 'recurrente'}
                      onChange={() => setEventoForm({ ...eventoForm, frecuencia: 'recurrente' })}
                    />
                    <span>Encuentro recurrente</span>
                  </label>
                </div>

                {eventoForm.frecuencia === 'unico' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-1">
                    <div>
                      <label className="block font-bold text-stone-600 mb-1">Fecha de inicio</label>
                      <input
                        type="date"
                        value={eventoForm.fechaIni}
                        onChange={(e) => setEventoForm({ ...eventoForm, fechaIni: e.target.value })}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-200 rounded-xl outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-600 mb-1">Hora de inicio</label>
                      <input
                        type="time"
                        value={eventoForm.horaIni}
                        onChange={(e) => setEventoForm({ ...eventoForm, horaIni: e.target.value })}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-200 rounded-xl outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-600 mb-1">Fecha de finalización</label>
                      <input
                        type="date"
                        value={eventoForm.fechaFin}
                        onChange={(e) => setEventoForm({ ...eventoForm, fechaFin: e.target.value })}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-200 rounded-xl outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-600 mb-1">Hora de finalización</label>
                      <input
                        type="time"
                        value={eventoForm.horaFin}
                        onChange={(e) => setEventoForm({ ...eventoForm, horaFin: e.target.value })}
                        className="w-full px-3 py-2 bg-amber-50/50 border border-amber-200 rounded-xl outline-none"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="pt-2">
                    <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      <div>
                        <span className="text-xs font-bold text-club-brown block">
                          <i className="fa-solid fa-calendar-week text-club-orange mr-1" /> {resumenRecurrente}
                        </span>
                        <span className="text-[11px] text-stone-500">Configurá las fechas repetitivas de los encuentros.</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setModalFechasRepetitivasOpen(true)}
                        className="pill-btn px-4 py-2 bg-club-teal hover:bg-club-teal/80 text-white text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto shadow-xs cursor-pointer"
                      >
                        <i className="fa-regular fa-calendar-plus" />
                        <span>Modificar fechas repetitivas</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-white p-5 rounded-2xl border border-amber-200 space-y-3 relative">
                <div className="flex items-center justify-between border-b border-amber-100 pb-2">
                  <h4 className="font-brand text-base font-bold text-club-brown">Ubicación de la actividad (Presencial)</h4>
                  <span className="text-[11px] font-bold text-club-orange bg-orange-50 border border-orange-200 px-2.5 py-0.5 rounded-full">
                    <i className="fa-solid fa-person-walking mr-1" /> Encuentro Presencial
                  </span>
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-bold text-xs text-club-brown">Dirección o punto de encuentro *</label>
                    <span className="text-[11px] text-stone-500 font-semibold flex items-center gap-1">
                      <i className="fa-solid fa-earth-americas text-club-teal" /> Buscador libre OpenStreetMap
                    </span>
                  </div>
                  <div className="relative">
                    <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-3 text-stone-400 text-xs" />
                    <input
                      type="text"
                      required
                      value={eventoForm.direccion}
                      onChange={(e) => handleSearchLocation(e.target.value)}
                      placeholder="Escribí una calle, altura, plaza o club..."
                      className="w-full pl-9 pr-16 py-2.5 bg-amber-50/50 border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                    />
                    <div className="absolute right-3 top-2.5 flex items-center gap-1.5">
                      {isSearchingLocation && (
                        <i className="fa-solid fa-spinner fa-spin text-club-orange text-xs" title="Buscando en OpenStreetMap..." />
                      )}
                      {eventoForm.direccion && (
                        <button
                          type="button"
                          onClick={() => {
                            setEventoForm(prev => ({ ...prev, direccion: '', lat: -34.6068, lng: -58.5647 }));
                            setShowSugerencias(false);
                          }}
                          className="text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
                        >
                          <i className="fa-solid fa-circle-xmark" />
                        </button>
                      )}
                    </div>
                  </div>
                  {showSugerencias && sugerenciasUbicacion.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-amber-200 rounded-2xl shadow-xl z-30 max-h-56 overflow-y-auto divide-y divide-amber-100">
                      {sugerenciasUbicacion.map((u, i) => (
                        <div
                          key={i}
                          onClick={() => {
                            const chosenAddress = u.detalle && u.detalle !== u.nombre ? `${u.nombre} - ${u.detalle}` : u.nombre;
                            setEventoForm(prev => ({
                              ...prev,
                              direccion: chosenAddress,
                              lat: u.lat ?? prev.lat ?? -34.6068,
                              lng: u.lng ?? prev.lng ?? -58.5647
                            }));
                            setShowSugerencias(false);
                          }}
                          className="p-3 hover:bg-amber-50 cursor-pointer flex items-start gap-2.5 transition"
                        >
                          <i className="fa-solid fa-location-dot text-club-orange text-sm mt-0.5" />
                          <div className="flex-1">
                            <p className="font-bold text-xs text-club-brown">{u.nombre}</p>
                            <p className="text-[11px] text-stone-500 leading-snug">{u.detalle}</p>
                          </div>
                          {u.lat && u.lng && (
                            <span className="text-[10px] text-stone-400 self-center">
                              OSM
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {eventoForm.direccion && (
                    <div className="mt-3 p-3 bg-amber-50/60 rounded-xl border border-amber-200 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-club-brown flex items-center gap-1.5">
                          <i className="fa-solid fa-map-location-dot text-club-orange" />
                          Vista previa en OpenStreetMap
                        </span>
                        <span className="text-[10px] text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-full font-bold">
                          Leaflet + OSM libre
                        </span>
                      </div>
                      <div className="h-40 w-full rounded-xl overflow-hidden border border-amber-200 shadow-inner">
                        <LeafletMap
                          lat={eventoForm.lat || -34.6068}
                          lng={eventoForm.lng || -58.5647}
                          title={eventoForm.nombre || 'Ubicación seleccionada'}
                          locationName={eventoForm.direccion}
                          height={160}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-amber-200 space-y-4">
                <div className="flex items-center justify-between border-b border-amber-100 pb-2">
                  <h4 className="font-brand text-base font-bold text-club-brown">Cupos de asistencia</h4>
                  <span className="text-xs text-stone-500">Configurá la capacidad de participantes</span>
                </div>

                <div className="flex flex-wrap gap-2 text-xs">
                  <label className="flex items-center gap-2 p-2.5 px-4 rounded-xl border border-amber-200 bg-amber-50 font-bold cursor-pointer">
                    <input
                      type="radio"
                      name="ev_tipo_cupo"
                      value="limitado"
                      checked={eventoForm.tipoCupo === 'limitado'}
                      onChange={() => setEventoForm({ ...eventoForm, tipoCupo: 'limitado' })}
                    />
                    <span>Establecer cupo máximo</span>
                  </label>
                  <label className="flex items-center gap-2 p-2.5 px-4 rounded-xl border border-amber-200 hover:bg-amber-50 font-bold cursor-pointer">
                    <input
                      type="radio"
                      name="ev_tipo_cupo"
                      value="ilimitado"
                      checked={eventoForm.tipoCupo === 'ilimitado'}
                      onChange={() => setEventoForm({ ...eventoForm, tipoCupo: 'ilimitado' })}
                    />
                    <span>No establecer cupos (Sin límite)</span>
                  </label>
                </div>

                {eventoForm.tipoCupo === 'limitado' && (
                  <div className="flex items-center gap-3 pt-1">
                    <label className="text-xs font-bold text-club-brown">Cantidad máxima de personas:</label>
                    <input
                      type="number"
                      min={2}
                      max={150}
                      value={eventoForm.cupoMax}
                      onChange={(e) => setEventoForm({ ...eventoForm, cupoMax: Number(e.target.value) })}
                      className="w-24 px-3 py-1.5 bg-amber-50/50 border border-amber-200 rounded-xl text-xs text-center font-bold outline-none focus:ring-2 focus:ring-club-orange"
                    />
                    <span className="text-[11px] text-stone-500">vacantes disponibles</span>
                  </div>
                )}
              </div>

              <div className="bg-white p-5 rounded-2xl border border-amber-200 space-y-3">
                <h4 className="font-brand text-base font-bold text-club-brown border-b border-amber-100 pb-2">
                  Acerca de la actividad (Detalles) *
                </h4>
                <textarea
                  rows={4}
                  required
                  value={eventoForm.descripcion}
                  onChange={(e) => setEventoForm({ ...eventoForm, descripcion: e.target.value })}
                  placeholder="Utiliza este espacio para darles todos los detalles a los participantes acerca de esta actividad (aparecerá en la vista de detalle y mapa)."
                  className="w-full px-3.5 py-2.5 bg-amber-50/50 border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div className="pt-2 flex flex-col-reverse sm:flex-row justify-between items-center gap-3 border-t border-amber-200/80">
                <button
                  type="button"
                  onClick={() => setModalCrearEventoOpen(false)}
                  className="pill-btn px-6 py-2.5 bg-white border border-stone-300 text-stone-700 hover:bg-stone-100 text-xs font-bold w-full sm:w-auto cursor-pointer"
                >
                  Cancelar
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="submit"
                    className="pill-btn px-6 py-2.5 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <i className="fa-solid fa-paper-plane" />
                    <span>
                      {eventoTipoCreacion === 'institucional' ? 'Publicar actividad validada' : 'Enviar a Revisión de Moderación'}
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUBMODAL: AGREGAR FECHAS REPETITIVAS */}
      {modalFechasRepetitivasOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-2xl rounded-3xl border-2 border-amber-200 retro-shadow-strong overflow-hidden flex flex-col">
            <div className="p-4 bg-white border-b border-amber-200 flex items-center justify-between">
              <h3 className="font-brand text-lg font-bold text-club-brown">Agregar fechas repetitivas</h3>
              <button
                onClick={() => setModalFechasRepetitivasOpen(false)}
                className="text-2xl text-stone-400 hover:text-stone-600 font-bold leading-none p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-5 space-y-5 text-xs text-club-brown overflow-y-auto max-h-[80vh]">
              <div className="space-y-1.5">
                <label className="block font-bold text-club-brown">Frecuencia</label>
                <select
                  value={frecuenciaRecurrente}
                  onChange={(e) => setFrecuenciaRecurrente(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-amber-200 rounded-xl outline-none font-bold text-xs focus:ring-2 focus:ring-club-orange"
                >
                  <option value="semanal">Semanal</option>
                  <option value="quincenal">Quincenal (Cada 2 semanas)</option>
                  <option value="mensual">Mensual</option>
                </select>
              </div>

              {frecuenciaRecurrente !== 'mensual' ? (
                <div className="space-y-1.5">
                  <label className="block font-bold text-club-brown">Se repite el</label>
                  <div className="flex gap-1.5 sm:gap-2">
                    {['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'].map((dia) => {
                      const sel = diasSemanaRecurrente.includes(dia);
                      return (
                        <button
                          key={dia}
                          type="button"
                          onClick={() => {
                            if (sel) {
                              if (diasSemanaRecurrente.length > 1) {
                                setDiasSemanaRecurrente(prev => prev.filter(d => d !== dia));
                              }
                            } else {
                              setDiasSemanaRecurrente(prev => [...prev, dia]);
                            }
                          }}
                          className={`w-10 h-10 rounded-xl font-bold flex items-center justify-center text-xs cursor-pointer ${
                            sel
                              ? 'border-2 border-club-orange bg-club-orange text-white shadow-xs'
                              : 'border border-amber-200 bg-white hover:bg-amber-50 text-club-brown'
                          }`}
                        >
                          {dia.charAt(0)}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <label className="block font-bold text-club-brown">Día del mes (numérico)</label>
                  <div className="flex items-center gap-2">
                    <span>El día</span>
                    <input
                      type="number"
                      min={1}
                      max={31}
                      value={diaMesRecurrente}
                      onChange={(e) => setDiaMesRecurrente(Number(e.target.value))}
                      className="w-20 px-3 py-1.5 bg-white border border-amber-200 rounded-xl text-center font-bold text-xs outline-none focus:ring-2 focus:ring-club-orange"
                    />
                    <span>de cada mes</span>
                  </div>
                </div>
              )}

              <div className="space-y-1.5 pt-2 border-t border-amber-200/70">
                <h4 className="font-bold text-club-brown">Finalización de la actividad</h4>
                <div className="flex items-center gap-3 pt-1">
                  <label className="font-bold text-stone-600">Cantidad de encuentros:</label>
                  <input
                    type="number"
                    min={2}
                    max={52}
                    value={cantidadEventosRecurrente}
                    onChange={(e) => setCantidadEventosRecurrente(Number(e.target.value))}
                    className="w-24 px-3 py-1.5 bg-white border border-amber-200 rounded-xl text-center font-bold text-xs outline-none focus:ring-2 focus:ring-club-orange"
                  />
                  <span className="text-stone-500">encuentros en total</span>
                </div>
              </div>

              <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-200 text-xs">
                <p className="font-bold text-club-brown mb-1">
                  <i className="fa-solid fa-eye text-club-orange mr-1" /> Vista previa del cronograma:
                </p>
                <p className="text-stone-600">
                  {frecuenciaRecurrente === 'mensual'
                    ? `Se llevarán a cabo ${cantidadEventosRecurrente} encuentros en total, el día ${diaMesRecurrente} de cada mes.`
                    : frecuenciaRecurrente === 'quincenal'
                    ? `Se llevarán a cabo ${cantidadEventosRecurrente} encuentros cada 2 semanas los días ${diasSemanaRecurrente.join(', ')}.`
                    : `Se llevarán a cabo ${cantidadEventosRecurrente} encuentros todas las semanas los días ${diasSemanaRecurrente.join(', ')}.`}
                </p>
              </div>
            </div>

            <div className="p-3 bg-white border-t border-amber-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setModalFechasRepetitivasOpen(false)}
                className="pill-btn px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const summary = frecuenciaRecurrente === 'mensual'
                    ? `Mensual (día ${diaMesRecurrente}) • ${cantidadEventosRecurrente} encuentros`
                    : frecuenciaRecurrente === 'quincenal'
                    ? `Cada 2 semanas (${diasSemanaRecurrente.join(', ')}) • ${cantidadEventosRecurrente} encuentros`
                    : `Semanal (${diasSemanaRecurrente.join(', ')}) • ${cantidadEventosRecurrente} encuentros`;
                  setResumenRecurrente(summary);
                  setModalFechasRepetitivasOpen(false);
                }}
                className="pill-btn px-5 py-2 bg-club-orange text-white text-xs font-bold hover:bg-club-orange-dark shadow-sm cursor-pointer"
              >
                Guardar fechas repetitivas
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREAR NUEVO CHAT GRUPAL */}
      {modalCrearGrupoOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-3">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-5 space-y-4">
            <div className="flex justify-between items-center border-b border-amber-200 pb-2">
              <h3 className="font-brand text-lg font-bold text-club-brown flex items-center gap-2">
                <i className="fa-solid fa-users text-club-orange" /> Crear Nuevo Chat Grupal
              </h3>
              <button
                onClick={() => setModalCrearGrupoOpen(false)}
                className="text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCrearNuevoGrupo} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-club-brown mb-1">Nombre del grupo:</label>
                <input
                  type="text"
                  required
                  value={nombreNuevoGrupo}
                  onChange={(e) => setNombreNuevoGrupo(e.target.value)}
                  placeholder="Ej: Compañeros de caminatas"
                  className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl outline-none focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div>
                <label className="block font-bold text-club-brown mb-1">Invitar participantes (Mis Contactos):</label>
                <div className="space-y-1.5 bg-white p-3 rounded-xl border border-amber-200 max-h-40 overflow-y-auto">
                  {(() => {
                    const eligibleContacts = contacts.filter(c => !didOtherBlockMe(c.nombre) && !didIBlockUser(c.nombre) && !didIBlockContact(c));
                    if (eligibleContacts.length === 0) {
                      return <p className="p-2 text-stone-400 italic">No tenés contactos disponibles para invitar.</p>;
                    }
                    return eligibleContacts.map((c) => (
                      <label key={c.id} className="flex items-center gap-2 cursor-pointer text-xs font-semibold">
                        <input
                          type="checkbox"
                          checked={participantesSeleccionadosGrupo.includes(c.nombre)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setParticipantesSeleccionadosGrupo(prev => [...prev, c.nombre]);
                            } else {
                              setParticipantesSeleccionadosGrupo(prev => prev.filter(n => n !== c.nombre));
                            }
                          }}
                          className="text-club-orange"
                        />{' '}
                        {c.nombre}
                      </label>
                    ));
                  })()}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalCrearGrupoOpen(false)}
                  className="pill-btn px-4 py-2 bg-stone-100 text-stone-700 text-xs font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="pill-btn px-5 py-2 bg-club-orange text-white text-xs font-bold shadow-sm cursor-pointer"
                >
                  Crear Grupo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRMAR ELIMINACIÓN DE MENSAJE (PASO 1) */}
      {messageToDelete && (
        <div className="fixed inset-0 bg-black/70 z-[80] flex items-center justify-center p-4">
          <div className="bg-club-cream w-full max-w-sm rounded-3xl border-2 border-rose-300 p-6 space-y-4 shadow-2xl text-club-brown animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-700">
              <i className="fa-solid fa-trash-can text-2xl" />
              <h4 className="font-brand text-lg font-bold">Eliminar Mensaje</h4>
            </div>
            <p className="text-sm font-semibold text-center py-2">
              ¿Estas seguro de que querés eliminar este mensaje?
            </p>
            <div className="flex justify-end gap-3 pt-2 border-t border-amber-200">
              <button
                onClick={() => setMessageToDelete(null)}
                className="pill-btn px-6 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                NO
              </button>
              <button
                onClick={() => {
                  const curr = messageToDelete;
                  setMessageToDelete(null);
                  setConfirmDenounceMessage(curr);
                }}
                className="pill-btn px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                SI
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRMAR DENUNCIA DE MENSAJE (PASO 2) */}
      {confirmDenounceMessage && (
        <div className="fixed inset-0 bg-black/70 z-[80] flex items-center justify-center p-4">
          <div className="bg-club-cream w-full max-w-sm rounded-3xl border-2 border-amber-300 p-6 space-y-4 shadow-2xl text-club-brown animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-club-orange">
              <i className="fa-solid fa-shield-halved text-2xl" />
              <h4 className="font-brand text-lg font-bold">Seguridad Comunitaria</h4>
            </div>
            <p className="text-sm font-semibold text-center py-2">
              ¿querés denunciar este mensaje?
            </p>
            <div className="flex justify-end gap-3 pt-2 border-t border-amber-200">
              <button
                onClick={async () => {
                  await handleDeleteChatMessage(confirmDenounceMessage.chatId, confirmDenounceMessage.messageId);
                  setConfirmDenounceMessage(null);
                }}
                className="pill-btn px-6 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                NO
              </button>
              <button
                onClick={() => {
                  const curr = confirmDenounceMessage;
                  openReportModal({
                    type: 'chat_message',
                    chatId: curr.chatId,
                    messageId: curr.messageId,
                    messageText: curr.messageText,
                    reportedUser: curr.sender
                  });
                }}
                className="pill-btn px-6 py-2 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold cursor-pointer"
              >
                SI
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRMAR REPORTE DESDE VISOR DE FOTOS/VIDEOS */}
      {modalConfirmReportVisor && (
        <div className="fixed inset-0 bg-black/70 z-[85] flex items-center justify-center p-4">
          <div className="bg-club-cream w-full max-w-sm rounded-3xl border-2 border-rose-300 p-6 space-y-4 shadow-2xl text-club-brown animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-700">
              <i className="fa-solid fa-flag text-2xl" />
              <h4 className="font-brand text-lg font-bold">Reportar Contenido</h4>
            </div>
            <p className="text-sm font-semibold text-center py-2">
              ¿Estas seguro de que querés reportar este Chat?
            </p>
            <div className="flex justify-end gap-3 pt-2 border-t border-amber-200">
              <button
                onClick={() => setModalConfirmReportVisor(false)}
                className="pill-btn px-6 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                NO
              </button>
              <button
                onClick={() => {
                  setModalConfirmReportVisor(false);
                  openReportModal({
                    type: 'review_media',
                    mediaUrl: galeriaItems[galeriaIndex]?.mediaUrl,
                    reportedUser: galeriaItems[galeriaIndex]?.autor,
                    activityId: resenasOriginActivityId || undefined
                  });
                }}
                className="pill-btn px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                SI
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL UNIFICADO: REPORTAR UN PROBLEMA (Formulario unificado con 9 opciones para toda la web) */}
      {modalReporteData.isOpen && (
        <div className="fixed inset-0 bg-black/75 z-[90] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-200 p-6 space-y-4 shadow-2xl text-club-brown max-h-[90vh] overflow-y-auto">
            <div className="border-b border-amber-200 pb-2 flex items-center justify-between">
              <h3 className="font-brand text-xl font-bold text-club-brown flex items-center gap-2">
                <i className="fa-solid fa-triangle-exclamation text-rose-600" /> Reportar un problema
              </h3>
              <button
                onClick={() => {
                  setModalReporteData(prev => ({ ...prev, isOpen: false }));
                  setConfirmDenounceMessage(null);
                }}
                className="text-stone-400 hover:text-stone-700 text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-sm text-club-brown mb-2">¿Qué queres reportar?</label>
                <div className="space-y-1.5 bg-white p-3.5 rounded-2xl border border-amber-200">
                  {[
                    'Spam',
                    'Odio, abuso, o acoso',
                    'Discurso violento',
                    'Comportamientos ilegales',
                    'Suplantación de identidad',
                    'Suicidio o Autolesiones',
                    'Terrorismo o extremismo',
                    'Integridad cívica',
                    'Contenido sexual'
                  ].map((opt) => (
                    <label
                      key={opt}
                      className={`flex items-center gap-2.5 p-2 rounded-xl cursor-pointer font-semibold transition ${
                        modalReporteData.reason === opt ? 'bg-amber-100 text-club-brown font-bold' : 'hover:bg-amber-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="report_reason"
                        value={opt}
                        checked={modalReporteData.reason === opt}
                        onChange={() => setModalReporteData(prev => ({ ...prev, reason: opt }))}
                        className="text-club-orange"
                      />
                      <span>{opt}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-xs text-club-brown mb-1">
                  ¿Querés dejar un comentario explicativo? (opcional)
                </label>
                <textarea
                  rows={3}
                  value={modalReporteData.comment}
                  onChange={(e) => setModalReporteData(prev => ({ ...prev, comment: e.target.value }))}
                  placeholder="Contanos brevemente qué sucedió..."
                  className="w-full p-2.5 bg-white border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-amber-200">
                <button
                  type="button"
                  onClick={() => {
                    setModalReporteData(prev => ({ ...prev, isOpen: false }));
                    setConfirmDenounceMessage(null);
                  }}
                  className="pill-btn px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="pill-btn px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow cursor-pointer"
                >
                  Enviar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: MODERACIÓN FUNCIONAL DEL GRUPO (Eliminar participante, Cambiar foto, Hacer admin) */}
      {modalModerarGrupoOpen && activeChat && (
        <div className="fixed inset-0 bg-black/70 z-[70] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-lg rounded-3xl border-2 border-amber-200 p-6 space-y-5 shadow-2xl text-club-brown max-h-[90vh] overflow-y-auto">
            <div className="border-b border-amber-200 pb-3">
              <span className="text-[10px] font-bold bg-amber-200 text-club-brown px-2 py-0.5 rounded-full uppercase">
                Administración del Grupo
              </span>
              <h3 className="font-brand text-lg font-bold text-club-brown mt-1">
                Moderar grupo: {activeChat.title}
              </h3>
            </div>

            {/* Cambiar foto del grupo (con ajuste circular interactivo estilo WhatsApp) */}
            <div className="bg-white p-4 rounded-2xl border border-amber-200 space-y-2">
              <label className="block text-xs font-bold text-club-brown">
                <i className="fa-solid fa-camera text-club-orange mr-1" /> Foto del grupo
              </label>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-club-orange flex items-center justify-center bg-club-orange text-white font-bold text-lg flex-shrink-0 shadow-sm aspect-square">
                  {activeChat.image ? (
                    <img src={activeChat.image} alt="Foto grupo" className="w-full h-full object-cover aspect-square rounded-full" />
                  ) : (
                    <i className="fa-solid fa-users" />
                  )}
                </div>
                <div className="flex-1">
                  <label className="pill-btn px-4 py-2 bg-amber-100 hover:bg-amber-200 text-club-brown text-xs font-bold border border-amber-300 cursor-pointer inline-flex items-center gap-2 shadow-xs">
                    <i className="fa-solid fa-camera text-club-orange" /> Subir y ajustar foto del grupo
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            if (ev.target?.result) {
                              setImageCropperState({
                                isOpen: true,
                                rawSrc: ev.target.result as string,
                                target: 'group',
                                title: 'Ajustar foto del grupo'
                              });
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  <p className="text-[10px] text-stone-500 mt-1">Podrás encuadrar y hacer zoom sobre la foto antes de aplicarla.</p>
                </div>
              </div>
            </div>

            {/* Participantes del grupo */}
            <div className="space-y-2">
              <h4 className="font-bold text-xs text-club-brown flex items-center justify-between">
                <span>Participantes ({activeChat.participants?.length || 0})</span>
              </h4>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {(activeChat.participants || []).map((p, idx) => {
                  const isAdmin = activeChat.creatorName === p || activeChat.adminUsernames?.includes(p);
                  const isSelf = !canRemoveParticipantFromGroup(currentUser?.usuario || '', currentUser?.apodo || '', p);

                  return (
                    <div
                      key={idx}
                      className="p-3 bg-white rounded-xl border border-amber-200 flex flex-col sm:flex-row justify-between sm:items-center gap-2 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-club-orange/20 text-club-orange font-bold flex items-center justify-center text-xs">
                          {p.charAt(0)}
                        </div>
                        <div>
                          <span className="font-bold text-club-brown">{p}</span>
                          {isAdmin && (
                            <span className="ml-2 bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full text-[10px]">
                              👑 Administrador
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 self-end sm:self-auto">
                        {!isAdmin && (
                          <button
                            type="button"
                            onClick={() => handleMakeAdmin(p)}
                            className="pill-btn px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-[11px] cursor-pointer"
                          >
                            Designar administrador
                          </button>
                        )}
                        {!isSelf ? (
                          <button
                            type="button"
                            onClick={() => handleRemoveParticipant(p)}
                            className="pill-btn px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-bold text-[11px] cursor-pointer"
                          >
                            Eliminar participante
                          </button>
                        ) : (
                          <span className="text-[11px] font-bold text-stone-400 italic px-2 py-1">
                            Tú (Organizador)
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* AGREGAR PARTICIPANTE AL GRUPO */}
            {(() => {
              let eligibleToAdd: { nombre: string; detalle: string; foto?: string }[] = [];

              if (activeChat.activityId) {
                const linkedAct = activities.find(a => a.id === activeChat.activityId);
                const enrolled = linkedAct?.enrolledUsernames || [];
                eligibleToAdd = enrolled
                  .filter(uName => !activeChat.participants?.includes(uName) && uName !== currentUser?.apodo && uName !== currentUser?.usuario)
                  .map(uName => ({
                    nombre: uName,
                    detalle: 'Inscripto/a a la actividad',
                    foto: getUserPhotoByName(uName)
                  }));
              } else {
                eligibleToAdd = contacts
                  .filter(c => !activeChat.participants?.includes(c.nombre) && !didOtherBlockMe(c.nombre) && !didIBlockUser(c.nombre) && !didIBlockContact(c))
                  .map(c => ({
                    nombre: c.nombre,
                    detalle: c.detalle || 'Contacto de tu agenda',
                    foto: c.foto || getUserPhotoByName(c.nombre)
                  }));
              }

              return (
                <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-xs text-club-brown flex items-center gap-1.5">
                      <i className="fa-solid fa-user-plus text-club-orange" />
                      <span>Agregar participante</span>
                    </h4>
                    <span className="text-[10px] text-stone-500 font-semibold">
                      {activeChat.activityId ? 'Inscriptos a la actividad fuera del grupo' : 'Tus contactos disponibles'}
                    </span>
                  </div>

                  {eligibleToAdd.length === 0 ? (
                    <p className="text-stone-500 text-[11px] italic bg-white p-2.5 rounded-xl border border-amber-200 text-center">
                      {activeChat.activityId
                        ? 'No hay otros participantes inscriptos a la actividad fuera de este grupo.'
                        : 'No tenés otros contactos disponibles para agregar a este grupo.'}
                    </p>
                  ) : (
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {eligibleToAdd.map((u, i) => (
                        <div
                          key={i}
                          className="p-2 bg-white rounded-xl border border-amber-200 flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-club-orange/20 text-club-orange font-bold flex items-center justify-center text-xs overflow-hidden flex-shrink-0">
                              {u.foto ? (
                                <img src={u.foto} alt={u.nombre} className="w-full h-full object-cover" />
                              ) : (
                                u.nombre.charAt(0)
                              )}
                            </div>
                            <div>
                              <p className="font-bold text-club-brown">{u.nombre}</p>
                              <p className="text-[10px] text-stone-400">{u.detalle}</p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleAddParticipantToGroup(u.nombre)}
                            className="pill-btn px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs cursor-pointer flex items-center gap-1"
                          >
                            <i className="fa-solid fa-plus text-[9px]" /> Agregar
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })()}

            <div className="pt-2 flex justify-end border-t border-amber-200">
              <button
                type="button"
                onClick={() => setModalModerarGrupoOpen(false)}
                className="pill-btn px-5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: DESIGNAR NUEVO ADMINISTRADOR OFICIAL */}
      {modalDesignarAdminOpen && (
        <div className="fixed inset-0 bg-black/70 z-[75] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-purple-300 p-6 space-y-4 shadow-2xl text-club-brown animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 border-b border-purple-200 pb-3">
              <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-900 flex items-center justify-center text-lg flex-shrink-0">
                <i className="fa-solid fa-crown text-amber-500" />
              </div>
              <div>
                <span className="text-[10px] font-black bg-purple-100 text-purple-900 px-2 py-0.5 rounded-full uppercase">
                  Gestión de Autoridades
                </span>
                <h3 className="font-brand text-lg font-bold text-purple-950 mt-0.5">
                  Designar Administrador Oficial
                </h3>
              </div>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed bg-white p-3 rounded-xl border border-purple-100">
              Ingresá el nombre de usuario de la persona que deseás nombrar como <strong>Administrador oficial</strong> de CLUB65. Tendrá acceso completo a la supervisión comunitaria, validación institucional, revisión de propuestas y centro de resoluciones.
            </p>

            <div className="space-y-1.5 text-xs">
              <label className="block font-bold text-club-brown">
                Nombre de usuario o apodo a promover:
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 font-bold text-stone-400">@</span>
                <input
                  type="text"
                  value={inputPromoverAdmin}
                  onChange={(e) => setInputPromoverAdmin(e.target.value)}
                  placeholder="ej: carola.m"
                  className="w-full pl-7 pr-3 py-2 bg-white border border-purple-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-purple-600 font-bold"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-purple-200">
              <button
                type="button"
                onClick={() => {
                  setModalDesignarAdminOpen(false);
                  setInputPromoverAdmin('');
                }}
                className="pill-btn px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handlePromoteToAdmin}
                disabled={!inputPromoverAdmin.trim()}
                className="pill-btn px-5 py-2 bg-purple-800 hover:bg-purple-900 disabled:opacity-50 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-crown text-amber-300" />
                <span>Confirmar designación</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: SOLICITAR CAMBIOS EN PROPUESTA */}
      {modalSolicitarCambiosAct && (
        <div className="fixed inset-0 bg-black/70 z-[70] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-amber-300 p-6 space-y-4 shadow-2xl text-club-brown">
            <div className="border-b border-amber-200 pb-2">
              <h3 className="font-brand text-lg font-bold text-club-brown">
                Solicitar Cambios en Propuesta
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">{modalSolicitarCambiosAct.title}</p>
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="block font-bold text-club-brown">
                Escribí una nota para indicarle al vecino qué modificaciones debe realizar:
              </label>
              <textarea
                rows={4}
                value={solicitarCambiosNota}
                onChange={(e) => setSolicitarCambiosNota(e.target.value)}
                placeholder="Ej: Por favor aclará si se requiere llevar mate propio o si el salón cuenta con sillas suficientes..."
                className="w-full p-3 bg-white border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-club-orange"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-amber-200">
              <button
                type="button"
                onClick={() => {
                  setModalSolicitarCambiosAct(null);
                  setSolicitarCambiosNota('');
                }}
                className="pill-btn px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => handleAdminModerateProposal(modalSolicitarCambiosAct.id, 'request_changes', solicitarCambiosNota)}
                className="pill-btn px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-xs cursor-pointer"
              >
                Enviar devolución al vecino
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: VISOR DE FOTO SIMPLE */}
      {modalVisorImgSrc && (
        <div
          className="fixed inset-0 bg-black/85 z-[70] flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setModalVisorImgSrc(null)}
        >
          <div
            className="relative max-w-md w-full bg-[#1A110E] p-3 rounded-3xl border border-amber-500/30 flex flex-col items-center gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-72 h-72 rounded-2xl overflow-hidden bg-black flex items-center justify-center">
              <img src={modalVisorImgSrc} alt="Visor" className="w-full h-full object-cover" />
            </div>
            <button
              onClick={() => setModalVisorImgSrc(null)}
              className="pill-btn px-5 py-1.5 bg-club-orange text-white text-xs font-bold shadow cursor-pointer"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}

      {/* MODAL: AJUSTE Y RECORTE DE FOTO (Circular para perfiles/grupos, Rectangular 16:10 para cartelera) */}
      {imageCropperState && imageCropperState.isOpen && (
        <ImageCropperModal
          imageSrc={imageCropperState.rawSrc}
          title={imageCropperState.title}
          shape={imageCropperState.shape || (imageCropperState.target === 'activity' ? 'rectangle' : 'circle')}
          onCancel={() => setImageCropperState(null)}
          onApply={(cropped) => {
            if (imageCropperState.target === 'profile') {
              setProfileForm(p => ({ ...p, avatar: cropped }));
              api.updateProfile({ avatar: cropped }).then(u => {
                setCurrentUser(u);
                refreshData();
                showToast('¡Foto de perfil actualizada con éxito!');
              }).catch(() => {
                showToast('Foto ajustada, recordá guardar los cambios de tu perfil.');
              });
            } else if (imageCropperState.target === 'group') {
              handleChangeChatPhoto(cropped);
            } else if (imageCropperState.target === 'activity') {
              setEventoForm(prev => ({ ...prev, imagen: cropped }));
              setEventoImgLabel('Foto ajustada (recorte 16:10) ✓');
              showToast('¡Foto de la actividad ajustada con éxito!');
            }
            setImageCropperState(null);
          }}
        />
      )}

      {/* MODAL: EVALUACIÓN Y SANCIÓN DE REPORTES (CON LOS 9 MOTIVOS Y NOTIFICACIÓN AL DENUNCIANTE) */}
      {modalDecisionReporte && (
        <div className="fixed inset-0 bg-black/75 z-[90] flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-club-cream w-full max-w-lg rounded-3xl border-2 border-rose-300 p-6 space-y-4 shadow-2xl text-club-brown max-h-[92vh] overflow-y-auto">
            <div className="border-b border-rose-200 pb-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black bg-rose-200 text-rose-900 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  Resolución de Seguridad
                </span>
                <h3 className="font-brand text-lg font-bold text-club-brown mt-1">
                  Resolución de Reporte y Aplicación de Sanción
                </h3>
              </div>
              <button
                onClick={() => setModalDecisionReporte(null)}
                className="text-stone-400 hover:text-stone-700 text-2xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="bg-rose-50/60 p-3.5 rounded-2xl border border-rose-200 text-xs space-y-1">
              <p className="font-bold text-stone-800">
                Denunciado:{' '}
                <button
                  type="button"
                  onClick={() => {
                    if (modalDecisionReporte.report.reportedUser) {
                      openUserProfileByName(modalDecisionReporte.report.reportedUser);
                    }
                  }}
                  className="text-rose-700 font-extrabold hover:underline"
                >
                  @{modalDecisionReporte.report.reportedUser || 'usuario'}
                </button>
              </p>
              <p className="text-stone-600">
                <strong>Motivo denunciado:</strong> {modalDecisionReporte.report.reason}
              </p>
              {modalDecisionReporte.report.messageText && (
                <p className="text-stone-600 italic bg-white p-2 rounded-lg border border-rose-100">
                  "{modalDecisionReporte.report.messageText}"
                </p>
              )}
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-club-brown mb-1.5">Decisión a tomar:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'sancionar', label: 'Sancionar usuario', icon: 'fa-gavel' },
                    { id: 'eliminar', label: 'Retirar contenido', icon: 'fa-trash-can' },
                    { id: 'desestimar', label: 'Desestimar', icon: 'fa-xmark' }
                  ].map(opt => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setModalDecisionReporte(prev => prev ? ({ ...prev, actionType: opt.id as any }) : null)}
                      className={`p-2.5 rounded-xl border text-center font-bold flex flex-col items-center gap-1 cursor-pointer transition ${
                        modalDecisionReporte.actionType === opt.id
                          ? 'bg-rose-700 border-rose-800 text-white shadow-xs'
                          : 'bg-white border-amber-200 text-stone-700 hover:bg-amber-50'
                      }`}
                    >
                      <i className={`fa-solid ${opt.icon} text-sm`} />
                      <span>{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {modalDecisionReporte.actionType === 'sancionar' && (
                <>
                  <div>
                    <label className="block font-bold text-club-brown mb-1">
                      Motivo de la sanción (coincidente con los 9 motivos del reporte):
                    </label>
                    <select
                      value={modalDecisionReporte.motive}
                      onChange={(e) => setModalDecisionReporte(prev => prev ? ({ ...prev, motive: e.target.value }) : null)}
                      className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-rose-500"
                    >
                      {MOTIVOS_REPORTE.map((m, idx) => (
                        <option key={idx} value={m}>{m}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-club-brown mb-1">Tipo de sanción:</label>
                    <div className="space-y-1.5 bg-white p-3 rounded-2xl border border-amber-200">
                      {[
                        { id: 'temporal_7', label: 'Suspensión temporal (7 días)' },
                        { id: 'temporal_30', label: 'Suspensión temporal (30 días)' },
                        { id: 'permanente', label: 'Vetado de forma permanente' }
                      ].map(item => (
                        <label key={item.id} className="flex items-center gap-2 cursor-pointer font-bold">
                          <input
                            type="radio"
                            name="sanction_type"
                            value={item.id}
                            checked={modalDecisionReporte.sanctionType === item.id}
                            onChange={() => setModalDecisionReporte(prev => prev ? ({ ...prev, sanctionType: item.id as any }) : null)}
                          />
                          <span>{item.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <label className="flex items-center gap-2 p-2.5 rounded-xl border border-amber-200 bg-white cursor-pointer font-bold">
                    <input
                      type="checkbox"
                      checked={modalDecisionReporte.alsoDelete}
                      onChange={(e) => setModalDecisionReporte(prev => prev ? ({ ...prev, alsoDelete: e.target.checked }) : null)}
                    />
                    <span>Retirar también el contenido reportado de la vista pública</span>
                  </label>
                </>
              )}

              <div>
                <label className="block font-bold text-club-brown mb-1">
                  Comentario o motivo concreto (se incluirá en el registro y en la notificación):
                </label>
                <textarea
                  rows={3}
                  value={modalDecisionReporte.comment}
                  onChange={(e) => setModalDecisionReporte(prev => prev ? ({ ...prev, comment: e.target.value }) : null)}
                  placeholder="Aclaración adicional de la administración sobre la sanción aplicada..."
                  className="w-full p-2.5 bg-white border border-amber-200 rounded-xl outline-none text-xs focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-rose-200">
              <button
                type="button"
                onClick={() => setModalDecisionReporte(null)}
                className="pill-btn px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmReportDecision}
                className="pill-btn px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <i className="fa-solid fa-check" /> Confirmar resolución
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: AVISO ALTA INSTITUCIONAL EN ESPERA DE VERIFICACIÓN */}
      {modalInstPendingNotice && (
        <div className="fixed inset-0 bg-black/70 z-[80] flex items-center justify-center p-4">
          <div className="bg-club-cream w-full max-w-md rounded-3xl border-2 border-blue-300 p-6 space-y-4 shadow-2xl text-club-brown animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-blue-900 border-b border-blue-100 pb-3">
              <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-xl flex-shrink-0 shadow-inner">
                <i className="fa-solid fa-hourglass-half text-club-orange" />
              </div>
              <div>
                <span className="text-[10px] font-black bg-blue-100 text-blue-900 px-2 py-0.5 rounded-full uppercase">
                  Registro Institucional Recibido
                </span>
                <h4 className="font-brand text-lg font-bold text-club-brown">Cuenta en Proceso de Alta</h4>
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-blue-200 text-xs space-y-3">
              <p className="font-bold text-club-brown text-sm">
                ¡Gracias por registrar a <strong>{modalInstPendingNotice.apodo}</strong>!
              </p>
              <p className="text-stone-700 leading-relaxed">
                Tu solicitud de cuenta ha sido registrada con éxito. Como institución oficial, tu cuenta <strong>estará a la espera de ser dada de alta por el Administrador Oficial</strong> de CLUB65 para acceder a un perfil activo y publicar actividades comunitarias.
              </p>
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-blue-950 flex items-start gap-2.5">
                <i className="fa-solid fa-envelope text-blue-600 text-sm mt-0.5 flex-shrink-0" />
                <span className="leading-relaxed">
                  Te hemos enviado automáticamente un correo electrónico a <strong>{modalInstPendingNotice.email}</strong> detallando el procedimiento y la documentación de personería requerida para la verificación legal.
                </span>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-amber-200">
              <button
                type="button"
                onClick={() => setModalInstPendingNotice(null)}
                className="pill-btn px-6 py-2.5 bg-club-orange hover:bg-club-orange-dark text-white text-xs font-bold shadow-sm cursor-pointer"
              >
                Entendido, muchas gracias
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IN-APP TOAST NOTIFICATION */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-[100] bg-stone-900/95 text-white px-5 py-3 rounded-2xl shadow-2xl border border-club-orange/40 text-xs sm:text-sm font-semibold flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
          <i className="fa-solid fa-circle-check text-club-orange text-base" />
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-stone-400 hover:text-white text-base cursor-pointer leading-none"
          >
            &times;
          </button>
        </div>
      )}
    </div>
  );
}
