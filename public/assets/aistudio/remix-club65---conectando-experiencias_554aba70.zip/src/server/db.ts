import fs from 'node:fs';
import path from 'node:path';
import type { User, Activity, ChatMessage, Chat, Review, Contact, SecurityReport, SanctionRecord, SimulatedEmail, BajaRecord } from '../types.ts';
import { formatArgentinaDateTime, formatArgentinaDateOnly, formatArgentinaTimeOnly } from '../utils/argentinaTime.ts';

export type { User, Activity, ChatMessage, Chat, Review, Contact, SecurityReport, SanctionRecord, SimulatedEmail, BajaRecord };

export interface DatabaseSchema {
  users: Record<string, User>;
  activities: Activity[];
  chats: Record<string, Chat>;
  reviews: Review[];
  contacts: Contact[];
  bannedUsers: string[];
  sanctions: SanctionRecord[];
  reports: SecurityReport[];
  simulatedEmails?: SimulatedEmail[];
  bajas?: BajaRecord[];
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'club65_db.json');

const INITIAL_DATA: DatabaseSchema = {
  users: {
    personal: {
      id: 'personal',
      usuario: 'carola',
      email: 'carola@correo.club65.ar',
      clave: 'caro',
      apodo: 'Carola Vecina Activa',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop',
      bio: 'Vecina de Santos Lugares, aficionada al tejido y a compartir mates en la plaza.',
      textSize: 'normal',
      contrast: false,
      tipo: 'personal',
      localidad: 'Santos Lugares',
      blockedUsers: [],
      notifications: [],
      createdAt: '2026-10-01'
    },
    institucional: {
      id: 'institucional',
      usuario: 'Municipio 3F',
      email: 'municipio@tresdefebrero.gov.ar',
      clave: 'untref',
      apodo: 'Municipalidad de Tres de Febrero',
      avatar: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=100&h=100&fit=crop',
      bio: 'Dirección de Deportes y Tercera Edad del Municipio de Tres de Febrero.',
      textSize: 'normal',
      contrast: false,
      tipo: 'institucional',
      localidad: 'Tres de Febrero',
      isVerified: true,
      estadoAlta: 'aprobada',
      entidadTipo: 'Organismo Municipal',
      cuit: '30-99900011-4',
      legalRepresentative: 'Lic. Mariano Valenzuela',
      telefonoInstitucional: '011 4734-2400',
      blockedUsers: [],
      notifications: [],
      createdAt: '2026-10-01'
    },
    moderador: {
      id: 'moderador',
      usuario: 'administrador',
      email: 'admin@club65.ar',
      clave: '12345',
      apodo: 'Administrador CLUB65',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
      bio: 'Equipo de Administración y Seguridad de CLUB65.',
      textSize: 'normal',
      contrast: false,
      tipo: 'moderador',
      localidad: 'Caseros',
      blockedUsers: [],
      notifications: [],
      createdAt: '2026-10-01'
    },
    // 2 Instituciones por validar (Pilar 2)
    inst_palomar: {
      id: 'inst_palomar',
      usuario: 'centro_palomar',
      clave: 'palomar123',
      apodo: 'Centro de Jubilados El Palomar',
      avatar: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=100&h=100&fit=crop',
      bio: 'Asociación civil sin fines de lucro con talleres y actividades para jubilados de El Palomar.',
      textSize: 'normal',
      contrast: false,
      tipo: 'institucional',
      entidadTipo: 'Centro de Jubilados',
      localidad: 'Ciudad Jardín / Palomar',
      isVerified: false,
      estadoAlta: 'pendiente',
      cuit: '30-71234567-8',
      legalRepresentative: 'Estela Domínguez (Presidenta)',
      documentoAdjunto: 'Estatuto_Personeria_Juridica_Palomar.pdf',
      documentoLegal: 'Estatuto_Personeria_Juridica_Palomar.pdf',
      documentoDescargaUrl: 'data:text/plain;charset=utf-8,Estatuto%20Legal%20Centro%20de%20Jubilados%20El%20Palomar%20-%20Personeria%20Juridica%20Nro%2048291',
      telefonoInstitucional: '011 4751-8899',
      contactoInstitucional: '011 4751-8899',
      blockedUsers: [],
      notifications: [],
      createdAt: '2026-10-18'
    },
    inst_santos_lugares: {
      id: 'inst_santos_lugares',
      usuario: 'asoc_santoslugares',
      clave: 'santos123',
      apodo: 'Asociación Vecinal Santos Lugares',
      avatar: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=100&h=100&fit=crop',
      bio: 'Espacio barrial de encuentro, cultura comunitaria y apoyo a adultos mayores.',
      textSize: 'normal',
      contrast: false,
      tipo: 'institucional',
      entidadTipo: 'Asociación Vecinal / Centro Cultural',
      localidad: 'Santos Lugares',
      isVerified: false,
      estadoAlta: 'pendiente',
      cuit: '30-68912345-1',
      legalRepresentative: 'Dr. Horacio Valenzuela (Tesorero)',
      documentoAdjunto: 'Decreto_Reconocimiento_Municipal_3F.pdf',
      documentoLegal: 'Decreto_Reconocimiento_Municipal_3F.pdf',
      documentoDescargaUrl: 'data:text/plain;charset=utf-8,Decreto%20Reconocimiento%20Municipal%20Santos%20Lugares%20-%20Expediente%203F-8812',
      telefonoInstitucional: '011 4712-4433',
      contactoInstitucional: '011 4712-4433',
      blockedUsers: [],
      notifications: [],
      createdAt: '2026-10-19'
    }
  },
  activities: [
    {
      id: 10,
      title: 'Tarde de Tejido, Cartas y Mate',
      category: 'social',
      schedule: 'Miércoles 16.00 h',
      location: 'Plaza Giorello - Santos Lugares',
      lat: -34.5985,
      lng: -58.5482,
      organizer: 'Carola Vecina Activa',
      organizerBio: 'Vecina de Santos Lugares, aficionada al tejido y a compartir mates en la plaza.',
      organizerId: 'personal',
      isInstitutional: false,
      isRecurrent: true,
      enrolled: true,
      capacity: 8,
      enrolledCount: 3,
      shortDescription: 'Mantas solidarias, truco y mate bajo los árboles.',
      description: 'Encuentro que propuse para juntarnos a tejer mantas solidarias, jugar a las cartas y tomar unos ricos mates bajo los árboles.',
      image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: ['carola', 'Marta Sánchez', 'Graciela Pérez']
    },
    {
      id: 1,
      title: 'Movilidad y elongación',
      category: 'salud',
      schedule: 'Martes y jueves 18.00 h',
      location: 'CEDEM 4 - Teodoro Plaza y Castelli, Ciudadela',
      lat: -34.6366,
      lng: -58.5414,
      organizer: 'Municipalidad de Tres de Febrero',
      organizerBio: 'Área oficial de deportes para adultos mayores del Municipio de Tres de Febrero.',
      organizerId: 'institucional',
      isInstitutional: true,
      isRecurrent: true,
      enrolled: true,
      capacity: 20,
      enrolledCount: 2,
      shortDescription: 'Clase adaptada para mejorar la movilidad articular.',
      description: 'Clase adaptada para personas mayores orientada a mejorar la postura, flexibilidad y articulaciones.',
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: ['carola', 'Roberto Gómez']
    },
    {
      id: 2,
      title: 'Taller de Memoria y Café Compartido',
      category: 'memoria',
      schedule: 'Viernes 16.30 h',
      location: 'Centro Cultural Caseros - Valentín Gómez 4726',
      lat: -34.6068,
      lng: -58.5647,
      organizer: 'Red de Centros de Jubilados',
      organizerBio: 'Asociación civil que fomenta la estimulación cognitiva en personas mayores.',
      organizerId: 'otra_inst',
      isInstitutional: true,
      isRecurrent: true,
      enrolled: false,
      capacity: 15,
      enrolledCount: 1,
      shortDescription: 'Juegos de agilidad mental y acertijos en grupo.',
      description: 'Juegos de agilidad mental y acertijos para ejercitar la memoria compartiendo café y medialunas.',
      image: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: ['Graciela Pérez']
    },
    {
      id: 3,
      title: 'Clases de Tango y Milonga para Principiantes',
      category: 'musica',
      schedule: 'Sábados 17.00 h',
      location: 'Plaza de la Unidad Nacional - Caseros',
      lat: -34.6033,
      lng: -58.5630,
      organizer: 'Club Social Caseros',
      organizerBio: 'Club tradicional de barrio con más de 70 años organizando talleres artísticos.',
      organizerId: 'otra_inst',
      isInstitutional: true,
      isRecurrent: true,
      enrolled: true,
      capacity: 25,
      enrolledCount: 2,
      shortDescription: 'Pasos básicos del 2x4 al aire libre.',
      description: 'Aprendé los pasos básicos del 2x4 al aire libre en un ambiente alegre y distendido.',
      image: 'https://images.unsplash.com/photo-1504609813442-a8924e83f76e?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: ['carola', 'Roberto Gómez']
    },
    {
      id: 4,
      title: 'Paseo Fotográfico por Ciudad Jardín',
      category: 'naturaleza',
      schedule: 'Domingo 26 de Octubre 10.30 h',
      location: 'Plaza de los Aviadores - Ciudad Jardín',
      lat: -34.6015,
      lng: -58.5830,
      organizer: 'Juan Carlos Benítez',
      organizerBio: 'Jubilado entusiasta de la fotografía y los pasajes arbolados de Palomar.',
      organizerId: 'personal_otro',
      isInstitutional: false,
      isRecurrent: false,
      enrolled: false,
      capacity: 12,
      enrolledCount: 1,
      shortDescription: 'Caminata fotográfica compartiendo tips sencillos.',
      description: 'Caminata fotográfica compartiendo tips sencillos de celular bajo los árboles.',
      image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: ['Juan Carlos Benítez']
    },
    {
      id: 5,
      title: 'Taller de Celulares y Trámites Digitales',
      category: 'tecnologia',
      schedule: 'Jueves 15.00 h',
      location: 'Centro Cultural Caseros - Valentín Gómez 4726',
      lat: -34.6068,
      lng: -58.5647,
      organizer: 'Punto Digital Tres de Febrero',
      organizerBio: 'Espacio de capacitación comunitaria y alfabetización digital para adultos mayores.',
      organizerId: 'institucional',
      isInstitutional: true,
      isRecurrent: true,
      enrolled: false,
      capacity: 18,
      enrolledCount: 0,
      shortDescription: 'Paso a paso para usar WhatsApp y trámites de PAMI/ANSES.',
      description: 'Aprende paso a paso a usar WhatsApp, pedir turnos de PAMI/ANSES y hacer trámites de forma segura.',
      image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=500&fit=crop',
      isApproved: true,
      proposalStatus: 'aprobada',
      vettedUsers: [],
      enrolledUsernames: []
    },
    // 3 Propuestas Pendientes de Vecinos (Pilar 1)
    {
      id: 201,
      title: 'Caminata Botánica y Reconocimiento de Árboles',
      category: 'naturaleza',
      schedule: 'Sábado 10.00 h',
      location: 'Plaza Pineral - Caseros',
      lat: -34.6070,
      lng: -58.5590,
      organizer: 'Roberto Gómez',
      organizerBio: 'Aficionado a la botánica urbana y vecino activo de Caseros.',
      organizerId: 'personal_roberto',
      isInstitutional: false,
      isRecurrent: false,
      enrolled: false,
      capacity: 15,
      enrolledCount: 1,
      shortDescription: 'Paseo suave aprendiendo especies de árboles y flores.',
      description: 'Paseo guiado a paso tranquilo por la Plaza Pineral para identificar especies de tipas, jacarandás y ceibos. Traer calzado cómodo y botella de agua.',
      image: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&h=500&fit=crop',
      isApproved: false,
      proposalStatus: 'pendiente',
      vettedUsers: [],
      enrolledUsernames: ['Roberto Gómez']
    },
    {
      id: 202,
      title: 'Taller de Pintura a la Acuarela en la Plaza',
      category: 'cultura',
      schedule: 'Lunes 16.00 h',
      location: 'Plaza de los Aviadores - Ciudad Jardín',
      lat: -34.6015,
      lng: -58.5830,
      organizer: 'Marta Sánchez',
      organizerBio: 'Docente jubilada de plástica con ganas de compartir técnicas sencillas al aire libre.',
      organizerId: 'personal_marta',
      isInstitutional: false,
      isRecurrent: true,
      enrolled: false,
      capacity: 10,
      enrolledCount: 1,
      shortDescription: 'Iniciación al paisaje en acuarela con materiales sencillos.',
      description: 'Encuentro para pintar las flores y fuentes de Ciudad Jardín. No hace falta experiencia previa, solo entusiasmo y ganas de expresarse.',
      image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&h=500&fit=crop',
      isApproved: false,
      proposalStatus: 'pendiente',
      vettedUsers: [],
      enrolledUsernames: ['Marta Sánchez']
    },
    {
      id: 203,
      title: 'Torneo Barrial de Truco y Escoba de 15',
      category: 'social',
      schedule: 'Viernes 17.30 h',
      location: 'Club Social y Deportivo El Libertador - Santos Lugares',
      lat: -34.5950,
      lng: -58.5450,
      organizer: 'Juan Carlos Benítez',
      organizerBio: 'Vecino de toda la vida y organizador de peñas vecinales.',
      organizerId: 'personal_juancarlos',
      isInstitutional: false,
      isRecurrent: false,
      enrolled: false,
      capacity: 24,
      enrolledCount: 1,
      shortDescription: 'Partidas amistosas en parejas con medialunas y café.',
      description: 'Tarde de cartas clásica para divertirse sanamente en parejas. Habrá premios simbólicos y sorteo de budines caseros.',
      image: 'https://images.unsplash.com/photo-1541278107931-e006523892df?w=800&h=500&fit=crop',
      isApproved: false,
      proposalStatus: 'pendiente',
      vettedUsers: [],
      enrolledUsernames: ['Juan Carlos Benítez']
    },
    {
      id: 204,
      title: 'Taller de Encuadernación Artesanal y Cartas',
      category: 'cultura',
      schedule: 'Jueves 17.00 h',
      location: 'Plaza Giorello - Santos Lugares',
      lat: -34.5985,
      lng: -58.5482,
      organizer: 'Carola Vecina Activa',
      organizerBio: 'Vecina de Santos Lugares, aficionada al tejido y a compartir mates en la plaza.',
      organizerId: 'personal',
      isInstitutional: false,
      isRecurrent: true,
      enrolled: true,
      capacity: 8,
      enrolledCount: 1,
      shortDescription: 'Armado de libretas y álbumes artesanales.',
      description: 'Taller práctico para confeccionar libretas y cuadernos artesanales con tapas de cartón reciclado.',
      image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&h=500&fit=crop',
      isApproved: false,
      proposalStatus: 'cambios_solicitados',
      proposalNote: 'Por favor indicá si los participantes deben llevar sus propias tijeras o si el espacio cuenta con materiales.',
      proposedAt: '21/10/2026, 14:30 hs',
      changesRequestedAt: '22/10/2026, 10:15 hs',
      versions: [
        {
          version: 1,
          date: '21/10/2026, 14:30 hs',
          title: 'Taller de Encuadernación Artesanal y Cartas',
          schedule: 'Jueves 17.00 h',
          location: 'Plaza Giorello - Santos Lugares',
          capacity: 8,
          description: 'Taller práctico para confeccionar libretas y cuadernos artesanales con tapas de cartón reciclado.',
          shortDescription: 'Armado de libretas y álbumes artesanales.',
          image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&h=500&fit=crop',
          note: 'Versión original de la propuesta'
        }
      ],
      vettedUsers: [],
      enrolledUsernames: ['carola']
    },
    {
      id: 205,
      title: 'Taller de Radioteatro Barrial',
      category: 'cultura',
      schedule: 'Miércoles 17.30 h',
      location: 'Centro Cultural Caseros - Aula 3',
      lat: -34.6068,
      lng: -58.5647,
      organizer: 'Marta Sánchez',
      organizerBio: 'Docente jubilada de plástica y teatro vecinal.',
      organizerId: 'personal_marta',
      isInstitutional: false,
      isRecurrent: true,
      enrolled: false,
      capacity: 15,
      enrolledCount: 1,
      shortDescription: 'Lecturas dramatizadas y efectos de sonido en vivo.',
      description: 'Lecturas dramatizadas de radioteatro con efectos sonoros caseros.',
      image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&h=500&fit=crop',
      isApproved: false,
      proposalStatus: 'pendiente',
      proposalNote: 'Por favor especificar el salón o aula exacta y reducir el cupo máximo a 15 personas para mayor comodidad.',
      proposedAt: '21/10/2026, 14:30 hs',
      changesRequestedAt: '22/10/2026, 10:15 hs',
      changesSubmittedAt: '23/10/2026, 11:45 hs',
      versions: [
        {
          version: 1,
          date: '21/10/2026, 14:30 hs',
          title: 'Taller de Radioteatro Barrial',
          schedule: 'Miércoles 17.30 h',
          location: 'Centro Cultural Caseros',
          capacity: 25,
          description: 'Lecturas dramatizadas de radioteatro con efectos sonoros caseros.',
          shortDescription: 'Lecturas dramatizadas y efectos de sonido en vivo.',
          image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&h=500&fit=crop',
          note: 'Versión original presentada'
        },
        {
          version: 2,
          date: '23/10/2026, 11:45 hs',
          title: 'Taller de Radioteatro Barrial',
          schedule: 'Miércoles 17.30 h',
          location: 'Centro Cultural Caseros - Aula 3',
          capacity: 15,
          description: 'Lecturas dramatizadas de radioteatro con efectos sonoros caseros.',
          shortDescription: 'Lecturas dramatizadas y efectos de sonido en vivo.',
          image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&h=500&fit=crop',
          note: 'Ajuste de cupo a 15 y especificación de Aula 3 en Centro Cultural'
        }
      ],
      vettedUsers: [],
      enrolledUsernames: ['Marta Sánchez']
    }
  ],
  chats: {
    '1': {
      id: 1,
      title: 'Movilidad y elongación (CEDEM 4)',
      subtitle: '16 participantes inscriptos',
      type: 'grupal',
      activityId: 1,
      organizerId: 'institucional',
      adminUsernames: ['Municipio 3F'],
      avatar: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=100&h=100&fit=crop',
      allowedRoles: ['personal', 'institucional'],
      participants: ['carola', 'roberto', 'institucional'],
      messages: [
        { id: 'm1_1', senderId: 'roberto', sender: 'Roberto Gómez', avatar: 'RG', role: 'vecino', text: '¡Hola a todos! ¿Alguien sabe si para la clase de mañana hay que llevar colchoneta o las prestan allá?', time: '10:14 hs' },
        { id: 'm1_2', senderId: 'institucional', sender: 'Municipalidad de Tres de Febrero', isVerifiedInst: true, avatar: 'CEDEM', role: 'institucional', text: '¡Hola Roberto! En el gimnasio tenemos colchonetas limpias para todos. Solo traigan toallita de mano y botellita de agua.', time: '10:20 hs' },
        { id: 'm1_3', senderId: 'personal', sender: 'Carola Vecina Activa', avatar: 'C', role: 'personal', text: '¡Buenísimo! Ahí estaremos a las 18 hs puntuales.', time: '10:25 hs' }
      ]
    },
    '10': {
      id: 10,
      title: 'Tarde de Tejido, Cartas y Mate',
      subtitle: '2 vecinas anotadas',
      type: 'grupal',
      activityId: 10,
      organizerId: 'personal',
      creatorId: 'personal',
      creatorName: 'Carola Vecina Activa',
      adminUsernames: ['carola', 'Carola Vecina Activa'],
      avatar: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?w=100&h=100&fit=crop',
      allowedRoles: ['personal'],
      participants: ['carola', 'Marta Sánchez', 'Graciela Pérez'],
      messages: [
        { id: 'm10_1', senderId: 'personal', sender: 'Carola Vecina Activa', isOrganizer: true, avatar: 'C', role: 'personal', text: '¡Hola a todas! Qué alegría que se hayan sumado. ¿Llevan agujas de tejer o prefieren jugar a las cartas?', time: '09:00 hs' },
        { id: 'm10_2', senderId: 'marta', sender: 'Marta Sánchez', avatar: 'MS', role: 'vecino', text: '¡Hola Carola! Yo llevo lana y agujas número 4, y un paquete de bizcochitos.', time: '09:40 hs' },
        { id: 'm10_3', senderId: 'graciela', sender: 'Graciela Pérez', avatar: 'GP', role: 'vecino', text: '¡Yo llevo el termo con agua caliente y las cartas de truco! Nos vemos mañana a las 16 hs.', time: '10:05 hs' }
      ]
    },
    '101': {
      id: 101,
      title: 'Roberto Gómez',
      subtitle: 'Chat privado',
      type: 'privado',
      activityId: null,
      allowedRoles: ['personal'],
      participants: ['carola', 'Roberto Gómez'],
      messages: [
        { id: 'm101_1', senderId: 'roberto', sender: 'Roberto Gómez', avatar: 'RG', role: 'vecino', text: 'Hola, ¿cómo estás? Te quería consultar si nos encontramos antes para ir juntos a la clase.', time: '11:05 hs' },
        { id: 'm101_2', senderId: 'personal', sender: 'Carola Vecina Activa', avatar: 'C', role: 'personal', text: '¡Hola Roberto! Dale, nos encontramos 17:40 hs en la esquina de la farmacia.', time: '11:15 hs' }
      ]
    },
    '102': {
      id: 102,
      title: 'Graciela Pérez',
      subtitle: 'Chat privado',
      type: 'privado',
      activityId: null,
      allowedRoles: ['personal'],
      participants: ['carola', 'Graciela Pérez'],
      messages: [
        { id: 'm102_1', senderId: 'graciela', sender: 'Graciela Pérez', avatar: 'GP', role: 'vecino', text: 'Gracias por avisarme de la merienda.', time: 'Lunes' }
      ]
    }
  },
  reviews: [
    {
      id: 201,
      actividadId: 1,
      actividad: 'Movilidad y elongación (CEDEM 4)',
      autor: 'Carola Vecina Activa',
      estrellas: 5,
      fecha: 'Hace 1 semana',
      texto: 'La profesora Mariana es muy atenta y paciente. El espacio es amplio y ventilado. ¡Muy recomendable para volver a moverse sin dolores!',
      foto: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop',
      media: ['https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop']
    },
    {
      id: 202,
      actividadId: 1,
      actividad: 'Movilidad y elongación (CEDEM 4)',
      autor: 'Roberto Gómez',
      estrellas: 5,
      fecha: 'Hace 2 semanas',
      texto: 'Excelente ritmo de la clase. Los profes muy atentos si alguien necesitaba descansar.',
      foto: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop',
      media: ['https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=500&fit=crop']
    },
    {
      id: 203,
      actividadId: 10,
      actividad: 'Tarde de Tejido, Cartas y Mate',
      autor: 'Marta Sánchez',
      estrellas: 5,
      fecha: 'Hace 1 semana',
      texto: 'Hermoso grupo de tejido, la pasamos genial con unos mates.',
      foto: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?w=800&h=500&fit=crop',
      media: ['https://images.unsplash.com/photo-1584992236310-6edddc08acff?w=800&h=500&fit=crop']
    },
    {
      id: 204,
      actividadId: 10,
      actividad: 'Tarde de Tejido, Cartas y Mate',
      autor: 'Graciela Pérez',
      estrellas: 5,
      fecha: 'Hace 2 semanas',
      texto: 'Muy buena tarde compartiendo anécdotas bajo los árboles.',
      foto: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?w=800&h=500&fit=crop',
      media: ['https://images.unsplash.com/photo-1516307365426-bea591f05011?w=800&h=500&fit=crop']
    }
  ],
  contacts: [
    {
      id: 'c1',
      nombre: 'Roberto Gómez',
      detalle: 'Caseros • Asiste a Movilidad',
      avatar: 'RG',
      avatarClass: 'bg-club-blue',
      bio: 'Vecino de Caseros, jubilado metalúrgico apasionado por el deporte y el tango.',
      foto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop'
    },
    {
      id: 'c2',
      nombre: 'Graciela Pérez',
      detalle: 'Santos Lugares • Asiste a Memoria',
      avatar: 'GP',
      avatarClass: 'bg-club-teal',
      bio: 'Vecina de Santos Lugares, me gusta la lectura, el café con amigas y las plantas.',
      foto: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop'
    },
    {
      id: 'c3',
      nombre: 'Marta Sánchez',
      detalle: 'Ciudadela • Amante del tejido',
      avatar: 'MS',
      avatarClass: 'bg-purple-600',
      bio: 'Jubilada docente, tejedora de corazón y organizadora de mateadas.',
      foto: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=200&h=200&fit=crop'
    }
  ],
  // 5 Usuarios Sancionados (Pilar 4)
  bannedUsers: [
    'usuario_troll',
    'spammer_crypto',
    'cuenta_falsa_3f',
    'estafas_online',
    'perfil_ofensivo'
  ],
  sanctions: [
    {
      id: 'sanc_1',
      username: 'usuario_troll',
      reason: 'Odio, abuso, o acoso',
      comment: 'Comentarios descalificadores e insultos reiterados en grupos vecinales.',
      adminUsername: 'administrador',
      date: '18/10/2026',
      type: 'permanente',
      liftDate: 'Sin fecha (Permanente)',
      reportId: 'rep_ant_1'
    },
    {
      id: 'sanc_2',
      username: 'spammer_crypto',
      reason: 'Spam',
      comment: 'Envío masivo de enlaces sospechosos a través de canales comunitarios.',
      adminUsername: 'administrador',
      date: '20/10/2026',
      type: 'temporal_30',
      liftDate: '19/11/2026',
      reportId: 'rep_1'
    },
    {
      id: 'sanc_3',
      username: 'cuenta_falsa_3f',
      reason: 'Suplantación de identidad',
      comment: 'Se hacía pasar por funcionario de la Municipalidad para solicitar trámites.',
      adminUsername: 'administrador',
      date: '15/10/2026',
      type: 'permanente',
      liftDate: 'Sin fecha (Permanente)'
    },
    {
      id: 'sanc_4',
      username: 'estafas_online',
      reason: 'Comportamientos ilegales',
      comment: 'Intento de captación indebida de datos bancarios a adultos mayores.',
      adminUsername: 'administrador',
      date: '21/10/2026',
      type: 'permanente',
      liftDate: 'Sin fecha (Permanente)'
    },
    {
      id: 'sanc_5',
      username: 'perfil_ofensivo',
      reason: 'Discurso violento',
      comment: 'Lenguaje agresivo y amenazas en reseñas y comentarios.',
      adminUsername: 'administrador',
      date: '22/10/2026',
      type: 'temporal_7',
      liftDate: '29/10/2026'
    }
  ],
  // 1 Reporte de Seguridad Inicial (Pilar 3)
  reports: [
    {
      id: 'rep_1',
      type: 'chat_message',
      chatId: 1,
      messageId: 'm1_1',
      messageText: 'Enlace no solicitado detectado en canal público.',
      reportedUser: 'spammer_crypto',
      reporterUser: 'Carola Vecina Activa',
      reporterUsername: 'carola',
      reason: 'Spam',
      comment: 'Compartieron links sospechosos en el grupo comunitario durante la mañana.',
      timestamp: 'Hace 2 horas',
      status: 'pendiente'
    }
  ],
  simulatedEmails: [
    {
      id: 'em_init_1',
      to: 'centro_palomar@institucion.club65.ar',
      subject: 'CLUB65 - Solicitud de Alta Institucional Recibida (Procedimiento)',
      body: 'Estimados representantes de Centro de Jubilados El Palomar: hemos recibido su solicitud de alta. Su personería jurídica se encuentra en proceso de revisión administrativa. Los mantendremos informados por esta vía.',
      date: '18/10/2026, 09:30 hs'
    }
  ]
};

function ensureDbFile(): DatabaseSchema {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(INITIAL_DATA, null, 2), 'utf-8');
    return INITIAL_DATA;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed: DatabaseSchema = JSON.parse(raw);

    let needsSave = false;

    // Ensure activities have enrolledCount synced
    if (parsed.activities) {
      parsed.activities.forEach(a => {
        if (!a.enrolledUsernames) a.enrolledUsernames = [];
        a.enrolledCount = a.enrolledUsernames.length;
      });
    } else {
      parsed.activities = INITIAL_DATA.activities;
      needsSave = true;
    }

    // Ensure at least 3 pending proposals exist for the Dashboard
    const pendingProps = parsed.activities.filter(a => !a.isApproved && a.proposalStatus === 'pendiente');
    if (pendingProps.length < 3) {
      INITIAL_DATA.activities
        .filter(a => !a.isApproved && a.proposalStatus === 'pendiente')
        .forEach(initPending => {
          if (!parsed.activities.some(a => a.id === initPending.id)) {
            parsed.activities.push(initPending);
            needsSave = true;
          }
        });
    }

    // Ensure proposal 204 exists if never created
    if (!parsed.activities.some(a => a.id === 204)) {
      const initCambios = INITIAL_DATA.activities.find(a => a.id === 204);
      if (initCambios) {
        parsed.activities.push(initCambios);
        needsSave = true;
      }
    }

    // Ensure all activities have versions populated
    if (parsed.activities) {
      parsed.activities.forEach(a => {
        if (!a.versions || a.versions.length === 0) {
          a.versions = [
            {
              version: 1,
              date: a.proposedAt || '21/10/2026, 14:30 hs',
              title: a.title,
              schedule: a.schedule,
              location: a.location,
              capacity: a.capacity,
              description: a.description,
              shortDescription: a.shortDescription,
              image: a.image,
              note: 'Versión inicial de la propuesta'
            }
          ];
          needsSave = true;
        }
      });
    }

    // Ensure users object
    if (!parsed.users) {
      parsed.users = INITIAL_DATA.users;
      needsSave = true;
    } else {
      if (parsed.users.personal && !parsed.users.personal.email) {
        parsed.users.personal.email = 'carola@correo.club65.ar';
        needsSave = true;
      }
      if (parsed.users.moderador && !parsed.users.moderador.email) {
        parsed.users.moderador.email = 'admin@club65.ar';
        needsSave = true;
      }
      if (parsed.users.institucional && !parsed.users.institucional.email) {
        parsed.users.institucional.email = 'municipio@tresdefebrero.gov.ar';
        needsSave = true;
      }
      // Ensure institutions to validate exist
      if (!parsed.users.inst_palomar) {
        parsed.users.inst_palomar = INITIAL_DATA.users.inst_palomar;
        needsSave = true;
      } else {
        if (!parsed.users.inst_palomar.entidadTipo) parsed.users.inst_palomar.entidadTipo = 'Centro de Jubilados';
        if (!parsed.users.inst_palomar.telefonoInstitucional) parsed.users.inst_palomar.telefonoInstitucional = '011 4751-8899';
        if (!parsed.users.inst_palomar.documentoDescargaUrl) parsed.users.inst_palomar.documentoDescargaUrl = 'data:text/plain;charset=utf-8,Estatuto%20Legal%20Centro%20de%20Jubilados%20El%20Palomar';
      }
      if (!parsed.users.inst_santos_lugares) {
        parsed.users.inst_santos_lugares = INITIAL_DATA.users.inst_santos_lugares;
        needsSave = true;
      } else {
        if (!parsed.users.inst_santos_lugares.entidadTipo) parsed.users.inst_santos_lugares.entidadTipo = 'Asociación Vecinal / Centro Cultural';
        if (!parsed.users.inst_santos_lugares.telefonoInstitucional) parsed.users.inst_santos_lugares.telefonoInstitucional = '011 4712-4433';
        if (!parsed.users.inst_santos_lugares.documentoDescargaUrl) parsed.users.inst_santos_lugares.documentoDescargaUrl = 'data:text/plain;charset=utf-8,Decreto%20Reconocimiento%20Municipal%20Santos%20Lugares';
      }
      // Ensure user properties
      Object.values(parsed.users).forEach(u => {
        if (!u.blockedUsers) u.blockedUsers = [];
        if (!u.notifications) u.notifications = [];
      });
    }

    // Initialize collections only if undefined (never overwrite user moderations/sanction lifts)
    if (!parsed.bannedUsers) {
      parsed.bannedUsers = [...INITIAL_DATA.bannedUsers];
      needsSave = true;
    }

    if (!parsed.sanctions) {
      parsed.sanctions = [...INITIAL_DATA.sanctions];
      needsSave = true;
    }

    if (!parsed.reports) {
      parsed.reports = [...INITIAL_DATA.reports];
      needsSave = true;
    }

    if (!parsed.bajas) {
      parsed.bajas = [];
      needsSave = true;
    }

    // Ensure all reports have reporterUsername properly populated
    parsed.reports.forEach(r => {
      if (!r.reporterUsername && r.reporterUser) {
        r.reporterUsername = r.reporterUser.toLowerCase().includes('carola') ? 'carola' : r.reporterUser.toLowerCase().replace(/\s+/g, '_');
      }
    // Ensure activities have proposedAt populated
    if (parsed.activities) {
      parsed.activities.forEach(a => {
        if (!a.proposedAt) {
          a.proposedAt = '21/10/2026, 14:30 hs';
        }
      });
    }

    // Ensure chat messages have IDs and adminUsernames
    if (parsed.chats) {
      Object.values(parsed.chats).forEach(chat => {
        if (!chat.adminUsernames) {
          chat.adminUsernames = chat.creatorId ? [chat.creatorId] : (chat.organizerId ? [chat.organizerId] : []);
        }
        if (chat.messages) {
          chat.messages.forEach((msg, idx) => {
            if (!msg.id) msg.id = `msg_${chat.id}_${idx}_${Math.random()}`;
          });
        }
      });
    }

    // Ensure simulatedEmails
    if (!parsed.simulatedEmails) {
      parsed.simulatedEmails = [...(INITIAL_DATA.simulatedEmails || [])];
      needsSave = true;
    }

    // Ensure activity 205 with complete date breakdown exists
    if (parsed.activities && !parsed.activities.some(a => a.id === 205)) {
      const a205 = INITIAL_DATA.activities.find(a => a.id === 205);
      if (a205) {
        parsed.activities.unshift(a205);
        needsSave = true;
      }
    }

    // Ensure chat participants sync with activity enrolled users
    if (parsed.chats && parsed.activities) {
      parsed.activities.forEach(act => {
        const chatKey = Object.keys(parsed.chats).find(k => parsed.chats[k].activityId === act.id || Number(k) === act.id);
        if (chatKey) {
          const chat = parsed.chats[chatKey];
          const participants = chat.participants || [];
          chat.participants = participants;
          (act.enrolledUsernames || []).forEach(u => {
            const uObj = Object.values(parsed.users).find(usr => usr.usuario.toLowerCase() === u.toLowerCase() || usr.apodo.toLowerCase() === u.toLowerCase());
            const display = uObj ? uObj.apodo : u;
            if (!participants.includes(display) && !participants.includes(u)) {
              participants.push(display);
              needsSave = true;
            }
          });
        }
      });
    }

    if (needsSave) {
      fs.writeFileSync(DB_FILE, JSON.stringify(parsed, null, 2), 'utf-8');
    }

    return parsed;
  } catch {
    return INITIAL_DATA;
  }
}

function saveDb(data: DatabaseSchema): void {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

export const db = {
  getUsers(): Record<string, User> {
    const data = ensureDbFile();
    return data.users;
  },

  getUser(id: string): User | undefined {
    const data = ensureDbFile();
    return data.users[id];
  },

  findUserByCredentials(usuarioOrEmail: string, clave: string): User | undefined {
    const data = ensureDbFile();
    const u = usuarioOrEmail.trim().toLowerCase();
    return Object.values(data.users).find(
      user => (user.usuario.trim().toLowerCase() === u || (user.email && user.email.trim().toLowerCase() === u)) && user.clave === clave
    );
  },

  findUserByUsername(usuario: string): User | undefined {
    const data = ensureDbFile();
    const u = usuario.trim().toLowerCase();
    return Object.values(data.users).find(
      user => user.usuario.trim().toLowerCase() === u
    );
  },

  getPublicUser(identifier: string): { id: string; usuario: string; apodo: string; avatar: string; bio: string; tipo: string; localidad?: string } | undefined {
    const data = ensureDbFile();
    const clean = identifier.replace(/^@/, '').trim().toLowerCase();
    const u = Object.values(data.users).find(
      user => user.usuario.toLowerCase() === clean || user.apodo.toLowerCase() === clean || user.id.toLowerCase() === clean
    );
    if (!u) return undefined;
    return {
      id: u.id,
      usuario: u.usuario,
      apodo: u.apodo,
      avatar: u.avatar,
      bio: u.bio,
      tipo: u.tipo,
      localidad: u.localidad
    };
  },

  createUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const data = ensureDbFile();
    const id = `user_${Date.now()}`;
    const newUser: User = {
      ...user,
      id,
      blockedUsers: [],
      notifications: [],
      createdAt: new Date().toISOString()
    };
    data.users[id] = newUser;
    saveDb(data);
    return newUser;
  },

  updateUser(id: string, updates: Partial<User>): User | undefined {
    const data = ensureDbFile();
    const oldUser = data.users[id];
    if (!oldUser) return undefined;
    
    const oldApodo = oldUser.apodo;
    const oldUsername = oldUser.usuario;
    const newApodo = updates.apodo || oldApodo;
    const newBio = updates.bio !== undefined ? updates.bio : oldUser.bio;

    data.users[id] = { ...oldUser, ...updates };

    if (updates.avatar && updates.avatar !== oldUser.avatar) {
      const newAv = updates.avatar;
      Object.values(data.chats).forEach(chat => {
        chat.messages.forEach(msg => {
          if (msg.senderId === id || msg.senderId === oldUsername || msg.sender === oldApodo || msg.sender === newApodo) {
            msg.avatar = newAv;
          }
        });
      });
      if (data.contacts) {
        data.contacts.forEach(c => {
          if (c.id === id || c.nombre.toLowerCase() === oldApodo.toLowerCase() || c.nombre.toLowerCase() === newApodo.toLowerCase()) {
            c.foto = newAv;
            c.avatar = newAv;
          }
        });
      }
      if (data.reviews) {
        data.reviews.forEach(rev => {
          if (rev.autor.toLowerCase() === oldApodo.toLowerCase() || rev.autor.toLowerCase() === newApodo.toLowerCase()) {
            rev.foto = newAv;
          }
        });
      }
    }

    if (updates.apodo && updates.apodo !== oldApodo) {
      Object.values(data.chats).forEach(chat => {
        if (chat.creatorId === id) {
          chat.creatorName = newApodo;
        }
        if (chat.participants) {
          chat.participants = chat.participants.map(p => p === oldApodo ? newApodo : p);
        }
        chat.messages.forEach(msg => {
          if (msg.senderId === id || msg.senderId === oldUsername || msg.sender === oldApodo) {
            msg.sender = newApodo;
          }
        });
      });

      data.activities.forEach(act => {
        if (act.organizerId === id) {
          act.organizer = newApodo;
          act.organizerBio = newBio;
        }
      });

      data.reviews.forEach(rev => {
        if (rev.autor === oldApodo) {
          rev.autor = newApodo;
        }
      });
    }

    saveDb(data);
    return data.users[id];
  },

  blockUser(userId: string, targetUsername: string): boolean {
    const data = ensureDbFile();
    const user = data.users[userId];
    if (!user) return false;
    if (!user.blockedUsers) user.blockedUsers = [];
    const lowerTarget = targetUsername.trim().toLowerCase();

    const targetObj = Object.values(data.users).find(
      u => u.id.toLowerCase() === lowerTarget || u.usuario.toLowerCase() === lowerTarget || u.apodo.toLowerCase() === lowerTarget
    );
    const toAdd = [lowerTarget];
    if (targetObj) {
      toAdd.push(targetObj.id.toLowerCase());
      toAdd.push(targetObj.usuario.toLowerCase());
      toAdd.push(targetObj.apodo.toLowerCase());
    }
    toAdd.forEach(t => {
      if (!user.blockedUsers!.includes(t)) {
        user.blockedUsers!.push(t);
      }
    });
    saveDb(data);
    return true;
  },

  unblockUser(userId: string, targetUsername: string): boolean {
    const data = ensureDbFile();
    const user = data.users[userId];
    if (!user || !user.blockedUsers) return false;
    const lowerTarget = targetUsername.trim().toLowerCase();
    const targetObj = Object.values(data.users).find(
      u => u.id.toLowerCase() === lowerTarget || u.usuario.toLowerCase() === lowerTarget || u.apodo.toLowerCase() === lowerTarget
    );
    const toRemove = [lowerTarget];
    if (targetObj) {
      toRemove.push(targetObj.id.toLowerCase());
      toRemove.push(targetObj.usuario.toLowerCase());
      toRemove.push(targetObj.apodo.toLowerCase());
    }
    user.blockedUsers = user.blockedUsers.filter(u => !toRemove.includes(u.toLowerCase()));
    saveDb(data);
    return true;
  },

  isUserBlocked(userA: string, userB: string): boolean {
    const data = ensureDbFile();
    const aLower = (userA || '').trim().toLowerCase();
    const bLower = (userB || '').trim().toLowerCase();
    if (!aLower || !bLower) return false;

    // Find userA and userB objects
    const uA = Object.values(data.users).find(
      u => u.id.toLowerCase() === aLower || u.usuario.toLowerCase() === aLower || u.apodo.toLowerCase() === aLower
    );
    const uB = Object.values(data.users).find(
      u => u.id.toLowerCase() === bLower || u.usuario.toLowerCase() === bLower || u.apodo.toLowerCase() === bLower
    );

    const aBlocksB = uA?.blockedUsers?.some(
      b => b.toLowerCase() === bLower || (uB && (b.toLowerCase() === uB.usuario.toLowerCase() || b.toLowerCase() === uB.apodo.toLowerCase() || b.toLowerCase() === uB.id.toLowerCase()))
    );

    const bBlocksA = uB?.blockedUsers?.some(
      b => b.toLowerCase() === aLower || (uA && (b.toLowerCase() === uA.usuario.toLowerCase() || b.toLowerCase() === uA.apodo.toLowerCase() || b.toLowerCase() === uA.id.toLowerCase()))
    );

    return Boolean(aBlocksB || bBlocksA);
  },

  addNotification(usernameOrId: string, text: string): void {
    const data = ensureDbFile();
    const lower = usernameOrId.trim().toLowerCase();
    const user = Object.values(data.users).find(
      u => u.id.toLowerCase() === lower || u.usuario.toLowerCase() === lower || u.apodo.toLowerCase() === lower
    );
    if (user) {
      if (!user.notifications) user.notifications = [];
      user.notifications.unshift({
        id: `notif_${Date.now()}_${Math.random()}`,
        text,
        time: 'Recién',
        read: false
      });
      saveDb(data);
    }
  },

  getActivities(): Activity[] {
    const data = ensureDbFile();
    return data.activities;
  },

  getActivityById(id: number): Activity | undefined {
    const data = ensureDbFile();
    return data.activities.find(a => a.id === id);
  },

  createActivity(act: Omit<Activity, 'id'>): Activity {
    const data = ensureDbFile();
    const id = Date.now();
    const nowStr = formatArgentinaDateTime();
    const newAct: Activity = {
      ...act,
      id,
      proposedAt: act.proposedAt || nowStr
    };
    data.activities.unshift(newAct);
    saveDb(data);
    return newAct;
  },

  updateActivity(id: number, updates: Partial<Activity>): Activity | undefined {
    const data = ensureDbFile();
    const idx = data.activities.findIndex(a => a.id === id);
    if (idx === -1) return undefined;
    const nowStr = formatArgentinaDateTime();
    const merged = { ...data.activities[idx], ...updates };
    if (updates.proposalStatus === 'cambios_solicitados') {
      merged.changesRequestedAt = nowStr;
    }
    data.activities[idx] = merged;
    saveDb(data);
    return data.activities[idx];
  },

  deleteActivity(id: number): boolean {
    const data = ensureDbFile();
    data.activities = data.activities.filter(a => a.id !== id);
    if (data.chats[String(id)]) {
      delete data.chats[String(id)];
    }
    saveDb(data);
    return true;
  },

  enrollActivity(id: number, username: string, apodo?: string): Activity | undefined {
    const data = ensureDbFile();
    const act = data.activities.find(a => a.id === id);
    if (!act) return undefined;

    const matchedUser = Object.values(data.users).find(
      u => u.usuario.toLowerCase() === username.toLowerCase() || (apodo && u.apodo.toLowerCase() === apodo.toLowerCase())
    );
    const userApodo = apodo || (matchedUser ? matchedUser.apodo : username);

    if (!act.enrolledUsernames) act.enrolledUsernames = [];
    if (!act.enrolledUsernames.includes(username)) {
      act.enrolledUsernames.push(username);
      act.enrolledCount = act.enrolledUsernames.length;
    }

    // Sync into the activity's group chat
    const chatKey = Object.keys(data.chats).find(
      k => data.chats[k].activityId === id || Number(k) === id
    );
    if (chatKey) {
      const chat = data.chats[chatKey];
      if (!chat.participants) chat.participants = [];
      if (!chat.participants.includes(userApodo) && !chat.participants.includes(username)) {
        chat.participants.push(userApodo);
      }
    }

    saveDb(data);
    return act;
  },

  unenrollActivity(id: number, username: string, apodo?: string): Activity | undefined {
    const data = ensureDbFile();
    const act = data.activities.find(a => a.id === id);
    if (!act) return undefined;

    const matchedUser = Object.values(data.users).find(
      u => u.usuario.toLowerCase() === username.toLowerCase() || (apodo && u.apodo.toLowerCase() === apodo.toLowerCase())
    );
    const userApodo = apodo || (matchedUser ? matchedUser.apodo : username);

    if (act.enrolledUsernames) {
      act.enrolledUsernames = act.enrolledUsernames.filter(
        u => u.toLowerCase() !== username.toLowerCase() && (!apodo || u.toLowerCase() !== apodo.toLowerCase())
      );
      act.enrolledCount = act.enrolledUsernames.length;
    }

    // Remove from chat
    const chatKey = Object.keys(data.chats).find(
      k => data.chats[k].activityId === id || Number(k) === id
    );
    if (chatKey) {
      const chat = data.chats[chatKey];
      if (chat.participants) {
        chat.participants = chat.participants.filter(
          p => p.toLowerCase() !== userApodo.toLowerCase() && p.toLowerCase() !== username.toLowerCase()
        );
      }
    }

    saveDb(data);
    return act;
  },

  resubmitActivityProposal(id: number, updates: Partial<Activity> & { userFeedbackNote?: string }): Activity | undefined {
    const data = ensureDbFile();
    const act = data.activities.find(a => a.id === id);
    if (!act) return undefined;

    const nowStr = formatArgentinaDateTime();

    Object.assign(act, updates);
    act.proposalStatus = 'pendiente';
    act.isApproved = false;
    act.changesSubmittedAt = nowStr;
    if (updates.userFeedbackNote) {
      act.userFeedbackNote = updates.userFeedbackNote;
    }

    if (!act.versions || act.versions.length === 0) {
      act.versions = [
        {
          version: 1,
          date: act.proposedAt || nowStr,
          title: act.title,
          schedule: act.schedule,
          location: act.location,
          lat: act.lat,
          lng: act.lng,
          capacity: act.capacity,
          description: act.description,
          shortDescription: act.shortDescription,
          image: act.image,
          note: 'Versión original de la propuesta'
        }
      ];
    }

    const nextVerNum = act.versions.length + 1;
    act.versions.push({
      version: nextVerNum,
      date: nowStr,
      title: act.title,
      schedule: act.schedule,
      location: act.location,
      lat: act.lat,
      lng: act.lng,
      capacity: act.capacity,
      description: act.description,
      shortDescription: act.shortDescription,
      image: act.image,
      note: updates.userFeedbackNote || 'Modificaciones enviadas por el organizador'
    });

    db.addNotification(
      'administrador',
      `El vecino ${act.organizer} reenvió con modificaciones la actividad "${act.title}".`
    );

    saveDb(data);
    return act;
  },

  vetoUserFromActivity(id: number, username: string): Activity | undefined {
    const data = ensureDbFile();
    const act = data.activities.find(a => a.id === id);
    if (!act) return undefined;

    const lowerTarget = username.trim().toLowerCase();
    const matchedUser = Object.values(data.users).find(
      u => u.usuario.toLowerCase() === lowerTarget || u.apodo.toLowerCase() === lowerTarget
    );
    const namesToVeto = [lowerTarget];
    if (matchedUser) {
      namesToVeto.push(matchedUser.usuario.toLowerCase());
      namesToVeto.push(matchedUser.apodo.toLowerCase());
    }

    if (!act.vettedUsers) act.vettedUsers = [];
    namesToVeto.forEach(n => {
      if (!act.vettedUsers.includes(n)) act.vettedUsers.push(n);
    });

    if (act.enrolledUsernames) {
      act.enrolledUsernames = act.enrolledUsernames.filter(
        u => !namesToVeto.includes(u.trim().toLowerCase())
      );
      act.enrolledCount = act.enrolledUsernames.length;
    }

    const chatKey = Object.keys(data.chats).find(k => data.chats[k].activityId === id);
    if (chatKey && data.chats[chatKey].participants) {
      data.chats[chatKey].participants = data.chats[chatKey].participants!.filter(
        p => !namesToVeto.includes(p.trim().toLowerCase())
      );
    }

    saveDb(data);
    return act;
  },

  getChats(): Record<string, Chat> {
    const data = ensureDbFile();
    return data.chats;
  },

  getChat(id: string | number): Chat | undefined {
    const data = ensureDbFile();
    return data.chats[String(id)];
  },

  addChatMessage(chatId: string | number, msg: ChatMessage): ChatMessage | undefined {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return undefined;

    const messageWithId = {
      ...msg,
      id: msg.id || `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`
    };
    chat.messages.push(messageWithId);
    saveDb(data);
    return messageWithId;
  },

  deleteChatMessage(chatId: string | number, messageId: string, deletedByAdmin = true, reasonText?: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;

    const msg = chat.messages.find(m => m.id === messageId);
    if (!msg) return false;

    msg.text = reasonText || (deletedByAdmin ? 'Este mensaje fue retirado por el administrador del grupo' : 'Mensaje eliminado');
    msg.isDeleted = true;
    msg.deletedByAdmin = deletedByAdmin;

    saveDb(data);
    return true;
  },

  addChatParticipant(chatId: string | number, participantName: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;
    if (!chat.participants) chat.participants = [];

    const target = participantName.trim();
    if (!chat.participants.some(p => p.toLowerCase() === target.toLowerCase())) {
      chat.participants.push(target);
      chat.messages.push({
        id: `sys_${Date.now()}`,
        senderId: 'sistema',
        sender: 'Sistema CLUB65',
        avatar: '👋',
        role: 'sistema',
        text: `${target} fue agregado al grupo por el administrador.`,
        time: 'Ahora'
      });
      saveDb(data);
    }
    return true;
  },

  removeChatParticipant(chatId: string | number, participantName: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat || !chat.participants) return false;

    const target = participantName.trim().toLowerCase();
    chat.participants = chat.participants.filter(p => p.trim().toLowerCase() !== target);
    if (chat.adminUsernames) {
      chat.adminUsernames = chat.adminUsernames.filter(a => a.trim().toLowerCase() !== target);
    }

    // Add system notification message
    chat.messages.push({
      id: `sys_${Date.now()}`,
      senderId: 'sistema',
      sender: 'Sistema CLUB65',
      avatar: '🛡️',
      role: 'sistema',
      text: `${participantName} fue retirado del grupo por el administrador.`,
      time: 'Ahora'
    });

    saveDb(data);
    return true;
  },

  updateChatPhoto(chatId: string | number, avatarUrl: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;

    chat.avatar = avatarUrl;
    chat.image = avatarUrl;
    saveDb(data);
    return true;
  },

  makeChatAdmin(chatId: string | number, participantName: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;

    if (!chat.adminUsernames) chat.adminUsernames = [];
    if (!chat.adminUsernames.includes(participantName)) {
      chat.adminUsernames.push(participantName);
      chat.messages.push({
        id: `sys_${Date.now()}`,
        senderId: 'sistema',
        sender: 'Sistema CLUB65',
        avatar: '⭐',
        role: 'sistema',
        text: `¡${participantName} fue designado administrador del grupo!`,
        time: 'Ahora'
      });
      saveDb(data);
    }
    return true;
  },

  createChat(chat: Omit<Chat, 'id'>): Chat {
    const data = ensureDbFile();
    const id = Date.now();
    const newChat: Chat = { ...chat, id };
    data.chats[String(id)] = newChat;
    saveDb(data);
    return newChat;
  },

  deleteChat(id: string | number): boolean {
    const data = ensureDbFile();
    delete data.chats[String(id)];
    saveDb(data);
    return true;
  },

  getReviews(): Review[] {
    const data = ensureDbFile();
    return data.reviews;
  },

  createReview(rev: Omit<Review, 'id'>): Review {
    const data = ensureDbFile();
    const id = Date.now();
    const newRev: Review = { ...rev, id };
    data.reviews.unshift(newRev);
    saveDb(data);
    return newRev;
  },

  updateReview(id: number, updates: Partial<Review>): Review | undefined {
    const data = ensureDbFile();
    const idx = data.reviews.findIndex(r => r.id === id);
    if (idx === -1) return undefined;
    data.reviews[idx] = { ...data.reviews[idx], ...updates };
    saveDb(data);
    return data.reviews[idx];
  },

  deleteReview(id: number): boolean {
    const data = ensureDbFile();
    data.reviews = data.reviews.filter(r => r.id !== id);
    saveDb(data);
    return true;
  },

  getContacts(): Contact[] {
    const data = ensureDbFile();
    return data.contacts;
  },

  addContact(contact: Omit<Contact, 'id'>): Contact {
    const data = ensureDbFile();
    const id = `contact_${Date.now()}`;
    const newContact: Contact = { ...contact, id };
    data.contacts.push(newContact);
    saveDb(data);
    return newContact;
  },

  deleteContact(id: string): boolean {
    const data = ensureDbFile();
    data.contacts = data.contacts.filter(c => c.id !== id);
    saveDb(data);
    return true;
  },

  leaveChat(chatId: string | number, usernameOrId: string, apodo?: string, userId?: string): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;

    const lowerTarget = usernameOrId.trim().toLowerCase();
    const lowerApodo = (apodo || '').trim().toLowerCase();
    const lowerId = (userId || '').trim().toLowerCase();

    if (chat.participants) {
      chat.participants = chat.participants.filter(p => {
        const lp = p.trim().toLowerCase();
        return lp !== lowerTarget && lp !== lowerApodo && lp !== lowerId;
      });
    }

    const isCreator = (
      chat.creatorId === userId ||
      chat.creatorId === usernameOrId ||
      chat.creatorName === apodo ||
      chat.creatorName === usernameOrId ||
      chat.organizerId === userId ||
      chat.organizerId === usernameOrId
    );

    if (isCreator) {
      if (chat.participants && chat.participants.length > 0) {
        chat.creatorName = chat.participants[0];
        const nextUser = Object.values(data.users).find(
          u => u.apodo.toLowerCase() === chat.participants![0].toLowerCase() || u.usuario.toLowerCase() === chat.participants![0].toLowerCase()
        );
        chat.creatorId = nextUser ? nextUser.id : undefined;
        chat.organizerId = nextUser ? nextUser.id : undefined;
      } else {
        chat.creatorId = undefined;
        chat.creatorName = undefined;
        chat.organizerId = undefined;
      }
    }

    if (!chat.participants || chat.participants.length === 0) {
      delete data.chats[String(chatId)];
    }
    saveDb(data);
    return true;
  },

  // CHAT PINNING
  pinChatMessage(chatId: string | number, messageId: string | null): boolean {
    const data = ensureDbFile();
    const chat = data.chats[String(chatId)];
    if (!chat) return false;

    chat.pinnedMessageId = messageId || undefined;
    if (chat.messages) {
      chat.messages.forEach(m => {
        m.isPinned = messageId ? m.id === messageId : false;
      });
    }
    saveDb(data);
    return true;
  },

  // SECURITY REPORTS
  getSecurityReports(): SecurityReport[] {
    const data = ensureDbFile();
    return data.reports || [];
  },

  createSecurityReport(rep: Omit<SecurityReport, 'id' | 'timestamp' | 'status'>): SecurityReport {
    const data = ensureDbFile();
    const id = `rep_${Date.now()}`;
    const newReport: SecurityReport = {
      ...rep,
      id,
      timestamp: 'Recién',
      status: 'pendiente'
    };
    if (!data.reports) data.reports = [];
    data.reports.unshift(newReport);
    saveDb(data);
    return newReport;
  },

  resolveSecurityReport(id: string, status: 'resuelto' | 'desestimado', resolutionNote?: string, action?: string, sanctionReason?: string, adminComment?: string, adminUsername = 'administrador'): SecurityReport | undefined {
    const data = ensureDbFile();
    if (!data.reports) return undefined;
    const rep = data.reports.find(r => r.id === id);
    if (!rep) return undefined;

    rep.status = status;
    rep.resolutionNote = resolutionNote || (status === 'resuelto' ? 'Reporte procesado con éxito.' : 'Reporte desestimado.');
    rep.resolutionAction = action;
    rep.resolutionDecision = status === 'resuelto' ? (action || 'Sancionado') : 'Desestimado';
    rep.sanctionReason = sanctionReason || rep.reason;
    rep.adminComment = adminComment || '';
    rep.resolvedBy = adminUsername;
    rep.resolvedAt = formatArgentinaDateTime();

    // Send detailed notification to the reporter user explaining the decision
    if (rep.reporterUser || rep.reporterUsername) {
      const recipient = rep.reporterUser || rep.reporterUsername!;
      const notifMessage = status === 'resuelto'
        ? `Resolución sobre tu reporte ("${rep.reason}"): El Administrador (${adminUsername}) aplicó medidas operativas (${action === 'ban_user' ? 'Usuario sancionado' : (action === 'delete_content' ? 'Contenido retirado' : 'Intervenido')}). ${adminComment ? `Nota: ${adminComment}. ` : ''}${rep.resolutionNote}`
        : `Tu reporte sobre "${rep.reason}" fue evaluado por el Administrador. Tras revisar el contexto, se desestimó al no evidenciar infracciones mayores a las normas comunitarias.`;
      db.addNotification(recipient, notifMessage);

      // Dispatch simulated email to the reporter's email address
      const reporterUserObj = Object.values(data.users).find(
        u => u.apodo.toLowerCase() === recipient.toLowerCase() || u.usuario.toLowerCase() === recipient.toLowerCase()
      );
      const emailRecipient = rep.reporterEmail || reporterUserObj?.email || `${(rep.reporterUsername || reporterUserObj?.usuario || 'vecino').toLowerCase()}@correo.club65.ar`;
      rep.reporterEmail = emailRecipient;

      const emailSubject = `CLUB65 - Resolución sobre tu reporte de seguridad ("${rep.reason}")`;
      const emailBody = status === 'resuelto'
        ? `Hola ${recipient}:\n\nTe informamos que el Administrador Oficial (${adminUsername}) ha evaluado tu reporte por "${rep.reason}".\n\nMedida tomada: ${action === 'ban_user' ? 'Sanción preventiva aplicada al usuario denunciado' : (action === 'delete_content' ? 'El contenido denunciado fue retirado de la plataforma' : 'Medidas de moderación y advertencia comunitaria')}.\nDetalle: ${rep.resolutionNote}\n${adminComment ? `Comentario del administrador: ${adminComment}\n` : ''}\nAgradecemos tu colaboración para mantener a CLUB65 como un espacio seguro para todos los adultos mayores.\n\nAtentamente,\nEquipo de Administración y Seguridad - CLUB65`
        : `Hola ${recipient}:\n\nTe informamos que el Administrador Oficial (${adminUsername}) ha evaluado tu reporte por "${rep.reason}".\n\nTras una revisión del contexto en la conversación, se determinó desestimar el caso al no configurarse una falta a las normas comunitarias.\n${adminComment ? `Observaciones: ${adminComment}\n` : ''}\nAtentamente,\nEquipo de Administración y Seguridad - CLUB65`;

      db.addSimulatedEmail({
        to: emailRecipient,
        subject: emailSubject,
        body: emailBody
      });
    }

    // Execute immediate action if requested
    if (action === 'delete_content' || action === 'ban_and_delete' || action === 'eliminar') {
      if (rep.type === 'chat_message' && rep.chatId && rep.messageId) {
        db.deleteChatMessage(rep.chatId, rep.messageId, true, 'Este mensaje fue retirado por no cumplir con las condiciones de uso de CLUB65');
      } else if ((rep.type === 'review_text' || rep.type === 'review_media') && rep.reviewId) {
        db.deleteReview(rep.reviewId);
      }
    }
    
    if ((action === 'ban_user' || action === 'ban_and_delete') && rep.reportedUser) {
      db.addSanction({
        username: rep.reportedUser,
        reason: sanctionReason || rep.reason,
        comment: adminComment || `Sanción derivada del reporte ${rep.id}`,
        adminUsername,
        type: 'temporal_30',
        reportId: rep.id
      });
    }

    saveDb(data);
    return rep;
  },

  // INSTITUTION VALIDATION
  approveInstitution(userId: string): User | undefined {
    const data = ensureDbFile();
    const user = data.users[userId];
    if (!user) return undefined;

    user.isVerified = true;
    user.estadoAlta = 'aprobada';
    db.addNotification(user.apodo, '¡Felicitaciones! Tu institución ha sido dada de alta y verificada oficialmente con tilde azul en CLUB65.');
    saveDb(data);
    return user;
  },

  rejectInstitution(userId: string, reason?: string): User | undefined {
    const data = ensureDbFile();
    const user = data.users[userId];
    if (!user) return undefined;

    user.isVerified = false;
    user.estadoAlta = 'rechazada';
    db.addNotification(user.apodo, `Tu solicitud de alta institucional fue rechazada. Motivo: ${reason || 'Documentación incompleta o no verificada.'}`);
    saveDb(data);
    return user;
  },

  verifyInstitution(userId: string, isVerified: boolean): User | undefined {
    const data = ensureDbFile();
    const user = data.users[userId];
    if (!user) return undefined;

    user.isVerified = isVerified;
    user.estadoAlta = isVerified ? 'aprobada' : 'rechazada';
    saveDb(data);
    return user;
  },

  // FORCE CANCEL / REMOVE ACTIVITY FROM CARTELERA
  forceCancelActivity(id: number, reason?: string, adminUsername = 'administrador'): Activity | undefined {
    const data = ensureDbFile();
    const act = data.activities.find(a => a.id === id);
    if (!act) return undefined;

    const fechaBaja = formatArgentinaDateTime();
    const motivoBaja = reason || 'Baja forzada por no cumplir con las normas comunitarias de CLUB65';

    act.isApproved = false;
    act.proposalStatus = 'baja_forzada';
    act.baja_forzada = true;
    act.bajaDate = fechaBaja;
    act.bajaReason = motivoBaja;
    act.bajaAdmin = adminUsername;
    act.proposalNote = motivoBaja;

    if (!data.bajas) data.bajas = [];
    // Evitar duplicados si ya estaba en el registro
    data.bajas = data.bajas.filter(b => b.activityId !== act.id);
    data.bajas.unshift({
      id: `baja_${Date.now()}`,
      activityId: act.id,
      title: act.title,
      organizer: act.organizer,
      date: fechaBaja,
      reason: motivoBaja,
      adminUsername
    });

    db.addNotification(act.organizer, `Tu actividad "${act.title}" ha sido dada de baja de la Cartelera pública por el Administrador (@${adminUsername}). Motivo: ${motivoBaja}`);

    if (act.enrolledUsernames) {
      act.enrolledUsernames.forEach(username => {
        db.addNotification(username, `Aviso: La actividad "${act.title}" a la que asistías fue dada de baja de la Cartelera por la administración.`);
      });
    }

    saveDb(data);
    return act;
  },

  getBajas(): BajaRecord[] {
    const data = ensureDbFile();
    return data.bajas || [];
  },

  // MAKE USER ADMINISTRATOR
  makeUserAdmin(identifier: string): User | undefined {
    const data = ensureDbFile();
    const lower = identifier.trim().toLowerCase();
    const user = Object.values(data.users).find(
      u => u.id.toLowerCase() === lower || u.usuario.toLowerCase() === lower || u.apodo.toLowerCase() === lower
    );
    if (!user) return undefined;

    user.tipo = 'moderador';
    user.bio = `Administrador Oficial de CLUB65. Equipo de gestión y seguridad comunitaria.`;
    db.addNotification(user.apodo, '¡Has sido designado como Administrador Oficial de CLUB65 con acceso total al Panel de Control!');
    saveDb(data);
    return user;
  },

  // SANCTIONS MANAGEMENT
  getSanctions(): SanctionRecord[] {
    const data = ensureDbFile();
    return data.sanctions || [];
  },

  addSanction(record: Omit<SanctionRecord, 'id' | 'date'> & { id?: string; date?: string }): SanctionRecord {
    const data = ensureDbFile();
    if (!data.sanctions) data.sanctions = [];
    if (!data.bannedUsers) data.bannedUsers = [];

    const dateStr = record.date || formatArgentinaDateOnly();

    let liftDate = record.liftDate;
    if (!liftDate) {
      if (record.type === 'temporal_7') {
        const d = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
        liftDate = formatArgentinaDateOnly(d);
      } else if (record.type === 'temporal_30') {
        const d = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        liftDate = formatArgentinaDateOnly(d);
      } else {
        liftDate = 'Sin fecha (Permanente)';
      }
    }

    const newSanction: SanctionRecord = {
      id: record.id || `sanc_${Date.now()}`,
      username: record.username,
      reason: record.reason,
      comment: record.comment || '',
      adminUsername: record.adminUsername || 'administrador',
      date: dateStr,
      type: record.type,
      liftDate,
      reportId: record.reportId
    };

    data.sanctions = data.sanctions.filter(s => s.username.toLowerCase() !== record.username.toLowerCase());
    data.sanctions.unshift(newSanction);

    const lowerTarget = record.username.trim().toLowerCase();
    if (!data.bannedUsers.includes(lowerTarget)) {
      data.bannedUsers.push(lowerTarget);
    }

    const user = Object.values(data.users).find(
      u => u.usuario.toLowerCase() === lowerTarget || u.apodo.toLowerCase() === lowerTarget || u.id.toLowerCase() === lowerTarget
    );
    if (user) {
      user.isSuspended = true;
      db.addNotification(user.apodo, `Has recibido una sanción (${record.reason}): ${record.comment || 'Violación de normas comunitarias'}.`);
    }

    saveDb(data);
    return newSanction;
  },

  removeSanction(username: string): void {
    const data = ensureDbFile();
    const lower = username.trim().toLowerCase();
    if (data.sanctions) {
      data.sanctions = data.sanctions.filter(s => s.username.toLowerCase() !== lower);
    }
    if (data.bannedUsers) {
      data.bannedUsers = data.bannedUsers.filter(b => b.toLowerCase() !== lower);
    }
    const user = Object.values(data.users).find(
      u => u.usuario.toLowerCase() === lower || u.apodo.toLowerCase() === lower || u.id.toLowerCase() === lower
    );
    if (user) {
      user.isSuspended = false;
      db.addNotification(user.apodo, 'Tu sanción ha sido levantada por un Administrador.');
    }
    saveDb(data);
  },

  // GLOBAL BANS & SUSPENSIONS
  banUserGlobal(identifier: string): void {
    db.addSanction({
      username: identifier,
      reason: 'Comportamientos ilegales',
      comment: 'Veto preventivo aplicado por la administración.',
      adminUsername: 'administrador',
      type: 'permanente'
    });
  },

  unbanUserGlobal(identifier: string): void {
    db.removeSanction(identifier);
  },

  isUserBanned(identifier: string): boolean {
    const data = ensureDbFile();
    return data.bannedUsers ? data.bannedUsers.includes(identifier.trim().toLowerCase()) : false;
  },

  // SIMULATED EMAILS
  getSimulatedEmails(): SimulatedEmail[] {
    const data = ensureDbFile();
    return data.simulatedEmails || [];
  },

  addSimulatedEmail(email: Omit<SimulatedEmail, 'id' | 'date'>): SimulatedEmail {
    const data = ensureDbFile();
    if (!data.simulatedEmails) data.simulatedEmails = [];
    const now = new Date();
    const dateStr = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}, ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} hs`;
    const newEmail: SimulatedEmail = {
      ...email,
      id: `email_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      date: dateStr
    };
    data.simulatedEmails.unshift(newEmail);
    saveDb(data);
    return newEmail;
  }
};
