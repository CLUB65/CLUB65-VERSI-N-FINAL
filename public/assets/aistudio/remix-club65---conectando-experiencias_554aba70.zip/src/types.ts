export interface UserNotification {
  id: string;
  text: string;
  time: string;
  read: boolean;
}

export interface SanctionRecord {
  id: string;
  username: string;
  reason: string; // One of the 9 motives
  comment?: string;
  adminUsername: string;
  date: string;
  type: 'temporal_7' | 'temporal_30' | 'permanente';
  liftDate?: string;
  reportId?: string;
}

export interface User {
  id: string;
  usuario: string;
  clave: string;
  apodo: string;
  avatar: string;
  bio: string;
  textSize: 'normal' | 'grande' | 'gigante';
  contrast: boolean;
  tipo: 'personal' | 'institucional' | 'moderador';
  localidad?: string;
  email?: string;
  isVerified?: boolean;
  cuit?: string;
  legalRepresentative?: string;
  responsableLegal?: string;
  documentoAdjunto?: string;
  documentoLegal?: string;
  documentoDescargaUrl?: string;
  contactoInstitucional?: string;
  telefonoInstitucional?: string;
  entidadTipo?: string;
  estadoAlta?: 'pendiente' | 'aprobada' | 'rechazada';
  isSuspended?: boolean;
  blockedUsers?: string[];
  blockedByUsers?: string[];
  myBlockedUsers?: string[];
  notifications?: UserNotification[];
  createdAt?: string;
}

export interface ActivityVersion {
  version: number;
  date: string;
  title: string;
  schedule: string;
  location: string;
  lat?: number;
  lng?: number;
  capacity: number;
  description: string;
  shortDescription?: string;
  image?: string;
  note?: string;
}

export interface Activity {
  id: number;
  title: string;
  category: 'salud' | 'cultura' | 'social' | 'musica' | 'tecnologia' | 'memoria' | 'naturaleza' | string;
  schedule: string;
  location: string;
  lat: number;
  lng: number;
  organizer: string;
  organizerBio: string;
  organizerId: string;
  isInstitutional: boolean;
  isRecurrent: boolean;
  enrolled: boolean;
  capacity: number;
  enrolledCount: number;
  shortDescription?: string;
  description: string;
  image: string;
  isApproved: boolean;
  proposalStatus?: 'aprobada' | 'pendiente' | 'cambios_solicitados' | 'rechazada' | 'baja_forzada';
  baja_forzada?: boolean;
  bajaDate?: string;
  bajaReason?: string;
  bajaAdmin?: string;
  proposalNote?: string;
  userFeedbackNote?: string;
  proposedAt?: string;
  changesRequestedAt?: string;
  changesSubmittedAt?: string;
  versions?: ActivityVersion[];
  vettedUsers: string[];
  enrolledUsernames: string[];
}

export interface BajaRecord {
  id: string;
  activityId: number;
  title: string;
  organizer: string;
  date: string;
  reason: string;
  adminUsername: string;
}

export interface ChatMessage {
  id?: string;
  senderId: string;
  sender: string;
  avatar: string;
  role: string;
  text: string;
  time: string;
  isOrganizer?: boolean;
  isVerifiedInst?: boolean;
  isDeleted?: boolean;
  deletedByAdmin?: boolean;
  replyTo?: {
    id: string;
    sender: string;
    text: string;
  };
  isPinned?: boolean;
}

export interface Chat {
  id: number;
  title: string;
  subtitle: string;
  type: 'grupal' | 'privado';
  activityId?: number | null;
  organizerId?: string;
  creatorId?: string;
  creatorName?: string;
  adminUsernames?: string[];
  avatar?: string;
  image?: string;
  allowedRoles?: string[];
  participants?: string[];
  pinnedMessageId?: string;
  messages: ChatMessage[];
}

export interface Review {
  id: number;
  actividadId: number;
  actividad: string;
  autor: string;
  estrellas: number;
  fecha: string;
  texto: string;
  foto?: string | null;
  media?: string[];
}

export interface Contact {
  id: string;
  nombre: string;
  detalle: string;
  avatar: string;
  avatarClass: string;
  bio: string;
  foto?: string;
}

export interface SimulatedEmail {
  id: string;
  to: string;
  subject: string;
  body: string;
  date: string;
}

export interface SecurityReport {
  id: string;
  type: 'chat_message' | 'review_media' | 'review_text' | 'chat_general';
  chatId?: number;
  messageId?: string;
  messageText?: string;
  mediaUrl?: string;
  reviewId?: number;
  activityId?: number;
  reportedUser?: string;
  reporterUser: string;
  reporterUsername?: string;
  reporterEmail?: string;
  reason: string;
  comment?: string;
  timestamp: string;
  createdAt?: string;
  status: 'pendiente' | 'resuelto' | 'desestimado' | 'pending' | 'resolved';
  resolutionNote?: string;
  resolutionAction?: string;
  resolutionDecision?: string;
  sanctionReason?: string;
  adminComment?: string;
  resolvedBy?: string;
  resolvedAt?: string;
}
