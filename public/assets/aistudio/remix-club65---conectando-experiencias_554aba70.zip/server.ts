import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db } from './src/server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);

// Increased limits to smoothly handle user photo & short video uploads (<=45s)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Helper to extract session username or token from header
function getAuthUser(req: express.Request) {
  const userId = req.headers['x-user-id'] as string;
  if (!userId) return null;
  return db.getUser(userId) || null;
}

// ================= AUTH ROUTES =================
app.post('/api/auth/login', (req, res) => {
  const { usuario, clave } = req.body;
  if (!usuario || !clave) {
    return res.status(400).json({ error: 'Usuario o correo electrónico y clave requeridos.' });
  }

  const user = db.findUserByCredentials(usuario, clave);
  if (!user) {
    return res.status(401).json({ error: 'Datos incorrectos. Por favor verificá tu usuario o correo electrónico y contraseña.' });
  }

  if (db.isUserBanned(user.usuario) || db.isUserBanned(user.id)) {
    return res.status(403).json({ error: 'Este usuario ha sido suspendido de la plataforma.' });
  }

  const allUsers = Object.values(db.getUsers());
  const myIdentifiers = [user.id.toLowerCase(), user.usuario.toLowerCase(), user.apodo.toLowerCase()];
  const whoBlockedMe = allUsers.filter(u => 
    u.blockedUsers && u.blockedUsers.some(b => myIdentifiers.includes(b.toLowerCase()))
  ).flatMap(u => [u.id, u.usuario, u.apodo]);

  const mutualBlocked = Array.from(new Set([
    ...(user.blockedUsers || []),
    ...whoBlockedMe
  ]));

  res.json({
    success: true,
    user: {
      ...user,
      blockedUsers: mutualBlocked,
      myBlockedUsers: user.blockedUsers || [],
      blockedByUsers: whoBlockedMe
    }
  });
});

app.get('/api/users', (_req, res) => {
  res.json(db.getUsers());
});

app.post('/api/auth/register', (req, res) => {
  const { usuario, clave, apodo, tipo, localidad, cuit, entidadTipo, contactoInstitucional, telefonoInstitucional, email } = req.body;
  if (!usuario || !clave || !apodo) {
    return res.status(400).json({ error: 'Faltan campos requeridos.' });
  }

  if (db.isUserBanned(usuario)) {
    return res.status(403).json({ error: 'No se puede registrar este usuario.' });
  }

  const existing = db.findUserByUsername(usuario);
  if (existing) {
    return res.status(409).json({ error: 'El nombre de usuario ya está registrado.' });
  }

  const isInst = tipo === 'institucional';
  const defaultAvatar = isInst
    ? 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=100&h=100&fit=crop'
    : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop';

  const telContact = telefonoInstitucional || contactoInstitucional || '';

  const newUser = db.createUser({
    usuario,
    clave,
    apodo,
    email: email || '',
    avatar: defaultAvatar,
    bio: isInst
      ? `Institución registrada (${entidadTipo || 'Comunitaria'}). Localidad: ${localidad || 'Tres de Febrero'}. CUIT: ${cuit || 'S/D'}. Contacto: ${telContact || 'S/D'}`
      : `Vecino/a de ${localidad || 'Tres de Febrero'}. Miembro de CLUB65.`,
    textSize: 'normal',
    contrast: false,
    tipo: isInst ? 'institucional' : 'personal',
    entidadTipo: entidadTipo || (isInst ? 'Comunitaria' : undefined),
    localidad: localidad || 'Tres de Febrero',
    isVerified: false,
    estadoAlta: isInst ? 'pendiente' : 'aprobada',
    cuit: cuit || '',
    legalRepresentative: isInst ? apodo : '',
    contactoInstitucional: telContact,
    telefonoInstitucional: telContact
  });

  if (isInst) {
    const instEmail = email || `${usuario.toLowerCase()}@institucion.club65.ar`;
    db.addSimulatedEmail({
      to: instEmail,
      subject: 'CLUB65 - Solicitud de Alta Institucional Recibida (Procedimiento y Plazos)',
      body: `Estimados representantes de "${apodo}":\n\nHemos recibido correctamente su registro institucional en CLUB65.\n\nProcedimiento de Validación Oficial:\n1. Revisión de Documentación: El Administrador Oficial revisará la documentación legal y CUIT (${cuit || 'S/D'}) en un plazo de 24 a 48 hs hábiles.\n2. Verificación Telefónica: Se podrá coordinar una llamada de verificación al teléfono informado (${telContact || 'S/D'}).\n3. Estado de la cuenta: Las cuentas institucionales no cuentan con perfil público activo ni pueden acceder a la plataforma hasta tanto el Administrador Oficial otorgue el alta definitiva en el Panel de Validación.\n\nAtentamente,\nEquipo de Administración y Seguridad de CLUB65`
    });
  }

  res.status(201).json({
    success: true,
    user: newUser,
    isPendingValidation: isInst,
    message: isInst
      ? 'La cuenta ha sido registrada y se encuentra a la espera de ser dada de alta por el Administrador Oficial. Se envió un correo electrónico con los detalles del procedimiento.'
      : undefined
  });
});

app.get('/api/users/profile/:username', (req, res) => {
  const profile = db.getPublicUser(req.params.username);
  if (!profile) return res.status(404).json({ error: 'Usuario no encontrado.' });
  res.json(profile);
});

app.get('/api/auth/me', (req, res) => {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'No autenticado.' });
  }

  const allUsers = Object.values(db.getUsers());
  const myIdentifiers = [user.id.toLowerCase(), user.usuario.toLowerCase(), user.apodo.toLowerCase()];
  const whoBlockedMe = allUsers.filter(u => 
    u.blockedUsers && u.blockedUsers.some(b => myIdentifiers.includes(b.toLowerCase()))
  ).flatMap(u => [u.id, u.usuario, u.apodo]);

  const mutualBlocked = Array.from(new Set([
    ...(user.blockedUsers || []),
    ...whoBlockedMe
  ]));

  res.json({
    user: {
      ...user,
      blockedUsers: mutualBlocked,
      myBlockedUsers: user.blockedUsers || [],
      blockedByUsers: whoBlockedMe
    }
  });
});

app.put('/api/auth/profile', (req, res) => {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'No autenticado.' });
  }

  const { apodo, bio, avatar, textSize, contrast } = req.body;
  const updated = db.updateUser(user.id, {
    ...(apodo ? { apodo } : {}),
    ...(bio !== undefined ? { bio } : {}),
    ...(avatar ? { avatar } : {}),
    ...(textSize ? { textSize } : {}),
    ...(contrast !== undefined ? { contrast } : {})
  });

  res.json({ success: true, user: updated });
});

// ================= BLOCK / UNBLOCK ROUTES =================
app.post('/api/users/block', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });
  const { targetUsername } = req.body;
  if (!targetUsername) return res.status(400).json({ error: 'Usuario a bloquear requerido.' });

  db.blockUser(user.id, targetUsername);
  res.json({ success: true, message: `Usuario ${targetUsername} bloqueado.` });
});

app.post('/api/users/unblock', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });
  const { targetUsername } = req.body;
  if (!targetUsername) return res.status(400).json({ error: 'Usuario a desbloquear requerido.' });

  db.unblockUser(user.id, targetUsername);
  res.json({ success: true, message: `Usuario ${targetUsername} desbloqueado.` });
});

// ================= ACTIVITIES ROUTES =================
app.get('/api/activities', (_req, res) => {
  const activities = db.getActivities();
  res.json(activities);
});

app.post('/api/activities', (req, res) => {
  const user = getAuthUser(req);
  const { title, category, schedule, location, lat, lng, capacity, description, shortDescription, avance, image, isInstitutional, isRecurrent } = req.body;

  if (!title || !location) {
    return res.status(400).json({ error: 'Título y ubicación requeridos.' });
  }

  // Personal activities MUST require moderation approval! Only verified institutions or admins auto-approve.
  const isApproved = (user?.tipo === 'institucional' || user?.tipo === 'moderador') && !!isInstitutional;
  const organizer = user ? user.apodo : 'Vecino de CLUB65';
  const organizerId = user ? user.id : 'personal';
  const organizerBio = user ? user.bio : '';

  const newActivity = db.createActivity({
    title,
    category: category || 'salud',
    schedule: schedule || 'A coordinar',
    location,
    lat: typeof lat === 'number' && !isNaN(lat) ? lat : -34.6068,
    lng: typeof lng === 'number' && !isNaN(lng) ? lng : -58.5647,
    organizer,
    organizerBio,
    organizerId,
    isInstitutional: !!isInstitutional,
    isRecurrent: !!isRecurrent,
    enrolled: false,
    capacity: capacity || 20,
    enrolledCount: 0,
    shortDescription: shortDescription || avance || '',
    description: description || 'Actividad barrial en Tres de Febrero.',
    image: image || 'https://images.unsplash.com/photo-1516307365426-bea591f05011?w=800&h=500&fit=crop',
    isApproved,
    proposalStatus: isApproved ? 'aprobada' : 'pendiente',
    vettedUsers: [],
    enrolledUsernames: []
  });

  // If auto-approved, initialize chat
  if (isApproved) {
    db.createChat({
      title: newActivity.title,
      subtitle: `Encuentro coordinado por ${organizer}`,
      type: 'grupal',
      activityId: newActivity.id,
      organizerId: newActivity.organizerId,
      adminUsernames: [organizer],
      allowedRoles: ['personal', 'institucional'],
      participants: [organizer],
      messages: [
        {
          id: `m_init_${Date.now()}`,
          senderId: 'sistema',
          sender: 'Sistema CLUB65',
          avatar: 'S',
          role: 'institucional',
          text: `Bienvenidos al canal de ${newActivity.title}.`,
          time: 'Ahora'
        }
      ]
    });
  }

  res.status(201).json(newActivity);
});

app.post('/api/activities/:id/enroll', (req, res) => {
  const id = Number(req.params.id);
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });

  const act = db.getActivityById(id);
  if (!act) return res.status(404).json({ error: 'Actividad no encontrada.' });

  // Check if organizer has blocked this user
  if (db.isUserBlocked(act.organizer, user.apodo) || db.isUserBlocked(act.organizerId, user.id)) {
    return res.status(403).json({ error: 'Inscripción no disponible.' });
  }

  const updated = db.enrollActivity(id, user.usuario, user.apodo);

  // Add user to the chat for this activity
  const chatKey = Object.keys(db.getChats()).find(k => db.getChat(k)?.activityId === id || Number(k) === id);
  if (chatKey) {
    const chat = db.getChat(chatKey);
    if (chat && !chat.participants?.includes(user.usuario) && !chat.participants?.includes(user.apodo)) {
      chat.participants = [...(chat.participants || []), user.apodo];
      db.addChatMessage(chatKey, {
        senderId: 'sistema',
        sender: 'Sistema CLUB65',
        avatar: 'S',
        role: 'sistema',
        text: `¡${user.apodo} se unió a la actividad!`,
        time: 'Recién'
      });
    }
  }

  res.json({ success: true, activity: updated });
});

app.post('/api/activities/:id/unenroll', (req, res) => {
  const id = Number(req.params.id);
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });

  const updated = db.unenrollActivity(id, user.usuario, user.apodo);
  res.json({ success: true, activity: updated });
});

app.post('/api/activities/:id/resubmit', (req, res) => {
  const id = Number(req.params.id);
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });

  const { title, schedule, location, lat, lng, capacity, description, shortDescription, image, userFeedbackNote } = req.body;
  const updated = db.resubmitActivityProposal(id, {
    ...(title ? { title } : {}),
    ...(schedule ? { schedule } : {}),
    ...(location ? { location } : {}),
    ...(typeof lat === 'number' && !isNaN(lat) ? { lat } : {}),
    ...(typeof lng === 'number' && !isNaN(lng) ? { lng } : {}),
    ...(capacity !== undefined ? { capacity } : {}),
    ...(description ? { description } : {}),
    ...(shortDescription ? { shortDescription } : {}),
    ...(image ? { image } : {}),
    ...(userFeedbackNote ? { userFeedbackNote } : {})
  });

  if (!updated) return res.status(404).json({ error: 'Actividad no encontrada.' });
  res.json({ success: true, activity: updated });
});

app.post('/api/activities/:id/veto', (req, res) => {
  const id = Number(req.params.id);
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'Usuario a vetar requerido.' });

  const updated = db.vetoUserFromActivity(id, username);
  res.json({ success: true, activity: updated });
});

app.post('/api/activities/:id/moderate', (req, res) => {
  const id = Number(req.params.id);
  const { action, note } = req.body; // 'approve', 'reject', 'request_changes'

  if (action === 'approve') {
    const act = db.updateActivity(id, { isApproved: true, proposalStatus: 'aprobada', proposalNote: note });
    if (act) {
      db.createChat({
        title: act.title,
        subtitle: `Canal vecinal de ${act.title}`,
        type: 'grupal',
        activityId: act.id,
        organizerId: act.organizerId,
        adminUsernames: [act.organizer],
        allowedRoles: ['personal', 'institucional'],
        participants: [act.organizer],
        messages: [
          {
            id: `msg_app_${Date.now()}`,
            senderId: 'sistema',
            sender: 'Administración CLUB65',
            avatar: '🛡️',
            role: 'institucional',
            text: `¡La iniciativa "${act.title}" ha sido aprobada y publicada en la Cartelera!`,
            time: 'Ahora'
          }
        ]
      });
      db.addNotification(act.organizer, `¡Tu actividad "${act.title}" fue aprobada y publicada en la Cartelera!`);
    }
    return res.json({ success: true, activity: act });
  } else if (action === 'request_changes') {
    const act = db.updateActivity(id, { isApproved: false, proposalStatus: 'cambios_solicitados', proposalNote: note || 'Por favor revisá los detalles solicitados.' });
    if (act) {
      db.addNotification(act.organizer, `El moderador solicitó cambios en "${act.title}": ${note}`);
    }
    return res.json({ success: true, activity: act });
  } else {
    const act = db.updateActivity(id, { isApproved: false, proposalStatus: 'rechazada', proposalNote: note || 'No cumple con las normas comunitarias.' });
    if (act) {
      db.addNotification(act.organizer, `Tu propuesta "${act.title}" fue rechazada por no cumplir las normas comunitarias.`);
    }
    return res.json({ success: true, activity: act });
  }
});

app.post('/api/activities/:id/force-cancel', (req, res) => {
  const id = Number(req.params.id);
  const { reason } = req.body;
  const user = getAuthUser(req);

  if (user && user.tipo !== 'moderador') {
    return res.status(403).json({ error: 'Solo administradores pueden forzar la baja de actividades.' });
  }

  const act = db.forceCancelActivity(id, reason);
  if (!act) return res.status(404).json({ error: 'Actividad no encontrada.' });
  res.json({ success: true, activity: act });
});

app.delete('/api/activities/:id', (req, res) => {
  const id = Number(req.params.id);
  const deleted = db.deleteActivity(id);
  res.json({ success: deleted });
});

// ================= CHAT ROUTES =================
app.get('/api/chats', (req, res) => {
  const user = getAuthUser(req);
  const allChats = Object.values(db.getChats());

  if (!user || user.tipo === 'moderador') {
    return res.json(allChats);
  }

  // Filter based on user role and participation
  const userTokens = [user.usuario.toLowerCase(), user.apodo.toLowerCase(), user.id.toLowerCase()];
  const filtered = allChats.filter(c => {
    const isParticipant = c.participants?.some(p => userTokens.includes(p.toLowerCase()));

    // For custom group chats (without activityId), user MUST be in participants!
    if (c.type === 'grupal' && !c.activityId) {
      return isParticipant;
    }

    // For activity group chats
    if (c.activityId) {
      const act = db.getActivityById(c.activityId);
      const isOrganizer = act ? (act.organizerId === user.id || (user.tipo === 'personal' && act.organizerId === 'personal') || (user.tipo === 'institucional' && act.organizerId === 'institucional')) : false;
      const isEnrolled = act?.enrolledUsernames?.some(u => userTokens.includes(u.toLowerCase()));
      return isParticipant || isEnrolled || isOrganizer;
    }

    // For private chats
    if (c.type === 'privado') {
      return isParticipant || userTokens.includes(c.title.toLowerCase());
    }

    return isParticipant;
  });

  res.json(filtered);
});

app.get('/api/chats/:id/messages', (req, res) => {
  const chat = db.getChat(req.params.id);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });
  res.json(chat.messages);
});

app.post('/api/chats/:id/messages', (req, res) => {
  const user = getAuthUser(req);
  const { text, replyTo } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'El mensaje no puede estar vacío.' });
  }

  const now = new Date();
  const time = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} hs`;
  const sender = user ? user.apodo : 'Vecino';
  const senderId = user ? user.id : 'visitante';
  const role = user ? user.tipo : 'personal';
  const avatar = user ? (user.tipo === 'institucional' ? '3F' : user.apodo.charAt(0)) : '?';
  const chat = db.getChat(req.params.id);
  const isOrganizer = chat ? (chat.creatorId === user?.id || chat.organizerId === user?.id || Boolean(user?.apodo && chat.adminUsernames?.includes(user.apodo))) : false;

  const newMsg = db.addChatMessage(req.params.id, {
    senderId,
    sender,
    avatar,
    role,
    text: text.trim(),
    time,
    isOrganizer,
    isVerifiedInst: user?.tipo === 'institucional',
    replyTo: replyTo && replyTo.text ? {
      id: String(replyTo.id || ''),
      sender: String(replyTo.sender || ''),
      text: String(replyTo.text || '')
    } : undefined
  });

  if (!newMsg) return res.status(404).json({ error: 'Chat no encontrado.' });
  res.status(201).json(newMsg);
});

// PIN / UNPIN A CHAT MESSAGE (ADMIN ACTION)
app.post('/api/chats/:id/pin', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const { messageId } = req.body;

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'Solo los administradores del grupo pueden fijar mensajes.' });
  }

  const ok = db.pinChatMessage(chatId, messageId || null);
  res.json({ success: ok, chat: db.getChat(chatId) });
});

// DELETE A CHAT MESSAGE (ADMIN ACTION)
app.post('/api/chats/:id/messages/:msgId/delete', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const msgId = req.params.msgId;
  const { reasonText } = req.body || {};

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'No tenés permisos para retirar mensajes en este grupo.' });
  }

  const ok = db.deleteChatMessage(chatId, msgId, true, reasonText);
  res.json({ success: ok, message: reasonText || 'Este mensaje ha sido retirado por el administrador del grupo' });
});

// GROUP MODERATION: ADD PARTICIPANT
app.post('/api/chats/:id/participants/add', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const { participant } = req.body;
  if (!participant) return res.status(400).json({ error: 'Participante requerido.' });

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'Permisos insuficientes.' });
  }

  if (user && (db.isUserBlocked(user.apodo, participant) || db.isUserBlocked(user.usuario, participant))) {
    return res.status(403).json({ error: 'No podés agregar a este usuario debido a bloqueos activos.' });
  }

  const ok = db.addChatParticipant(chatId, participant);
  res.json({ success: ok, chat: db.getChat(chatId) });
});

// GROUP MODERATION: REMOVE PARTICIPANT
app.post('/api/chats/:id/participants/remove', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const { participant } = req.body;
  if (!participant) return res.status(400).json({ error: 'Participante requerido.' });

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'Permisos insuficientes.' });
  }

  const ok = db.removeChatParticipant(chatId, participant);
  res.json({ success: ok, chat: db.getChat(chatId) });
});

// GROUP MODERATION: CHANGE PHOTO
app.post('/api/chats/:id/photo', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const { photoUrl } = req.body;
  if (!photoUrl) return res.status(400).json({ error: 'URL de foto requerida.' });

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'Permisos insuficientes.' });
  }

  const ok = db.updateChatPhoto(chatId, photoUrl);
  res.json({ success: ok, chat: db.getChat(chatId) });
});

// GROUP MODERATION: MAKE ADMIN
app.post('/api/chats/:id/admins', (req, res) => {
  const user = getAuthUser(req);
  const chatId = req.params.id;
  const { participant } = req.body;
  if (!participant) return res.status(400).json({ error: 'Participante requerido.' });

  const chat = db.getChat(chatId);
  if (!chat) return res.status(404).json({ error: 'Chat no encontrado.' });

  const isAdmin = user && (
    user.tipo === 'moderador' ||
    chat.creatorId === user.id ||
    chat.organizerId === user.id ||
    chat.adminUsernames?.includes(user.apodo) ||
    chat.adminUsernames?.includes(user.usuario)
  );

  if (!isAdmin) {
    return res.status(403).json({ error: 'Permisos insuficientes.' });
  }

  const ok = db.makeChatAdmin(chatId, participant);
  res.json({ success: ok, chat: db.getChat(chatId) });
});

app.post('/api/chats', (req, res) => {
  const user = getAuthUser(req);
  const { title, subtitle, type, participants, avatar } = req.body;
  if (!title) return res.status(400).json({ error: 'Título requerido.' });

  // Validate that no participant has blocked the user or is blocked
  if (user && participants && Array.isArray(participants)) {
    for (const p of participants) {
      if (db.isUserBlocked(user.usuario, p) || db.isUserBlocked(user.apodo, p)) {
        return res.status(403).json({ error: `No podés agregar a ${p} al grupo debido a bloqueos activos.` });
      }
    }
  }

  const initialParticipants = Array.from(
    new Set([user ? user.apodo : 'Carola Vecina Activa', ...(participants || [])])
  );

  const creatorApodo = user ? user.apodo : 'Carola Vecina Activa';

  const newChat = db.createChat({
    title,
    subtitle: subtitle || (type === 'grupal' ? `${initialParticipants.length} participantes` : 'Chat directo'),
    type: type || 'grupal',
    organizerId: user ? user.id : 'personal',
    creatorId: user ? user.id : 'personal',
    creatorName: creatorApodo,
    adminUsernames: [creatorApodo],
    avatar: avatar || undefined,
    image: avatar || undefined,
    allowedRoles: [user ? user.tipo : 'personal'],
    participants: initialParticipants,
    messages: [
      {
        id: `msg_init_${Date.now()}`,
        senderId: 'sistema',
        sender: 'Sistema CLUB65',
        avatar: 'S',
        role: 'institucional',
        text: type === 'privado'
          ? `Se inició un chat privado con ${title}.`
          : `Se inició el grupo "${title}" con ${initialParticipants.join(', ')}.`,
        time: 'Ahora'
      }
    ]
  });

  res.status(201).json(newChat);
});

app.post('/api/chats/:id/leave', (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: 'No autenticado.' });
  const success = db.leaveChat(req.params.id, user.usuario, user.apodo, user.id);
  res.json({ success });
});

app.delete('/api/chats/:id', (req, res) => {
  db.deleteChat(req.params.id);
  res.json({ success: true });
});

// ================= REVIEWS ROUTES =================
app.get('/api/reviews', (_req, res) => {
  res.json(db.getReviews());
});

app.post('/api/reviews', (req, res) => {
  const user = getAuthUser(req);
  const { actividadId, actividad, estrellas, texto, foto, media } = req.body;
  if (!actividad || !texto) {
    return res.status(400).json({ error: 'Actividad y opinión requeridas.' });
  }

  const mediaArray: string[] = Array.isArray(media) ? media : (foto ? [foto] : []);

  const newReview = db.createReview({
    actividadId: actividadId || 1,
    actividad,
    autor: user ? user.apodo : 'Vecino de CLUB65',
    estrellas: estrellas || 5,
    fecha: 'Recién',
    texto,
    foto: mediaArray[0] || null,
    media: mediaArray
  });

  res.status(201).json(newReview);
});

app.put('/api/reviews/:id', (req, res) => {
  const id = Number(req.params.id);
  const updates = { ...req.body };
  if (Array.isArray(updates.media)) {
    updates.foto = updates.media[0] || null;
  }
  const updated = db.updateReview(id, updates);
  if (!updated) return res.status(404).json({ error: 'Reseña no encontrada.' });
  res.json(updated);
});

app.delete('/api/reviews/:id', (req, res) => {
  const id = Number(req.params.id);
  const ok = db.deleteReview(id);
  res.json({ success: ok });
});

// ================= CONTACTS ROUTES =================
app.get('/api/contacts', (_req, res) => {
  res.json(db.getContacts());
});

app.post('/api/contacts', (req, res) => {
  const { nombre, detalle, avatar, avatarClass, bio, foto } = req.body;
  if (!nombre) return res.status(400).json({ error: 'Nombre requerido.' });

  const newContact = db.addContact({
    nombre,
    detalle: detalle || 'Contacto de CLUB65',
    avatar: avatar || nombre.slice(0, 2).toUpperCase(),
    avatarClass: avatarClass || 'bg-club-teal',
    bio: bio || 'Miembro de la comunidad de CLUB65.',
    foto
  });

  res.status(201).json(newContact);
});

app.delete('/api/contacts/:id', (req, res) => {
  const success = db.deleteContact(req.params.id);
  res.json({ success });
});

// ================= SECURITY REPORTS ROUTES =================
app.get('/api/reports', (_req, res) => {
  res.json(db.getSecurityReports());
});

app.post('/api/reports', (req, res) => {
  const user = getAuthUser(req);
  const { type, chatId, messageId, messageText, mediaUrl, reviewId, activityId, reportedUser, reason, comment } = req.body;

  if (!reason) {
    return res.status(400).json({ error: 'Motivo de reporte requerido.' });
  }

  const reporterUser = user ? user.apodo : 'Vecino de CLUB65';

  const newReport = db.createSecurityReport({
    type: type || 'chat_message',
    chatId: chatId ? Number(chatId) : undefined,
    messageId,
    messageText,
    mediaUrl,
    reviewId: reviewId ? Number(reviewId) : undefined,
    activityId: activityId ? Number(activityId) : undefined,
    reportedUser: reportedUser || 'Usuario de CLUB65',
    reporterUser,
    reason,
    comment: comment || ''
  });

  res.status(201).json({
    success: true,
    report: newReport,
    notificationMessage: 'Su reporte ha sido recibido, Te comunicaremos si detectamos que se incumplió una regla, así como las medidas que tomaremos al respecto'
  });
});

app.post('/api/reports/:id/resolve', (req, res) => {
  const id = req.params.id;
  const user = getAuthUser(req);
  const { status, resolutionNote, action, sanctionReason, adminComment } = req.body;

  const resolved = db.resolveSecurityReport(
    id,
    status,
    resolutionNote,
    action,
    sanctionReason,
    adminComment,
    user?.apodo || 'administrador'
  );
  if (!resolved) return res.status(404).json({ error: 'Reporte no encontrado.' });

  res.json({ success: true, report: resolved });
});

// ================= ADMIN / INSTITUTION VALIDATION ROUTES =================
app.get('/api/admin/institutions', (_req, res) => {
  const allUsers = Object.values(db.getUsers());
  const pending = allUsers.filter(u => u.tipo === 'institucional');
  res.json(pending);
});

app.post('/api/admin/institutions/:id/approve', (req, res) => {
  const userId = req.params.id;
  const updated = db.approveInstitution(userId);
  if (!updated) return res.status(404).json({ error: 'Institución no encontrada.' });
  res.json({ success: true, user: updated, message: 'Institución dada de alta oficialmente.' });
});

app.post('/api/admin/institutions/:id/reject', (req, res) => {
  const userId = req.params.id;
  const { reason } = req.body;
  const updated = db.rejectInstitution(userId, reason);
  if (!updated) return res.status(404).json({ error: 'Institución no encontrada.' });
  res.json({ success: true, user: updated, message: 'Solicitud de alta rechazada.' });
});

app.post('/api/admin/institutions/:id/verify', (req, res) => {
  const userId = req.params.id;
  const { isVerified } = req.body;

  const updated = db.verifyInstitution(userId, isVerified !== false);
  if (!updated) return res.status(404).json({ error: 'Institución no encontrada.' });

  db.addNotification(updated.apodo, isVerified ? '¡Tu institución ha sido verificada con tilde azul oficial de CLUB65!' : 'Se rechazó la verificación de la institución.');
  res.json({ success: true, user: updated });
});

// PROMOTE USER TO ADMINISTRATOR
app.post('/api/admin/promote', (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).json({ error: 'Nombre de usuario requerido.' });

  const updated = db.makeUserAdmin(username);
  if (!updated) return res.status(404).json({ error: 'Usuario no encontrado.' });

  res.json({ success: true, user: updated, message: `El usuario ${updated.apodo} ahora es Administrador Oficial.` });
});

// ================= ADMIN BANS & SANCTIONS ROUTES =================
app.get('/api/admin/sanctions', (_req, res) => {
  res.json(db.getSanctions());
});

app.post('/api/admin/sanctions', (req, res) => {
  const user = getAuthUser(req);
  const { username, reason, comment, type, liftDate, reportId } = req.body;
  if (!username || !reason) {
    return res.status(400).json({ error: 'Usuario y motivo requeridos.' });
  }

  const sanction = db.addSanction({
    username,
    reason,
    comment,
    adminUsername: user?.usuario || 'administrador',
    type: type || 'permanente',
    liftDate,
    reportId
  });

  res.status(201).json({ success: true, sanction });
});

app.delete('/api/admin/sanctions/:username', (req, res) => {
  const username = req.params.username;
  db.removeSanction(username);
  res.json({ success: true, message: `Sanción levantada para ${username}.` });
});

app.get('/api/admin/banned', (_req, res) => {
  res.json({
    bannedUsers: (db as any).getSanctions ? db.getSanctions().map(s => s.username) : ['usuario_troll', 'spammer_crypto', 'cuenta_falsa_3f', 'estafas_online', 'perfil_ofensivo']
  });
});

app.post('/api/admin/ban', (req, res) => {
  const { identifier } = req.body;
  if (!identifier) return res.status(400).json({ error: 'Identificador requerido.' });
  db.banUserGlobal(identifier);
  res.json({ success: true, message: `Usuario ${identifier} vetado correctamente.` });
});

app.post('/api/admin/unban', (req, res) => {
  const { identifier } = req.body;
  if (!identifier) return res.status(400).json({ error: 'Identificador requerido.' });
  db.unbanUserGlobal(identifier);
  res.json({ success: true, message: `Sanción levantada para ${identifier}.` });
});

// ================= SIMULATED EMAILS ROUTE =================
app.get('/api/simulated-emails', (_req, res) => {
  res.json(db.getSimulatedEmails());
});

// ================= VITE DEV / PRODUCTION STATIC =================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CLUB65 Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
